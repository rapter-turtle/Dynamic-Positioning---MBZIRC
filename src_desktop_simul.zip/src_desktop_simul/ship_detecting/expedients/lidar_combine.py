#!/usr/bin/python3

import pcl
import rospy as rp
import numpy as np
import pcl_python_helper as ph

from variables import *
from scipy.spatial.transform import Rotation as R
from sensor_msgs.msg import PointCloud2

class LiDAR_Combinator():
    def __init__(self):
        rp.init_node(LIDAR_FIX_NODE)
        rp.loginfo("[{}] node created".format(LIDAR_FIX_NODE))

        # Flags
        self.is_pub_on = False
        self.rotation_matrix = None

        # Empty Variable Initials
        self.ouster1_pcl = None
        self.ouster2_pcl = None
        self.lidar_comb_pcl = pcl.PointCloud_PointXYZRGB()
        self.max_tdiff = 0.15
        self.sensor_tprev = None
        self.rp_tprev = None

        # ROS topic Subscribers
        self.os1_sub =  rp.Subscriber(OS1_, PointCloud2, self.os1_Callback)
        if NUM_LIDARS == "II":
            self.os2_sub =  rp.Subscriber(OS2_, PointCloud2, self.os2_Callback)
        self.lidar_comb_pub = rp.Publisher(OS_COMBINED_, PointCloud2, queue_size=1)

    def os1_Callback(self, os1_msg):
        if self.rp_tprev == None:
            self.rp_tprev = rp.Time.now()
            self.sensor_tprev = os1_msg.header.stamp
        print("START",(rp.Time.now()- self.rp_tprev) - (os1_msg.header.stamp-self.sensor_tprev))
        if (rp.Time.now()- self.rp_tprev) - (os1_msg.header.stamp-self.sensor_tprev) > rp.Duration(self.max_tdiff):
            return
        ouster1_pcl = ph.ros_to_pcl_I(os1_msg)
        ouster1_nmp = ph.pcl_to_numpy(ouster1_pcl)

        # Mask 1: By Distance (DELETE SO FAR)
        mask_far = np.square(ouster1_nmp[:,0])+np.square(ouster1_nmp[:,1]) > np.square(PASS_LIMIT_DEADZONE)
        ouster1_nmp[mask_far] = 0.0
        ouster1_nmp = ouster1_nmp[np.any(ouster1_nmp != [0.,0.,0.,0.], axis=1)]

        # Mask 2: By Intensity
        mask_intensity = np.logical_and(np.square(ouster1_nmp[:,0])+np.square(ouster1_nmp[:,1]) < np.square(INTENSITY_DISTANCE),
                                        ouster1_nmp[:,3] < INTENSITY_THRESHOLD)
        ouster1_nmp[mask_intensity] = 0.0
        ouster1_nmp = ouster1_nmp[np.any(ouster1_nmp != [0.,0.,0.,0.], axis=1)]

        # Fix the TF with IMU/USV-Center
        r = R.from_euler('z', -LIDAR_ROTATED_, degrees=True)
        ouster1_nmp[:,0:3] = (r.as_matrix()@(ouster1_nmp[:,0:3].T)).T
        ouster1_nmp[:,0] += TOP_BOARD_LENGTH/2
        ouster1_nmp[:,1] -= TOP_BOARD_WIDTH/2
        self.ouster1_pcl = ouster1_nmp

        if NUM_LIDARS == "II":
            if self.ouster1_pcl is not None and self.ouster2_pcl is not None:
                ouster_fixed = np.append(self.ouster1_pcl.astype('float32'), self.ouster2_pcl.astype('float32'), 0)
                self.lidar_comb_pcl.from_array(ouster_fixed.astype('float32'))
                lidar_comb_msg = ph.pcl_to_ros(self.lidar_comb_pcl, frame_id=LIDAR_TF)
                self.lidar_comb_pub.publish(lidar_comb_msg)
                
                if not self.is_pub_on:
                    print("--------- Publishing Topic: [{}] + [{}] = [{}] ...".format(OS1_, OS2_, OS_COMBINED_))
                    self.is_pub_on = True

        elif NUM_LIDARS == "I":
            ouster_fixed = self.ouster1_pcl
            self.lidar_comb_pcl.from_array(ouster_fixed.astype('float32'))
            lidar_comb_msg = ph.pcl_to_ros(self.lidar_comb_pcl, frame_id=LIDAR_TF)
            self.lidar_comb_pub.publish(lidar_comb_msg)

            if not self.is_pub_on:
                    print("--------- Publishing Topic: [{}] => [{}] ...".format(OS1_, OS_COMBINED_))
                    self.is_pub_on = True
        print("END", (rp.Time.now()- self.rp_tprev) - (os1_msg.header.stamp-self.sensor_tprev))

    def os2_Callback(self, os2_rosmsg):
        if rp.Time.now() - os2_rosmsg.header.stamp > rp.Duration(self.max_tdiff):
            return
        ouster2_pcl = ph.ros_to_pcl_I(os2_rosmsg)
        ouster2_nmp = ph.pcl_to_numpy(ouster2_pcl)
        
        # Mask 0: By LiDAR FOV
        mask_fov = np.logical_or(ouster2_nmp[:,0] < -TOP_BOARD_WIDTH, ouster2_nmp[:,0] < -TOP_BOARD_LENGTH)
        ouster2_nmp[mask_fov] = 0.0
        ouster2_nmp = ouster2_nmp[np.any(ouster2_nmp != [0.,0.,0.,0.], axis=1)]

        # Mask 1: By Distance (DELETE SO FAR)
        mask_far = np.square(ouster2_nmp[:,0])+np.square(ouster2_nmp[:,1]) > np.square(PASS_LIMIT_DEADZONE)
        ouster2_nmp[mask_far] = 0.0
        ouster2_nmp = ouster2_nmp[np.any(ouster2_nmp != [0.,0.,0.,0.], axis=1)]

        # Mask 2: By Intensity
        mask_intensity = np.logical_and(np.square(ouster2_nmp[:,0])+np.square(ouster2_nmp[:,1]) < np.square(INTENSITY_DISTANCE),
                                        ouster2_nmp[:,3] < INTENSITY_THRESHOLD)
        ouster2_nmp[mask_intensity] = 0.0
        ouster2_nmp = ouster2_nmp[np.any(ouster2_nmp != [0.,0.,0.,0.], axis=1)]

        # Fix the TF with IMU/USV-Center
        r = R.from_euler('z', LIDAR_ROTATED_, degrees=True)
        ouster2_nmp[:,0:3] = (r.as_matrix()@(ouster2_nmp[:,0:3].T)).T
        ouster2_nmp[:,0] += TOP_BOARD_LENGTH/2
        ouster2_nmp[:,1] -= TOP_BOARD_WIDTH/2
        self.ouster2_pcl = ouster2_nmp
    
if __name__=="__main__":
    try:
        lidar_combinator = LiDAR_Combinator()
        rp.spin()
    except rp.ROSInterruptException:
        pass