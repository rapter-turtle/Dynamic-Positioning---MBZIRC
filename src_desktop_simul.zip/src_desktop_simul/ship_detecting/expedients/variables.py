#!/usr/bin/python3
import rospy

# Nodes Name
rospy.init_node("lidar_params") # lidar_params.py
rospy.set_param('/COMBINE_NODE', "lidar_combine") # lidar_combine.cp
rospy.set_param('/MEASURE_NODE', "lidar_measure") # lidar_measure.py

# Nukhada Config
rospy.set_param('/TOP_BOARD_WIDTH', 3.325)
rospy.set_param('/TOP_BOARD_LENGTH', 1.415)

# IMU
rospy.set_param('/IMU_', "/imu/data")
rospy.set_param('/PC_GLOBALIZE', False) # boolean

# LiDAR
rospy.set_param('/LIDAR_FIX_NODE', "lidar_combine")
rospy.set_param('/FRAME_ID', "os_sensor")
rospy.set_param('/OS_SET_DOUBLE', False) # boolean
rospy.set_param('/LIDAR_ROTATED_', 90)
rospy.set_param('/max_tdiff', 0.1)

rospy.set_param('/OS_', "/os_cloud_node/points")
rospy.set_param('/OS1_', "/ouster1/points")
rospy.set_param('/OS2_', "/ouster2/points")
rospy.set_param('/OS_COMBINED_', "/ouster/fixed_bag")
rospy.set_param('/OS_FILTERED', "/ouster/filtered_bag")
rospy.set_param('/OS_CLUSTERED', "/ouster/clustered_bag")

rospy.set_param('/OS1_surface_x', -0.0)
rospy.set_param('/OS1_surface_y', 0.0)

# Target Ship Result
rospy.set_param('/TARGET_POLYGONS_', "/target/obboxes_bag")
rospy.set_param('/TARGET_POSES_', "/target/poses_bag")

# Filter Parameters
rospy.set_param('/VG_SIZE_X', 0.5)
rospy.set_param('/VG_SIZE_Y', 0.5)
rospy.set_param('/VG_SIZE_Z', 0.5)
# -----
rospy.set_param('/PASS_LIMIT_XP', 3.5)
rospy.set_param('/PASS_LIMIT_XN', -3.5)
rospy.set_param('/PASS_LIMIT_YP', 2.0)
rospy.set_param('/PASS_LIMIT_YN', -2.0)
rospy.set_param('/PASS_LIMIT_ZP', 10.0)
rospy.set_param('/PASS_LIMIT_ZN', -10.0)
# -----
rospy.set_param('/SHIP_BOX_FILTER', "/ouster/box_filter_bag")
# -----
rospy.set_param('/PASS_LIMIT_DEADZONE', 250)
# -----
rospy.set_param('/INTENSITY_DISTANCE', 30)
rospy.set_param('/INTENSITY_THRESHOLD', 300)
# -----
rospy.set_param('/DENOISE', False) # Boolean
rospy.set_param('/MEAN_K', 3)
rospy.set_param('/THRESH', 0.01)
# -----
rospy.set_param('/TARGET_TOP_HEIGHT_N', 0.3)
rospy.set_param('/TARGET_TOP_HEIGHT_P', 0.3)
# -----
rospy.set_param('/GLOBAL_Z_FILTER', False) # Boolean
rospy.set_param('/LIDAR_TILT_BIAS', 2)
rospy.set_param('/PCL_GROUND_Z_BOUND', 0.4)

# Cluster Parameters
rospy.set_param('/LOG_SCALE', False) # Boolean
rospy.set_param('/EC_TOLERANCE', 0.3)
# rospy.set_param('/LOG_SCALE', True) # Boolean
# rospy.set_param('/EC_TOLERANCE', 0.05)
rospy.set_param('/EC_MIN_SIZE', 5)
rospy.set_param('/EC_MAX_SIZE', 500)

# CAM FoV
rospy.set_param('/CAM_FOV_HORIZONTAL', 90)
rospy.set_param('/CAM_FOV_VERTICAL', 60)
rospy.set_param('/CAM_ALPHA', 0.5236) # pi/6 radian
rospy.set_param('/A_BY_WIDTH', 0.7)
rospy.set_param('/B_BY_HEIGHT', 0.3)

# # KASS
# IMU_ = "/AN_fog/Imu"
# LIDAR_TF = "os_sensor"
# NUM_LIDARS = "I"