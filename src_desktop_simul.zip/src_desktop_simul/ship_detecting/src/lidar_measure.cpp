// Use functions to cluster the pointclouds
// Use custom functions to filter out non-ROI clusters

#include "lidar_params.hpp"
#include "lidar_heuristic_filters.cpp"
#include "pointcloud_helper.cpp"
LiDAR_Params lp;

// Global Variables
ros::Time start;
bool set_init_imu = false;
Eigen::Quaternionf current_imu, init_imu;
ros::Publisher os_filtered, os_outlines, os_clustered, target_pose, marker_pub, ground_pub, ground_outline_pub;
pcl::PointCloud<pcl::PointXYZI>::Ptr os_pcl_data(new pcl::PointCloud<pcl::PointXYZI>);
pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered_original(new pcl::PointCloud<pcl::PointXYZI>);

// Messages to be published
sensor_msgs::PointCloud2 ros_filtered, ros_clustered, ros_outlines;
std_msgs::Float32MultiArray targetPoseArr;

void ground_voxels (Eigen::MatrixXf max_cluster_global){

    if (!max_cluster_global.rows()){
        sensor_msgs::PointCloud2 rosCloud;
        rosCloud.header.frame_id = lp.FRAME_ID_GROUND;
        ground_pub.publish(rosCloud);
        ground_outline_pub.publish(rosCloud);
        return;
    }

    Eigen::MatrixXf max_cluster_fixed = (init_imu.toRotationMatrix().transpose() * max_cluster_global.transpose()).transpose();
    float lhs_y = max_cluster_fixed.col(1).minCoeff();
    float rhs_y = max_cluster_fixed.col(1).maxCoeff();
    float width_range = abs(rhs_y - lhs_y);
    float bin_range = lp.GROUND_BIN_SIZE; // meter
    int total_bin_num = int(std::ceil(width_range / bin_range));

    std::vector<Eigen::MatrixXf> bin_original(total_bin_num);
    std::vector<Eigen::MatrixXf> bin_fixed(total_bin_num);

    //Initialize the bin
    for (int i=0;i<total_bin_num;i++){
        bin_original[i].setZero(1, max_cluster_global.cols());
        bin_fixed[i].setZero(1, max_cluster_global.cols());
    }

    for (int i = 0; i < max_cluster_fixed.rows(); ++i) {
        int bin_num = int(std::floor((max_cluster_fixed(i,1)-lhs_y)/bin_range));

        if (int(max_cluster_fixed(i,0)) && int(max_cluster_fixed(i,1))){
            Eigen::MatrixXf newMat_original(bin_fixed[bin_num].rows() + 1, bin_fixed[bin_num].cols());
            newMat_original << bin_original[bin_num],
                        max_cluster_global.row(i);
            bin_original[bin_num] = newMat_original;

            Eigen::MatrixXf newMat_fixed(bin_fixed[bin_num].rows() + 1, bin_fixed[bin_num].cols());
            newMat_fixed << bin_fixed[bin_num],
                        max_cluster_fixed.row(i);
            bin_fixed[bin_num] = newMat_fixed;
        }
    }

    std::vector<std::pair<float, float>> ground_voxels;
    pcl::PointCloud<pcl::PointXYZI> groundCloud, groundOutline;
    for (int b=0;b<total_bin_num;b++){

        int max_x_idx, min_x_idx = 0;
        float min_x = INFINITY;
        float max_x = -INFINITY;
        pcl::PointXYZI max_x_pt, min_x_pt;
        for (int i=1;i<bin_fixed[b].rows();i++){

            pcl::PointXYZI pt_original;
            pt_original.x = bin_original[b](i,0);
            pt_original.y = bin_original[b](i,1);
            pt_original.z = bin_original[b](i,2);
            pt_original.intensity = float(b);

            if (bin_fixed[b](i,0) < min_x){
                min_x = bin_fixed[b](i,0);
                min_x_pt.x = pt_original.x;
                min_x_pt.y = pt_original.y;
                min_x_pt.z = pt_original.z;
                min_x_pt.intensity = 0.0;
                min_x_idx = i;
            }

            if (bin_fixed[b](i,0) > max_x){
                max_x = bin_fixed[b](i,0);
                max_x_pt.x = pt_original.x;
                max_x_pt.y = pt_original.y;
                max_x_pt.z = pt_original.z;
                max_x_pt.intensity = 0.0;
                max_x_idx = i;
            }


            groundCloud.push_back(pt_original);
        }
        groundOutline.push_back(min_x_pt);
        groundOutline.push_back(max_x_pt);
    }

    sensor_msgs::PointCloud2 rosCloud;
    pcl::toROSMsg(groundCloud, rosCloud);
    rosCloud.header.frame_id = lp.FRAME_ID_GROUND;
    ground_pub.publish(rosCloud);

    pcl::toROSMsg(groundOutline, rosCloud);
    rosCloud.header.frame_id = lp.FRAME_ID_GROUND;
    ground_outline_pub.publish(rosCloud);
}

pcl::PointCloud<pcl::PointXYZI>::Ptr filtering_function (const sensor_msgs::PointCloud2::ConstPtr& msg){

    pcl::PointCloud<pcl::PointXYZI> pcl;
    pcl::fromROSMsg (*msg, pcl);

    pcl::VoxelGrid<pcl::PointXYZI> vg;
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered_vg (new pcl::PointCloud<pcl::PointXYZI>);
    vg.setInputCloud (pcl.makeShared());
    vg.setLeafSize (lp.VG_SIZE_X, lp.VG_SIZE_Y, lp.VG_SIZE_X);
    vg.filter(*cloud_filtered_vg);

    pcl::CropBox<pcl::PointXYZI> boxFilter;
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered_box (new pcl::PointCloud<pcl::PointXYZI>);
    boxFilter.setInputCloud(cloud_filtered_vg);
    boxFilter.setMin(Eigen::Vector4f(lp.PASS_LIMIT_XN, lp.PASS_LIMIT_YN, lp.PASS_LIMIT_ZN, 1.0));
    boxFilter.setMax(Eigen::Vector4f(lp.PASS_LIMIT_XP, lp.PASS_LIMIT_YP, lp.PASS_LIMIT_ZP, 1.0));
    boxFilter.setNegative(true);
    boxFilter.filter(*cloud_filtered_box);

    // cout << cloud_filtered_box->points.size() << endl;

    cloud_filtered_original = cloud_filtered_box;

    //////////
    pcl::PointCloud<pcl::PointXYZI>::Ptr filtered_topub(new pcl::PointCloud<pcl::PointXYZI>);
    if (lp.LOG_SCALE){

        // To Eigen Matrix
        Eigen::MatrixXf points_mat(cloud_filtered_box->points.size(), 4); // Assuming XYZI structure
        for(int i = 0; i < cloud_filtered_box->points.size(); ++i) {
            points_mat(i, 0) = cloud_filtered_box->points[i].x;
            points_mat(i, 1) = cloud_filtered_box->points[i].y;
            points_mat(i, 2) = cloud_filtered_box->points[i].z;
            points_mat(i, 3) = cloud_filtered_box->points[i].intensity;
            // cout << cloud_filtered_box->points[i].intensity << endl;
        }

        // Perform the log scale transformation on the x, y coordinates
        for(int i = 0; i < points_mat.rows(); ++i) {
            float x = points_mat(i, 0);
            float y = points_mat(i, 1);

            float dist_squared = x * x + y * y;
            float dist = std::sqrt(dist_squared);
            if(dist > 0) { // Check to avoid division by zero
                float ln_dist = std::log(dist);
                points_mat(i, 0) *= ln_dist / dist;
                points_mat(i, 1) *= ln_dist / dist;
                points_mat(i, 2) = 0.0;
            }
            // Z and intensity values remain unchanged
        }

        // If you need to convert the Eigen matrix back to a PCL point cloud
        for(int i = 0; i < points_mat.rows(); ++i) {
            pcl::PointXYZI point;
            point.x = points_mat(i, 0);
            point.y = points_mat(i, 1);
            point.z = points_mat(i, 2); // if you need to keep the z value
            point.intensity = points_mat(i, 3); // if you need to keep the intensity value
            filtered_topub->push_back(point);
        }

    }else{
        filtered_topub = cloud_filtered_box;
    }

    pcl::toROSMsg(*filtered_topub, ros_filtered);
    ros_filtered.header.frame_id = lp.FRAME_ID_FILTERED;

    return filtered_topub;
}

void clustering_function (pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered){

    std::vector<pcl::PointIndices> cluster_indices;
    pcl::search::KdTree<pcl::PointXYZI>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZI>);
    // cout << cloud_filtered->points.size() << endl;

    if (cloud_filtered->points.size () > 0) {
        // cout << cloud_filtered->points[0].x << endl;
        pcl::EuclideanClusterExtraction<pcl::PointXYZI> ec;
        tree->setInputCloud(cloud_filtered);
        ec.setClusterTolerance(lp.EC_TOLERANCE);
        ec.setMinClusterSize(lp.EC_MIN);
        ec.setMaxClusterSize(lp.EC_MAX);
        ec.setSearchMethod(tree);
        ec.setInputCloud(cloud_filtered);
        ec.extract(cluster_indices);
    }
    tree.reset(new pcl::search::KdTree<pcl::PointXYZI>);

    int total_point_num = 0;
    for (std::vector<pcl::PointIndices>::const_iterator it1 = cluster_indices.begin (); it1 != cluster_indices.end (); ++it1) {
        total_point_num += it1->indices.size();
    }

    int j = 0;
    int valid_cluster_cnt = 0;
    pcl::PointCloud<pcl::PointXYZI>::Ptr TotalCloud(new pcl::PointCloud<pcl::PointXYZI>);
    pcl::PointCloud<pcl::PointXYZI>::Ptr TotalOutlines(new pcl::PointCloud<pcl::PointXYZI>);

    // Marker Preparation
    visualization_msgs::MarkerArray TotalMarkers;
    visualization_msgs::Marker clear_marker;
    clear_marker.header.frame_id = "os_sensor"; // Same frame as your other markers
    clear_marker.header.stamp = ros::Time::now();
    clear_marker.ns = "vector_viz"; // Same namespace as the markers you want to clear
    clear_marker.action = visualization_msgs::Marker::DELETEALL;
    TotalMarkers.markers.push_back(clear_marker);
    marker_pub.publish(TotalMarkers);

    // TargetPose Preparation
    targetPoseArr.data.clear();
    targetPoseArr.data.push_back(float(valid_cluster_cnt));
    Eigen::Vector3f euler_angles = current_imu.toRotationMatrix().eulerAngles(2, 0, 1); // 2=z, 0=x, 1=y (zxy order)
    targetPoseArr.data.push_back(euler_angles[0]);
    targetPoseArr.data.push_back(euler_angles[1]);
    targetPoseArr.data.push_back(euler_angles[2]);

    Eigen::MatrixXf max_cluster(total_point_num, 3);
    // cout << "Max PN: " << total_point_num << endl;
    max_cluster.setZero();
    int cnt = 0;
    float max_dimension = 0.0;
    for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it) {
        int numPoints = it->indices.size();

        if (numPoints != 0){

            // 1. Change to Eigen Matrix ////////////////////////////////////////////////////////////////////////////////////////////
            Eigen::MatrixXf cluster_matrix(it->indices.size(), 3);
            cluster_matrix.setZero();

            int i = 0;
            pcl::PointCloud<pcl::PointXYZI> clusterCloud;
            for (std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit) {
                pcl::PointXYZI pt = cloud_filtered_original->points[*pit];
                pt.intensity = (float)(j + 1);

                // cout << pt.intensity << endl;
                clusterCloud.push_back(pt);

                cluster_matrix(i, 0) = pt.x;
                cluster_matrix(i, 1) = pt.y;
                cluster_matrix(i, 2) = pt.z;

                i++;
            }

            Eigen::Vector3f com;
            com.setZero();
            com(0) = (cluster_matrix.col(0).maxCoeff()+cluster_matrix.col(0).minCoeff())/2;
            com(1) = (cluster_matrix.col(1).maxCoeff()+cluster_matrix.col(1).minCoeff())/2;

            Eigen::MatrixXf covariance = (cluster_matrix.adjoint() * cluster_matrix) / double(cluster_matrix.rows() - 1);
            Eigen::EigenSolver<Eigen::MatrixXf> solver(covariance);
            Eigen::VectorXf eigenvalues = solver.eigenvalues().real();
            Eigen::MatrixXf eigenvectors = solver.eigenvectors().real();

            Eigen::MatrixXf cluster_matrix_coordinated = (eigenvectors.transpose() * cluster_matrix.transpose()).transpose();

            // 2. Check the checklist ////////////////////////////////////////////////////////////////////////////////////////////////
            bool keepCluster = true;

            float height = cluster_matrix_coordinated.col(2).maxCoeff() - cluster_matrix_coordinated.col(2).minCoeff();
            float width = cluster_matrix_coordinated.col(1).maxCoeff() - cluster_matrix_coordinated.col(1).minCoeff();
            float length = cluster_matrix_coordinated.col(0).maxCoeff() - cluster_matrix_coordinated.col(0).minCoeff();
            max_dimension = (width > length) ? width : length;

            if (lp.CAM_FOV_FITLER){
                keepCluster = (keepCluster != true) ? keepCluster : cam_fov_filter(com, lp.TOP_BOARD_WIDTH, lp.CAM_ALPHA);    // Camera FOV
            }

            if (lp.LETTUCE_FILTER){
                keepCluster = (keepCluster != true) ? keepCluster : lettuce_filter(eigenvalues, eigenvectors, 0.005);                // Lettuce Filter (with Z eigenvalue)
            }

            if (lp.BUOY_FILTER){
                keepCluster = (keepCluster != true) ? keepCluster : (max_dimension > lp.BUOY_SIZE);                       // Buoy Filter (with size)
            }

            if (lp.GLOBAL_Z_FILTER){
                keepCluster = (keepCluster != true) ? keepCluster : max_height_filter(  cluster_matrix_coordinated, com,                    // Too high box filter
                                                                                    lp.TARGET_TOP_HEIGHT_MIN, lp.TARGET_TOP_HEIGHT_MAX);
            }

            if (lp.TAIL_FILTER){
                keepCluster = (keepCluster != true) ? keepCluster : nukhada_tail_filter(cluster_matrix_coordinated, lp.TAIL_ANGLE);       // Nukhada Tail Filter
            }

            if (lp.BIG_WAVE_FILTER){
                keepCluster = (keepCluster != true) ? keepCluster : (lettuce_filter(eigenvalues, eigenvectors, 0.01) && (max_dimension > lp.WAVE_SIZE));                // Big Wave Filter (with Z eigenvalue)
            }

            if (max_dimension > lp.GROUND_MAX_WIDTH){
                max_cluster.block(cnt, 0, numPoints, 3) = cluster_matrix;
                keepCluster = false;
            }
            cnt += numPoints;

            // 3. Publish the proper clusters ///////////////////////////////////////////////////////////////////////////////////////
            if (keepCluster){

                // 4. Create the contour outline of the cluster /////////////////////////////////////////////////////////////////////////
                Eigen::MatrixXf cluster_outline = cluster_to_contour(cluster_matrix, com);
                Eigen::MatrixXf sorted_eigenvectors_outline = extract_sorted_eigenvectors(cluster_outline);

                valid_cluster_cnt++;

                // OUTLINE ################################################################################
                pcl::PointCloud<pcl::PointXYZI> cluster_outline_topub;
                Eigen::MatrixXf outline_original = cluster_outline.rowwise() + com.transpose();
                for(int i = 0; i < outline_original.rows(); ++i) {
                    pcl::PointXYZI point;
                    point.x = outline_original(i, 0);
                    point.y = outline_original(i, 1);
                    point.z = outline_original(i, 2); // if you need to keep the z value
                    point.intensity = j; // if you need to keep the intensity value
                    cluster_outline_topub.push_back(point);
                }
                *TotalOutlines += cluster_outline_topub;

                // T_POSE #################################################################################
                float width_projected = (cluster_matrix.col(0).maxCoeff()-cluster_matrix.col(0).minCoeff()); // X
                float height_projected = (cluster_matrix.col(2).maxCoeff()-cluster_matrix.col(2).minCoeff()); // Z
                float r1 = width_projected/(2*lp.A_BY_WIDTH*tan(lp.CAM_FOV_HORIZONTAL));
                float r2 = height_projected/(2*lp.B_BY_HEIGHT*tan(lp.CAM_FOV_VERTICAL));
                float minimum_r = (r1 > r2) ? r1 : r2;
                float dv_theta = - atan2(com[0],(com[1]-lp.TOP_BOARD_WIDTH/2));
                float theta = dv_theta - M_PI/2;

                targetPoseArr.data.push_back(com[0]);
                targetPoseArr.data.push_back(com[1]);
                targetPoseArr.data.push_back(com[2]);

                theta = atan2(sorted_eigenvectors_outline(1,0),sorted_eigenvectors_outline(0,0));
                if (theta < 0) {
                    theta += 2 * M_PI;
                }
                targetPoseArr.data.push_back(theta);
                targetPoseArr.data.push_back(minimum_r);
                targetPoseArr.data.push_back(theta);
                targetPoseArr.data.push_back(max_dimension);

                // CLUSTER ################################################################################
                *TotalCloud += clusterCloud;
                clusterCloud.clear();

                // HEADING ################################################################################
                visualization_msgs::Marker marker;
                marker.header.frame_id = "os_sensor"; // Change to your frame
                marker.header.stamp = ros::Time();
                marker.ns = "vector_viz";
                marker.id = j;
                marker.type = visualization_msgs::Marker::ARROW;
                marker.action = visualization_msgs::Marker::ADD;

                geometry_msgs::Point start, end;
                start.x = com[0];
                start.y = com[1];
                start.z = com[2];

                end.x = start.x + sorted_eigenvectors_outline(0,0)*30; // Change 1.0 to your vector's x component
                end.y = start.y + sorted_eigenvectors_outline(1,0)*30; // Change 1.0 to your vector's y component
                end.z = start.z + sorted_eigenvectors_outline(2,0)*30; // Change 1.0 to your vector's z component

                marker.points.push_back(start);
                marker.points.push_back(end);

                marker.scale.x = 1; // Shaft diameter
                marker.scale.y = 1; // Head diameter
                marker.scale.z = 1; // Head length
                marker.color.r = 1.0;
                marker.color.g = 0.0;
                marker.color.b = 0.0;
                marker.color.a = 1.0;

                TotalMarkers.markers.push_back(marker);

                // END ####################################################################################
            }
        }
        j++;
    }

    ground_voxels(max_cluster);

    targetPoseArr.data[0] = valid_cluster_cnt;

    // cout << TotalCloud->points.size() << endl;
    pcl::toROSMsg(*TotalCloud, ros_clustered);
    ros_clustered.header.frame_id = lp.FRAME_ID_CLUSTERED;

    pcl::toROSMsg(*TotalOutlines, ros_outlines);
    ros_outlines.header.frame_id = lp.FRAME_ID_CLUSTERED;

    marker_pub.publish(TotalMarkers);

    return;
}

void cloud_cb(const sensor_msgs::PointCloud2::ConstPtr& msg){
    start = ros::Time::now();

    pcl::PointCloud<pcl::PointXYZI>::Ptr output = filtering_function(msg);

    os_filtered.publish(ros_filtered);

    clustering_function(output);
    os_clustered.publish(ros_clustered);
    os_outlines.publish(ros_outlines);
    target_pose.publish(targetPoseArr);

    std::cout << "LAP - MEASURE: " << std::fixed << std::setprecision(12) << ros::Time::now() - start << std::endl;
}

void imu_cb(const sensor_msgs::Imu::ConstPtr& msg){
    if (!set_init_imu){
        init_imu.x() = msg->orientation.x;
        init_imu.y() = msg->orientation.y;
        init_imu.z() = msg->orientation.z;
        init_imu.w() = msg->orientation.w;
        // cout << "SET!!" << endl;
        set_init_imu = true;
    }

    current_imu.x() = msg->orientation.x;
    current_imu.y() = msg->orientation.y;
    current_imu.z() = msg->orientation.z;
    current_imu.w() = msg->orientation.w;
}

int main(int argc, char **argv){
    ros::init(argc, argv, "lidar_measure");
    ros::NodeHandle n;

    lp = load_lidar_prop(n);

    os_filtered = n.advertise<sensor_msgs::PointCloud2>(lp.OS_FILTERED, 1);
    os_clustered = n.advertise<sensor_msgs::PointCloud2>(lp.OS_CLUSTERED, 1);
    os_outlines = n.advertise<sensor_msgs::PointCloud2>(lp.OS_OUTLINES, 1);
    target_pose = n.advertise<std_msgs::Float32MultiArray>(lp.TARGET_POSES_, 1);
    marker_pub = n.advertise<visualization_msgs::MarkerArray>(lp.MARKER_PUB, 1);
    ground_pub = n.advertise<sensor_msgs::PointCloud2>(lp.OS_GROUND, 1);
    ground_outline_pub = n.advertise<sensor_msgs::PointCloud2>(lp.OS_GROUNDLINE, 1);

    ros::AsyncSpinner spinner(2);
    ros::Subscriber sub_pointcloud = n.subscribe(lp.OS_COMBINED_GLOBAL, 1, cloud_cb);
    ros::Subscriber sub_imu = n.subscribe(lp.IMU_, 1, imu_cb);
    // ros::spin();
    spinner.start();
    ros::waitForShutdown();

    return 0;
}
