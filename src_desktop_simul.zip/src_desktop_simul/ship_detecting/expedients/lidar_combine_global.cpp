#include "lidar_params.hpp"
LiDAR_Params lp;

// Global Variables
pcl::PointCloud<pcl::PointXYZI>::Ptr os1_pcl_data(new pcl::PointCloud<pcl::PointXYZI>);
pcl::PointCloud<pcl::PointXYZI>::Ptr os2_pcl_data(new pcl::PointCloud<pcl::PointXYZI>);
Eigen::MatrixXd os1_eigen_data, os2_eigen_data, output_eigen, os1_eigen_data_global, os2_eigen_data_global, output_eigen_global;
bool os1_set, os2_set, os_comb_ready = false;
ros::Time rp_tprev, sensor_tprev, start;
ros::Publisher os_pub;
double os1_t, os2_t;

// IMU Interpolation
std::vector<double> imu_time_stack_os1, imu_time_stack_os2;
std::vector<Eigen::Quaterniond> imu_quat_stack_os1, imu_quat_stack_os2;
Eigen::Vector3d imu_angvel_os1, imu_angvel_os2;

Eigen::MatrixXd pcl_to_eigen(const pcl::PointCloud<pcl::PointXYZI>::ConstPtr& pcl){
    Eigen::MatrixXd eigen;

    int numPoints = pcl->points.size();
    eigen.setZero(numPoints, 4);

    for(int i = 0; i < numPoints; i++) {
        eigen(i, 0) = pcl->points[i].x;
        eigen(i, 1) = pcl->points[i].y;
        eigen(i, 2) = pcl->points[i].z;
        eigen(i, 3) = pcl->points[i].intensity;
    }

    return eigen;
}

Eigen::MatrixXd rotate_matrix(const Eigen::MatrixXd mat, double theta_custom){
    Eigen::MatrixXd mat_copy = mat;
    double theta = theta_custom * M_PI/180;
    Eigen::Matrix3d rotation;
    rotation << cos(theta), -sin(theta), 0,
                sin(theta),  cos(theta), 0,
                        0,          0, 1;
    double dx = lp.TOP_BOARD_LENGTH/2, dy = -lp.TOP_BOARD_WIDTH/2;
    Eigen::Vector3d translation(dx, dy, 0);
    for (int i = 0; i < mat_copy.rows(); ++i) {
        Eigen::Vector3d point(mat_copy(i, 0), mat_copy(i, 1), mat_copy(i, 2));
        Eigen::Vector3d transformed = rotation * point + translation;
        mat_copy(i, 0) = transformed(0);
        mat_copy(i, 1) = transformed(1);
        mat_copy(i, 2) = transformed(2);
    }

    return mat_copy;
}

Eigen::Quaterniond imu_interpolation(std::string os_num, double os_time_tosec){
    /// IMU Time Match

    Eigen::Vector3d imu_angvel;
    std::vector<Eigen::Quaterniond> imu_quat_stack;
    std::vector<double> imu_time_stack;
    if (os_num == "os1"){
        imu_angvel = imu_angvel_os1;
        imu_quat_stack = imu_quat_stack_os1;
        imu_time_stack = imu_time_stack_os1;
    }else if (os_num == "os2"){
        imu_angvel = imu_angvel_os2;
        imu_quat_stack = imu_quat_stack_os2;
        imu_time_stack = imu_time_stack_os2;
    }

    int idx = 0;
    bool between = false;
    while ((idx < imu_time_stack.size()) && (1 < imu_time_stack.size())){
        if (imu_time_stack[idx] < os_time_tosec){
            if (idx != 0){
                imu_time_stack.erase(imu_time_stack.begin());
                imu_quat_stack.erase(imu_quat_stack.begin());
            }
            else idx++;
        }else{
            between = true;
            break;
        }
    }

    Eigen::Quaterniond result;
    if(between){
        double t = (os_time_tosec - imu_time_stack[0])/(imu_time_stack[1] - imu_time_stack[0]);
        result = imu_quat_stack[0].slerp(t, imu_quat_stack[1]);
    }else{
        Eigen::Quaterniond quat = imu_quat_stack[0];
        Eigen::Vector4d quat_coeffs = quat.coeffs(); // Get current quaternion coeffs
        Eigen::Vector3d pqr = 0.5 * imu_angvel;

        // Quaternion derivative from angular velocity
        Eigen::Vector4d quat_derivative;
        quat_derivative << -quat.x() * pqr(0) - quat.y() * pqr(1) - quat.z() * pqr(2),
                            quat.w() * pqr(0) + quat.z() * pqr(1) - quat.y() * pqr(2),
                            quat.w() * pqr(1) - quat.z() * pqr(0) + quat.x() * pqr(2),
                            quat.w() * pqr(2) + quat.y() * pqr(0) - quat.x() * pqr(1);

        // Update quaternion
        double dt = os_time_tosec - imu_time_stack[0]; // Your time difference
        Eigen::Vector4d new_quat_coeffs = quat_coeffs + quat_derivative * dt;
        Eigen::Quaterniond new_quat(new_quat_coeffs[3], new_quat_coeffs[0], new_quat_coeffs[1], new_quat_coeffs[2]);
        new_quat = new_quat.normalized();
    }

    return result;
}

void os1_callback(const sensor_msgs::PointCloud2::ConstPtr& msg){
    os1_set = false;
    
    if(os1_pcl_data && !os_comb_ready){ // If not NullPtr

        cout << "OS1 Callback" << endl;
        
        start = ros::Time::now();

        pcl::fromROSMsg (*msg, *os1_pcl_data);
        os1_eigen_data = pcl_to_eigen(os1_pcl_data);

        // Local OS-1 LiDAR
        os1_eigen_data = rotate_matrix(os1_eigen_data, -lp.LIDAR_ROTATED_);

        // Global OS-1 LiDAR
        os1_t = msg->header.stamp.toSec();
        os1_eigen_data_global = (imu_interpolation("os1", os1_t).toRotationMatrix() * os1_eigen_data.transpose()).transpose();
        // cout << os1_eigen_data_global.rows() << " " << os1_eigen_data_global.cols() << endl;

        os1_set = true;
    }else{
        cout << "OS1 Callback FAIL" << endl;
    }

    // Combine two LiDAR pointclouds
    if (lp.OS_SET_DOUBLE && os1_set && os2_set){

        output_eigen.setZero(os1_eigen_data.rows() + os2_eigen_data.rows(), 4);
        output_eigen_global.setZero(os1_eigen_data_global.rows() + os2_eigen_data_global.rows(), 4);

        output_eigen << os1_eigen_data, os2_eigen_data;
        output_eigen.topRows(os1_eigen_data.rows()) = os1_eigen_data;
        output_eigen.bottomRows(os2_eigen_data.rows()) = os2_eigen_data;
        os_comb_ready = true;

    }else if (!lp.OS_SET_DOUBLE && os1_set){

        output_eigen.setZero(os1_eigen_data.rows(), 4);
        output_eigen_global.setZero(os1_eigen_data_global.rows(), 4);

        output_eigen << os1_eigen_data;
        output_eigen_global = os1_eigen_data_global;
        os_comb_ready = true;

    }

    if (os_comb_ready){
        pcl::PointCloud<pcl::PointXYZI> output_cloud;
        output_cloud.header.frame_id = lp.FRAME_ID_FIXED;
        
        int rowCnt = 0;
        int row_num = output_eigen_global.rows();
        cout << row_num << endl;
        for (int i=0; i<row_num; i++){
            Eigen::VectorXd rowVector = output_eigen_global.row(i);
            
            double m = lp.OS_MIN_INTN;
            double d = lp.OS_MAX_DIST;
            double md = lp.OS_MIN_INTN_DIST;
            double p = lp.PASS_LIMIT_ZP;
            double n = lp.PASS_LIMIT_ZN;
            double x = rowVector(0);
            double y = rowVector(1);
            double z = rowVector(2);
            double I = rowVector(3);

            // if ((x*x+y*y < md*md) && (I < m)){                     // Mask 1: By Intensity
            //     // 
            // }else if ((z > p) || (z < n)){  // Mask 2: By Z value
            //     // 
            // }else if ((x*x+y*y > d*d)){     // Mask 3: By Distance (DELETE SO FAR)
            //     // 
            // }else{
            //     pcl::PointXYZI point;
            //     point.x = x;
            //     point.y = y;
            //     point.z = z;
            //     point.intensity = I;
            //     output_cloud.points.push_back(point);

            //     rowCnt += 1;
            // }
            pcl::PointXYZI point;
            point.x = x;
            point.y = y;
            point.z = z;
            point.intensity = I;
            output_cloud.points.push_back(point);

            rowCnt += 1;
        }

        cout << output_cloud.size() << endl;

        sensor_msgs::PointCloud2 output;
        pcl::toROSMsg(output_cloud, output);
        ros::Time time;
        time.fromSec((os1_t + os2_t)/2);
        output.header.stamp = time;
        os_pub.publish(output);

        std::cout << "LAP - Combine: " << ros::Time::now() - start << std::endl;

        os_comb_ready = false;
    }
}

void os2_callback(const sensor_msgs::PointCloud2::ConstPtr& msg){

    os2_set = false;
    
    if(os2_pcl_data && !os_comb_ready){ // If not NullPtr

        cout << "OS2 Callback" << endl;
    
        pcl::fromROSMsg (*msg, *os2_pcl_data);
        os2_eigen_data = pcl_to_eigen(os2_pcl_data);

        std::vector<int> rowsToKeep;
        os_comb_ready = false;

        for(int i = 0; i < os2_eigen_data.rows(); ++i) {
            if((os2_eigen_data(i, 0) > -lp.TOP_BOARD_WIDTH) && (os2_eigen_data(i, 1) > -lp.TOP_BOARD_LENGTH)) {
                rowsToKeep.push_back(i);
            }
        }
        Eigen::MatrixXd filtered(os2_eigen_data.rows(), os2_eigen_data.cols());
        int newRow = 0;
        for(int i : rowsToKeep) {
            filtered.row(newRow++) = os2_eigen_data.row(i);
        }
        filtered.conservativeResize(newRow, Eigen::NoChange);

        // Local OS-2 LiDAR
        os2_eigen_data = rotate_matrix(filtered, lp.LIDAR_ROTATED_);
        
        // Global OS-2 LiDAR
        os2_t = msg->header.stamp.toSec();
        // cout << std::fixed << std::setprecision(12) << os2_t << endl;
        os2_eigen_data_global = (imu_interpolation("os2", os2_t).toRotationMatrix() * os2_eigen_data.transpose()).transpose();

        os2_set = true;
    }else{
        cout << "OS2 Callback FAIL" << endl;
    }
}

void imu_cb(const sensor_msgs::Imu::ConstPtr& msg){
    double msg_stamp = msg->header.stamp.toSec();
    Eigen::Quaterniond eigen_quat(msg->orientation.w, msg->orientation.x, msg->orientation.y, msg->orientation.z);

    imu_quat_stack_os1.push_back(eigen_quat);
    imu_time_stack_os1.push_back(msg_stamp);
    imu_quat_stack_os2.push_back(eigen_quat);
    imu_time_stack_os2.push_back(msg_stamp);

    imu_angvel_os1 << msg->angular_velocity.x, msg->angular_velocity.y, msg->angular_velocity.z;
    imu_angvel_os2 << msg->angular_velocity.x, msg->angular_velocity.y, msg->angular_velocity.z;
}


int main(int argc, char **argv){
    ros::init(argc, argv, "lidar_combine");
    ros::NodeHandle n;

    lp = load_lidar_prop(n);

    os_pub = n.advertise<sensor_msgs::PointCloud2>(lp.OS_COMBINED_, 1);

    if (lp.OS_SET_DOUBLE){
        ros::Subscriber os1_sub = n.subscribe(lp.OS1_, 10, os1_callback);
        ros::Subscriber os2_sub = n.subscribe(lp.OS2_, 10, os2_callback);
        ros::Subscriber imu_sub = n.subscribe(lp.IMU_, 10, imu_cb);
        ros::spin();
    }else{
        ros::Subscriber os1_sub = n.subscribe(lp.OS1_, 10, os1_callback);
        ros::Subscriber imu_sub = n.subscribe(lp.IMU_, 10, imu_cb);
        ros::spin();
    }

    return 0;
}