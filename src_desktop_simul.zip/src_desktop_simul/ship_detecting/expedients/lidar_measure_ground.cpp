#include "lidar_params.hpp"

class LiDAR_Measure{
    public:
        LiDAR_Measure();
        ~LiDAR_Measure();
    private:
        ros::NodeHandle nh;
        
        LiDAR_Params lp;

        pcl::PointCloud<pcl::PointXYZI>::Ptr os_pcl_data;
        pcl::PointCloud<pcl::PointXYZI>::Ptr TotalCloud;
        int start_flag, meas_num, marker_num, imu_init = 0;
        float imu_roll, imu_pitch, imu_yaw = 0.0;
        Eigen::Quaternionf init_eigen_quat, curr_eigen_quat;
        Eigen::Vector3f imu_angvel;
        std::vector<Eigen::Quaternionf> imu_quat_stack;
        std::vector<double> imu_time_stack;
        ros::Publisher os_filtered, os_clustered, target_pose, ground_pub, ground_outline_pub;
        std_msgs::Float32MultiArray targetPoseArr;
        ros::Time start;
        tf2_ros::TransformBroadcaster tf_broadcaster;

        void ground_voxels(Eigen::MatrixXf max_cluster_original);
        pcl::PointCloud<pcl::PointXYZI>::Ptr filtering_function (pcl::PointCloud<pcl::PointXYZI> pcl);
        std::vector<pcl::PointIndices> clustering_function (pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered);
        void lidar_detection_function (const pcl::PointCloud<pcl::PointXYZI>::ConstPtr& pcl);
        void cloud_cb(const sensor_msgs::PointCloud2::ConstPtr& msg);
        void imu_cb(const sensor_msgs::Imu::ConstPtr& msg);

        ros::Subscriber sub_pointcloud;
        ros::Subscriber sub_imu;
};

LiDAR_Measure::LiDAR_Measure(){
    lp = load_lidar_prop(nh);
    os_filtered = nh.advertise<sensor_msgs::PointCloud2>(lp.OS_FILTERED, 1);
    os_clustered = nh.advertise<sensor_msgs::PointCloud2>(lp.OS_CLUSTERED, 1);
    ground_pub = nh.advertise<sensor_msgs::PointCloud2>(lp.OS_GROUND, 1);
    ground_outline_pub = nh.advertise<sensor_msgs::PointCloud2>(lp.OS_GROUNDLINE, 1);
    target_pose = nh.advertise<std_msgs::Float32MultiArray>(lp.TARGET_POSES_, 1);
    sub_pointcloud = nh.subscribe(lp.OS_COMBINED_, 1, &LiDAR_Measure::cloud_cb, this);
    sub_imu = nh.subscribe(lp.IMU_, 1, &LiDAR_Measure::imu_cb, this);
    os_pcl_data.reset(new pcl::PointCloud<pcl::PointXYZI>);
    TotalCloud.reset(new pcl::PointCloud<pcl::PointXYZI>);
}

LiDAR_Measure::~LiDAR_Measure(){
    nh.shutdown();
}

void LiDAR_Measure::ground_voxels (Eigen::MatrixXf max_cluster_original){

    if (!max_cluster_original.rows()){
        sensor_msgs::PointCloud2 rosCloud;
        rosCloud.header.frame_id = lp.FRAME_ID_GROUND;
        ground_pub.publish(rosCloud);
        ground_outline_pub.publish(rosCloud);
        return;
    }

    // 방향만 유지
    // Eigen::MatrixXf max_cluster_fixed = (init_eigen_quat.toRotationMatrix().transpose() * curr_eigen_quat.toRotationMatrix() * max_cluster_original.transpose()).transpose();
    Eigen::MatrixXf max_cluster_fixed = (init_eigen_quat.toRotationMatrix().transpose() * curr_eigen_quat.toRotationMatrix() * max_cluster_original.transpose()).transpose();
    Eigen::MatrixXf max_cluster_global = (curr_eigen_quat.toRotationMatrix() * max_cluster_original.transpose()).transpose();


    float lhs_y = max_cluster_fixed.col(1).minCoeff();
    float rhs_y = max_cluster_fixed.col(1).maxCoeff();
    float width_range = abs(rhs_y - lhs_y);
    float bin_range = 10.0; // meter
    int total_bin_num = int(std::ceil(width_range / bin_range));

    std::vector<Eigen::MatrixXf> bin_original(total_bin_num);
    std::vector<Eigen::MatrixXf> bin_fixed(total_bin_num);

    //Initialize the bin
    for (int i=0;i<total_bin_num;i++){
        bin_original[i].setZero(1, max_cluster_global.cols());   //max_cluster_original
        bin_fixed[i].setZero(1, max_cluster_global.cols());//max_cluster_original
    }

    for (int i = 0; i < max_cluster_fixed.rows(); ++i) {
        int bin_num = int(std::floor((max_cluster_fixed(i,1)-lhs_y)/bin_range));
        
        if (int(max_cluster_fixed(i,0)) && int(max_cluster_fixed(i,1))){
            Eigen::MatrixXf newMat_original(bin_fixed[bin_num].rows() + 1, bin_fixed[bin_num].cols());
            newMat_original << bin_original[bin_num],
                        max_cluster_global.row(i);           //max_cluster_original
            bin_original[bin_num] = newMat_original;

            Eigen::MatrixXf newMat_fixed(bin_fixed[bin_num].rows() + 1, bin_fixed[bin_num].cols());
            newMat_fixed << bin_fixed[bin_num],
                        max_cluster_fixed.row(i);
            bin_fixed[bin_num] = newMat_fixed;
        }
    }

    std::vector<std::pair<float, float>> ground_voxels;
    pcl::PointCloud<pcl::PointXYZI> groundCloud, groundOutline;
    for (int b=0;b<total_bin_num;b++){

        int max_x_idx, min_x_idx = 0;
        float min_x = INFINITY;
        float max_x = -INFINITY;
        pcl::PointXYZI max_x_pt, min_x_pt;
        for (int i=1;i<bin_fixed[b].rows();i++){

            pcl::PointXYZI pt_original;
            pt_original.x = bin_original[b](i,0);
            pt_original.y = bin_original[b](i,1);
            pt_original.z = bin_original[b](i,2);
            pt_original.intensity = float(b);

            if (bin_fixed[b](i,0) < min_x){
                min_x = bin_fixed[b](i,0);
                min_x_pt.x = pt_original.x;
                min_x_pt.y = pt_original.y;
                min_x_pt.z = pt_original.z;
                min_x_pt.intensity = 0.0;
                min_x_idx = i;
            }

            if (bin_fixed[b](i,0) > max_x){
                max_x = bin_fixed[b](i,0);
                max_x_pt.x = pt_original.x;
                max_x_pt.y = pt_original.y;
                max_x_pt.z = pt_original.z;
                max_x_pt.intensity = 0.0;
                max_x_idx = i;
            }
            

            groundCloud.push_back(pt_original);
        }
        groundOutline.push_back(min_x_pt);
        groundOutline.push_back(max_x_pt);
    }

    sensor_msgs::PointCloud2 rosCloud;
    pcl::toROSMsg(groundCloud, rosCloud);
    rosCloud.header.frame_id = lp.FRAME_ID_GROUND;
    ground_pub.publish(rosCloud);

    pcl::toROSMsg(groundOutline, rosCloud);
    rosCloud.header.frame_id = lp.FRAME_ID_GROUND;
    ground_outline_pub.publish(rosCloud);

    geometry_msgs::TransformStamped tf_stamped;
    tf_stamped.header.stamp = ros::Time::now();
    tf_stamped.header.frame_id = lp.FRAME_ID_GROUND;
    tf_stamped.child_frame_id = lp.FRAME_ID_CLUSTERED;
    tf_stamped.transform.translation.x = 0.0;
    tf_stamped.transform.translation.y = 0.0;
    tf_stamped.transform.translation.z = 0.0;
    tf_stamped.transform.rotation.x = curr_eigen_quat.x();
    tf_stamped.transform.rotation.y = curr_eigen_quat.y();
    tf_stamped.transform.rotation.z = curr_eigen_quat.z();
    tf_stamped.transform.rotation.w = curr_eigen_quat.w();
    tf_broadcaster.sendTransform(tf_stamped);
}

pcl::PointCloud<pcl::PointXYZI>::Ptr LiDAR_Measure::filtering_function (pcl::PointCloud<pcl::PointXYZI> pcl){
    // cout << "OS_COMBINED FILTERING" << endl;

    pcl::VoxelGrid<pcl::PointXYZI> vg;
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered_vg (new pcl::PointCloud<pcl::PointXYZI>);
    vg.setInputCloud (pcl.makeShared());
    vg.setLeafSize (lp.VG_SIZE_X, lp.VG_SIZE_Y, lp.VG_SIZE_X);
    vg.filter(*cloud_filtered_vg);

    // cout << cloud_filtered_vg->points.size() << endl;

    pcl::CropBox<pcl::PointXYZI> boxFilter;
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered_box (new pcl::PointCloud<pcl::PointXYZI>);
    boxFilter.setInputCloud(cloud_filtered_vg);
    boxFilter.setMin(Eigen::Vector4f(lp.PASS_LIMIT_XN, lp.PASS_LIMIT_YN, lp.PASS_LIMIT_ZN, 1.0));
    boxFilter.setMax(Eigen::Vector4f(lp.PASS_LIMIT_XP, lp.PASS_LIMIT_YP, lp.PASS_LIMIT_ZP, 1.0));
    boxFilter.setNegative(true);
    boxFilter.filter(*cloud_filtered_box);

    // cout << cloud_filtered_box->points.size() << endl;

    sensor_msgs::PointCloud2 rosCloud;
    pcl::toROSMsg(*cloud_filtered_box, rosCloud);
    rosCloud.header.frame_id = lp.FRAME_ID_FILTERED;
    os_filtered.publish(rosCloud);

    cloud_filtered_vg.reset(new pcl::PointCloud<pcl::PointXYZI>);
    return cloud_filtered_box;
}

std::vector<pcl::PointIndices> LiDAR_Measure::clustering_function (pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered){
    std::vector<pcl::PointIndices> cluster_indices;
    pcl::search::KdTree<pcl::PointXYZI>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZI>);
    if (cloud_filtered->points.size () > 0) {
        pcl::EuclideanClusterExtraction<pcl::PointXYZI> ec;
        tree->setInputCloud(cloud_filtered);
        ec.setClusterTolerance(lp.EC_TOLERANCE);
        ec.setMinClusterSize(lp.EC_MIN);
        ec.setMaxClusterSize(lp.EC_MAX);
        ec.setSearchMethod(tree);
        ec.setInputCloud(cloud_filtered);
        ec.extract(cluster_indices);
    }
    // free memory
    tree.reset(new pcl::search::KdTree<pcl::PointXYZI>);

    return cluster_indices;
}

void LiDAR_Measure::lidar_detection_function (const pcl::PointCloud<pcl::PointXYZI>::ConstPtr& pcl){
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered = filtering_function(*pcl);
    int points_num = cloud_filtered->points.size ();

    std::vector<pcl::PointIndices> cluster_indices = clustering_function (cloud_filtered);

    int total_point_num = 0;
    for (std::vector<pcl::PointIndices>::const_iterator it1 = cluster_indices.begin (); it1 != cluster_indices.end (); ++it1) {
        total_point_num += it1->indices.size();
    }

    meas_num = cluster_indices.size ();

    int j = 0;
    int valid_cluster_cnt = 0;
    targetPoseArr.data.clear();
    targetPoseArr.data.push_back(float(valid_cluster_cnt));
    targetPoseArr.data.push_back(imu_yaw);
    targetPoseArr.data.push_back(imu_roll);
    targetPoseArr.data.push_back(imu_pitch);

    float max_eigenvalue = 0.0;
    float max_dimension = 0.0;
    Eigen::MatrixXf max_cluster(total_point_num, 3);
    max_cluster.setZero();

    int cnt = 0;
    for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it) {
        int numPoints = it->indices.size();

        if (numPoints == 0){
            continue;
        }else{

            // 1. Change to Eigen Matrix
            Eigen::MatrixXf pcl_matrix(numPoints, 3);
            pcl_matrix.setZero();

            int i = 0;
            pcl::PointCloud<pcl::PointXYZI> clusterCloud;
            for (std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit) {
                pcl::PointXYZI pt = cloud_filtered->points[*pit];
                pt.intensity = (float)(j + 1);
                clusterCloud.push_back(pt);
                
                pcl_matrix(i, 0) = pt.x;
                pcl_matrix(i, 1) = pt.y;
                pcl_matrix(i, 2) = pt.z;

                i++;
            }


            // 2. Check the checklist
            // - Camera FOV (optional)
            // - Eigenvalue Z too small
            // - Cluster Box Height
            // - Back of my Nukhada (optional)
            bool keepCluster = true;
            Eigen::Vector3f com;
            com = pcl_matrix.colwise().mean();

            // Camera FOV
            float dv_theta = - atan(com[0]/(com[1]-lp.TOP_BOARD_WIDTH/2));
            float fov_test = lp.CAM_ALPHA - dv_theta - M_PI/2;
            if (lp.CAM_FOV_FITLER && (0 < fov_test) && (fov_test < -M_PI)){
                keepCluster = false;
            }

            // Eigenvalue Z too small
            Eigen::MatrixXf centered = pcl_matrix.rowwise() - pcl_matrix.colwise().mean();
            Eigen::MatrixXf covariance = (centered.adjoint() * centered) / double(pcl_matrix.rows() - 1);
            Eigen::EigenSolver<Eigen::MatrixXf> solver(covariance);
            Eigen::VectorXf eigenValues = solver.eigenvalues().real();
            Eigen::MatrixXf eigenvectors = solver.eigenvectors().real();

            std::vector<std::pair<float, int>> eigen_pairs(3);
            for (int i = 0; i < 3; ++i) {
                eigen_pairs[i] = std::make_pair(eigenValues[i], i);
            }
            std::sort(eigen_pairs.begin(), eigen_pairs.end(), std::greater<>());

            Eigen::VectorXf sorted_eigenvalues(3);
            Eigen::MatrixXf sorted_eigenvectors(3, 3);
            for (int i = 0; i < 3; ++i) {
                sorted_eigenvalues[i] = eigen_pairs[i].first;
                sorted_eigenvectors.col(i) = eigenvectors.col(eigen_pairs[i].second);
            }

            if (sorted_eigenvalues[2] < 0.005 && std::abs(sorted_eigenvectors(2, 2)) > 0.85) {
                keepCluster = false;
            }
             
            // Cluster Box Height
            Eigen::MatrixXf pcl_matrix_coordinated = (eigenvectors.transpose() * pcl_matrix.transpose()).transpose();
            float height = pcl_matrix_coordinated.col(2).maxCoeff() - pcl_matrix_coordinated.col(2).minCoeff();
            float width = pcl_matrix_coordinated.col(1).maxCoeff() - pcl_matrix_coordinated.col(1).minCoeff();
            float length = pcl_matrix_coordinated.col(0).maxCoeff() - pcl_matrix_coordinated.col(0).minCoeff();
            
            // Biggest Cluster
            // if (sorted_eigenvalues[0] > max_eigenvalue){
            //     max_eigenvalue = sorted_eigenvalues[0];
            //     max_cluster = pcl_matrix;
            //     max_dimension = (width > length) ? width : length;
            //     cout << max_dimension << endl;
            // }

            // Cluster Concatenate
            max_dimension = (width > length) ? width : length;
            if (max_dimension > lp.GROUND_MAX_WIDTH){
                max_cluster.block(cnt, 0, numPoints, 3) = pcl_matrix;
                // cout << "Concatenate" << endl;
            }
            cnt += numPoints;
            
            float cluster_distance = com[0]*com[0] + com[1]*com[1];
            float min_d = 5.0;
            float max_d = 20.0;
            if (cluster_distance < max_d*max_d){
                if (height < (lp.TARGET_TOP_HEIGHT_MAX-lp.TARGET_TOP_HEIGHT_MIN)/((max_d-min_d)*(cluster_distance-min_d)) + lp.TARGET_TOP_HEIGHT_MIN){
                    keepCluster = false;
                }
            }else{
                if (height < lp.TARGET_TOP_HEIGHT_MAX){
                    keepCluster = false;
                }
            }

            // Back of my Nukhada
            double angle_factor = tan(lp.TAIL_ANGLE);
            Eigen::Array<bool, Eigen::Dynamic, 1> mask_P = pcl_matrix_coordinated.col(1).array() < pcl_matrix_coordinated.col(0).array() * angle_factor;
            Eigen::Array<bool, Eigen::Dynamic, 1> mask_N = pcl_matrix_coordinated.col(1).array() > pcl_matrix_coordinated.col(0).array() * angle_factor;
            Eigen::Array<bool, Eigen::Dynamic, 1> mask_P_ = pcl_matrix_coordinated.col(1).array() < -pcl_matrix_coordinated.col(0).array() * angle_factor;

            bool condition1 = (mask_P_ && mask_N).any();
            bool condition2 = (pcl_matrix_coordinated.col(0).array() < 0).any();
            if (lp.TAIL_FILTER && condition1 && condition2) {
                keepCluster = false;
            }

            if (keepCluster){
                valid_cluster_cnt++;

                float width_projected = (pcl_matrix.col(0).maxCoeff()-pcl_matrix.col(0).minCoeff()); // X
                float height_projected = (pcl_matrix.col(2).maxCoeff()-pcl_matrix.col(2).minCoeff()); // Z
                float r1 = width_projected/(2*lp.A_BY_WIDTH*tan(lp.CAM_FOV_HORIZONTAL));
                float r2 = height_projected/(2*lp.B_BY_HEIGHT*tan(lp.CAM_FOV_VERTICAL));
                float minimum_r = (r1 > r2) ? r1 : r2;
                float dv_theta = - atan(com[0]/(com[1]-lp.TOP_BOARD_WIDTH/2));
                float theta = dv_theta - M_PI/2;

                targetPoseArr.data.push_back(com[0]);
                targetPoseArr.data.push_back(com[1]);
                targetPoseArr.data.push_back(com[2]);
                targetPoseArr.data.push_back(atan(sorted_eigenvectors(0, 0)/-sorted_eigenvectors(0, 1)));
                targetPoseArr.data.push_back(minimum_r);
                targetPoseArr.data.push_back(theta);

                *TotalCloud += clusterCloud;
                clusterCloud.clear();
            }
        }

        j++;
    }
    ground_voxels(max_cluster);

    targetPoseArr.data[0] = valid_cluster_cnt;
    target_pose.publish(targetPoseArr);

    sensor_msgs::PointCloud2 rosCloud;
    pcl::toROSMsg(*TotalCloud, rosCloud);
    rosCloud.header.frame_id = lp.FRAME_ID_CLUSTERED;
    os_clustered.publish(rosCloud);

    TotalCloud.reset(new pcl::PointCloud<pcl::PointXYZI>);
}

void LiDAR_Measure::cloud_cb(const sensor_msgs::PointCloud2::ConstPtr& msg){
    start = ros::Time::now();
    pcl::fromROSMsg (*msg, *os_pcl_data);

    /// IMU Time Match
    double curr_lidar_time = msg->header.stamp.toSec();
    int idx = 0;
    bool between = false;
    while ((idx < imu_time_stack.size()) && (1 < imu_time_stack.size())){
        if (imu_time_stack[idx] < curr_lidar_time){
            if (idx != 0){
                imu_time_stack.erase(imu_time_stack.begin());
                imu_quat_stack.erase(imu_quat_stack.begin());
            }
            else idx++;
        }
        else{
            between = true;
            break;
        }
    }

    Eigen::Quaternionf result;
    if(between)
    {
        cout << curr_lidar_time << ", " << imu_time_stack[0] << ", " << imu_time_stack[1] << endl; 
        double t = (curr_lidar_time - imu_time_stack[0])/(imu_time_stack[1] - imu_time_stack[0]);
        result = imu_quat_stack[0].slerp(t, imu_quat_stack[1]);
    }
    else
    {
        cout << curr_lidar_time << ", " << imu_time_stack[0] << endl; 
        Eigen::Quaternionf quat = imu_quat_stack[0];
        Eigen::Vector4f quat_coeffs = quat.coeffs(); // Get current quaternion coeffs
        Eigen::Vector3f pqr = 0.5 * imu_angvel;

        // Quaternion derivative from angular velocity
        Eigen::Vector4f quat_derivative;
        quat_derivative << -quat.x() * pqr(0) - quat.y() * pqr(1) - quat.z() * pqr(2),
                            quat.w() * pqr(0) + quat.z() * pqr(1) - quat.y() * pqr(2),
                            quat.w() * pqr(1) - quat.z() * pqr(0) + quat.x() * pqr(2),
                            quat.w() * pqr(2) + quat.y() * pqr(0) - quat.x() * pqr(1);

        // Update quaternion
        double dt = curr_lidar_time - imu_time_stack[0]; // Your time difference
        Eigen::Vector4f new_quat_coeffs = quat_coeffs + quat_derivative * (float) dt;
        Eigen::Quaternionf new_quat(new_quat_coeffs[3], new_quat_coeffs[0], new_quat_coeffs[1], new_quat_coeffs[2]);
        new_quat = new_quat.normalized();
    }

    curr_eigen_quat = result;
    Eigen::Vector3f euler_angles = curr_eigen_quat.toRotationMatrix().eulerAngles(2, 0, 1); // 2=z, 0=x, 1=y (zxy order)
    imu_yaw = euler_angles[0];
    imu_roll = euler_angles[1];
    imu_pitch = euler_angles[2];

    lidar_detection_function(os_pcl_data);
    std::cout << "LAP - MEASURE: " << ros::Time::now() - start << std::endl;
}

void LiDAR_Measure::imu_cb(const sensor_msgs::Imu::ConstPtr& msg){
    Eigen::Quaternionf eigen_quat(msg->orientation.w, msg->orientation.x, msg->orientation.y, msg->orientation.z);
    imu_quat_stack.push_back(eigen_quat);
    imu_time_stack.push_back(msg->header.stamp.toSec());

    imu_angvel << msg->angular_velocity.x, msg->angular_velocity.y, msg->angular_velocity.z;

    // print(msg->header.stamp.toSec());

    if (!imu_init){
        init_eigen_quat = eigen_quat;
        imu_init = 1;
    }
}

int main(int argc, char **argv){
    ros::init(argc, argv, "lidar_measure");

    LiDAR_Measure lm;

    ros::spin();

    return 0;
}