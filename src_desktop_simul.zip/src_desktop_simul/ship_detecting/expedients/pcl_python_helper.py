#!/usr/bin/python3

import rospy
import pcl
import ctypes
import struct
import numpy as np
from random import randint
import sensor_msgs.point_cloud2 as pc2
from scipy.spatial.transform import Rotation
from geometry_msgs.msg import PolygonStamped, Point32
from sensor_msgs.msg import PointCloud2, PointField

def ros_to_pcl_I(msg):
    point_step = msg.point_step # get stride between points in bytes
    length = len(msg.data)
    
    # Assuming you have the correct offsets for 'z' and 'intensity'
    x_offset = 0
    y_offset = 4
    z_offset = 8 # Example offset, adjust as per actual offset
    intensity_offset = 16 # Adjust as per actual offset
    
    x_format = "f" # 32-bit float
    y_format = "f" # 32-bit float
    z_format = "f" # 32-bit float
    intensity_format = "f" # 32-bit float
    
    points_list = []
    for i in range(0, length, point_step):
        # Adjust offsets for each point
        x_data = msg.data[i + x_offset: i + x_offset + 4]
        y_data = msg.data[i + y_offset: i + y_offset + 4]
        z_data = msg.data[i + z_offset: i + z_offset + 4]
        intensity_data = msg.data[i + intensity_offset: i + intensity_offset + 4]
        
        x = struct.unpack(x_format, x_data)[0]
        y = struct.unpack(y_format, y_data)[0]
        z = struct.unpack(z_format, z_data)[0]
        intensity = struct.unpack(intensity_format, intensity_data)[0]

        points_list.append([x, y, z, intensity])

    pcl_data = pcl.PointCloud_PointXYZRGB()
    pcl_data.from_list(points_list)

    return pcl_data

def ros_to_pcl(ros_cloud):
    """ Converts a ROS PointCloud2 message to a pcl PointXYZRGB
    
        Args:
            ros_cloud (PointCloud2): ROS PointCloud2 message
            
        Returns:
            pcl.PointCloud_PointXYZRGB: PCL XYZRGB point cloud
    """
    points_list = []

    for data in pc2.read_points(ros_cloud, skip_nans=True):
        points_list.append([data[0], data[1], data[2], data[3]])

    pcl_data = pcl.PointCloud_PointXYZRGB()
    pcl_data.from_list(points_list)

    return pcl_data

def pcl_to_ros(pcl_data, frame_id="base_link"):
    """ Converts a pcl PointXYZRGB to a ROS PointCloud2 message
    
        Args:
            pcl_array (PointCloud_PointXYZRGB): A PCL XYZRGB point cloud
            
        Returns:
            PointCloud2: A ROS point cloud
    """
    ros_msg = PointCloud2()

    ros_msg.header.stamp = rospy.Time.now()
    ros_msg.header.frame_id = frame_id

    ros_msg.height = 1
    ros_msg.width = pcl_data.size

    ros_msg.fields.append(PointField(
                            name="x",
                            offset=0,
                            datatype=PointField.FLOAT32, count=1))
    ros_msg.fields.append(PointField(
                            name="y",
                            offset=4,
                            datatype=PointField.FLOAT32, count=1))
    ros_msg.fields.append(PointField(
                            name="z",
                            offset=8,
                            datatype=PointField.FLOAT32, count=1))
    ros_msg.fields.append(PointField(
                            name="rgb",
                            offset=16,
                            datatype=PointField.FLOAT32, count=1))

    ros_msg.is_bigendian = False
    ros_msg.point_step = 32
    ros_msg.row_step = ros_msg.point_step * ros_msg.width * ros_msg.height
    ros_msg.is_dense = False
    buffer = []

    for data in pcl_data:
        s = struct.pack('>f', data[3])
        i = struct.unpack('>l', s)[0]
        pack = ctypes.c_uint32(i).value

        r = (pack & 0x00FF0000) >> 16
        g = (pack & 0x0000FF00) >> 8
        b = (pack & 0x000000FF)

        buffer.append(struct.pack('ffffBBBBIII', data[0], data[1], data[2], 1.0, b, g, r, 0, 0, 0, 0))

    ros_msg.data = b"".join(buffer)

    return ros_msg

def pcl_to_numpy(pcl_data):
    np_array = []
    for data in pcl_data:
        x, y, z, i = data
        np_array.append([x, y, z, i])

    return np.asarray(np_array)
        
def XYZRGB_to_XYZ(XYZRGB_cloud):
    """ Converts a PCL XYZRGB point cloud to an XYZ point cloud (removes color info)
    
        Args:
            XYZRGB_cloud (PointCloud_PointXYZRGB): A PCL XYZRGB point cloud
            
        Returns:
            PointCloud_PointXYZ: A PCL XYZ point cloud
    """
    XYZ_cloud = pcl.PointCloud()
    points_list = []

    for data in XYZRGB_cloud:
        points_list.append([data[0], data[1], data[2]])

    XYZ_cloud.from_list(points_list)
    return XYZ_cloud

def XYZ_to_XYZRGB(XYZ_cloud, color):
    """ Converts a PCL XYZ point cloud to a PCL XYZRGB point cloud
    
        All returned points in the XYZRGB cloud will be the color indicated
        by the color parameter.
    
        Args:
            XYZ_cloud (PointCloud_XYZ): A PCL XYZ point cloud
            color (list): 3-element list of integers [0-255,0-255,0-255]
            
        Returns:
            PointCloud_PointXYZRGB: A PCL XYZRGB point cloud
    """
    XYZRGB_cloud = pcl.PointCloud_PointXYZRGB()
    points_list = []

    float_rgb = rgb_to_float(color)

    for data in XYZ_cloud:
        points_list.append([data[0], data[1], data[2], float_rgb])

    XYZRGB_cloud.from_list(points_list)
    return XYZRGB_cloud

def random_color_gen():
    """ Generates a random color
    
        Args: None
        
        Returns: 
            list: 3 elements, R, G, and B
    """
    r = randint(0, 255)
    g = randint(0, 255)
    b = randint(0, 255)
    return [r, g, b]

def rgb_to_float(color):
    """ Converts an RGB list to the packed float format used by PCL
    
        From the PCL docs:
        "Due to historical reasons (PCL was first developed as a ROS package),
         the RGB information is packed into an integer and casted to a float"
    
        Args:
            color (list): 3-element list of integers [0-255,0-255,0-255]
            
        Returns:
            float_rgb: RGB value packed as a float
    """
    hex_r = (0xff & color[0]) << 16
    hex_g = (0xff & color[1]) << 8
    hex_b = (0xff & color[2])

    hex_rgb = hex_r | hex_g | hex_b

    float_rgb = struct.unpack('f', struct.pack('i', hex_rgb))[0]

    return float_rgb

def float_to_rgb(float_rgb):
    """ Converts a packed float RGB format to an RGB list    
        
        Args:
            float_rgb: RGB value packed as a float
            
        Returns:
            color (list): 3-element list of integers [0-255,0-255,0-255]
    """
    s = struct.pack('>f', float_rgb)
    i = struct.unpack('>l', s)[0]
    pack = ctypes.c_uint32(i).value
			
    r = (pack & 0x00FF0000) >> 16
    g = (pack & 0x0000FF00) >> 8
    b = (pack & 0x000000FF)
			
    color = [r,g,b]
			
    return color

class lidar_prop():
    def __init__(self):
        rospy.init_node(rospy.get_param('/MEASURE_NODE', "-"))
        
        self.IMU_ = rospy.get_param('/IMU_', "-")
        self.OS_CLUSTERED = rospy.get_param('/OS_CLUSTERED', "-")
        self.OS_FILTERED = rospy.get_param('/OS_FILTERED', "-")
        self.SHIP_BOX_FILTER = rospy.get_param('/SHIP_BOX_FILTER', "-")
        self.TARGET_POLYGONS_ = rospy.get_param('/TARGET_POLYGONS_', "-")
        self.TARGET_POSES_ = rospy.get_param('/TARGET_POSES_', "-")
        self.OS_COMBINED_ = rospy.get_param('/OS_COMBINED_', "-")
        self.TOP_BOARD_WIDTH = rospy.get_param('/TOP_BOARD_WIDTH', 0)
        self.CAM_ALPHA = rospy.get_param('/CAM_ALPHA', 0)
        self.TARGET_TOP_HEIGHT_P = rospy.get_param('/TARGET_TOP_HEIGHT_P', 0)
        self.TARGET_TOP_HEIGHT_N = rospy.get_param('/TARGET_TOP_HEIGHT_N', 0)
        self.GLOBAL_Z_FILTER = rospy.get_param('/GLOBAL_Z_FILTER', False)
        self.LIDAR_TILT_BIAS = rospy.get_param('/LIDAR_TILT_BIAS', 0)
        self.PCL_GROUND_Z_BOUND = rospy.get_param('/PCL_GROUND_Z_BOUND', 0)
        self.FRAME_ID = rospy.get_param('/FRAME_ID', "-")
        self.CAM_FOV_HORIZONTAL = rospy.get_param('/CAM_FOV_HORIZONTAL', 0)
        self.CAM_FOV_VERTICAL = rospy.get_param('/CAM_FOV_VERTICAL', 0)
        self.A_BY_WIDTH = rospy.get_param('/A_BY_WIDTH', 0)
        self.B_BY_HEIGHT = rospy.get_param('/B_BY_HEIGHT', 0)
        self.PASS_LIMIT_XP = rospy.get_param('/PASS_LIMIT_XP', 0)
        self.PASS_LIMIT_XN = rospy.get_param('/PASS_LIMIT_XN', 0)
        self.PASS_LIMIT_YP = rospy.get_param('/PASS_LIMIT_YP', 0)
        self.PASS_LIMIT_YN = rospy.get_param('/PASS_LIMIT_YN', 0)
        self.PASS_LIMIT_ZP = rospy.get_param('/PASS_LIMIT_ZP', 0)
        self.PASS_LIMIT_ZN = rospy.get_param('/PASS_LIMIT_ZN', 0)
        self.DENOISE = rospy.get_param('/DENOISE', 0)
        self.MEAN_K = rospy.get_param('/MEAN_K', 0)
        self.THRESH = rospy.get_param('/THRESH', 0)
        self.LOG_SCALE = rospy.get_param('/LOG_SCALE', False)
        self.EC_TOLERANCE = rospy.get_param('/EC_TOLERANCE', 0)
        self.EC_MIN_SIZE = rospy.get_param('/EC_MIN_SIZE', 0)
        self.EC_MAX_SIZE = rospy.get_param('/EC_MAX_SIZE', 0)
        self.VG_SIZE_X = rospy.get_param('/VG_SIZE_X', 0)
        self.VG_SIZE_Y = rospy.get_param('/VG_SIZE_Y', 0)
        self.VG_SIZE_Z = rospy.get_param('/VG_SIZE_Z', 0)
        self.box_filter_visualizer()

    def box_filter_visualizer(self):
        box_filter_pub = rospy.Publisher(self.SHIP_BOX_FILTER, PolygonStamped, queue_size=1)
        ########################## Box Visualization Publisher ######################
        box_filter_viz = PolygonStamped()
        box_filter_viz.header.frame_id = self.FRAME_ID
        box_filter_corner1 = Point32(); box_filter_corner2 = Point32(); box_filter_corner3 = Point32(); box_filter_corner4 = Point32()
        box_filter_corner5 = Point32(); box_filter_corner6 = Point32(); box_filter_corner7 = Point32(); box_filter_corner8 = Point32()
        box_filter_corner2.x = self.PASS_LIMIT_XN; box_filter_corner2.y = self.PASS_LIMIT_YN; box_filter_corner2.z = self.PASS_LIMIT_ZP
        box_filter_corner1.x = self.PASS_LIMIT_XN; box_filter_corner1.y = self.PASS_LIMIT_YN; box_filter_corner1.z = self.PASS_LIMIT_ZN
        box_filter_corner3.x = self.PASS_LIMIT_XN; box_filter_corner3.y = self.PASS_LIMIT_YP; box_filter_corner3.z = self.PASS_LIMIT_ZN
        box_filter_corner4.x = self.PASS_LIMIT_XN; box_filter_corner4.y = self.PASS_LIMIT_YP; box_filter_corner4.z = self.PASS_LIMIT_ZP
        box_filter_corner5.x = self.PASS_LIMIT_XP; box_filter_corner5.y = self.PASS_LIMIT_YN; box_filter_corner5.z = self.PASS_LIMIT_ZN
        box_filter_corner6.x = self.PASS_LIMIT_XP; box_filter_corner6.y = self.PASS_LIMIT_YN; box_filter_corner6.z = self.PASS_LIMIT_ZP
        box_filter_corner7.x = self.PASS_LIMIT_XP; box_filter_corner7.y = self.PASS_LIMIT_YP; box_filter_corner7.z = self.PASS_LIMIT_ZN
        box_filter_corner8.x = self.PASS_LIMIT_XP; box_filter_corner8.y = self.PASS_LIMIT_YP; box_filter_corner8.z = self.PASS_LIMIT_ZP
        box_filter_viz.polygon.points.append(box_filter_corner1); box_filter_viz.polygon.points.append(box_filter_corner2)
        box_filter_viz.polygon.points.append(box_filter_corner4); box_filter_viz.polygon.points.append(box_filter_corner3)
        box_filter_viz.polygon.points.append(box_filter_corner1); box_filter_viz.polygon.points.append(box_filter_corner5)
        box_filter_viz.polygon.points.append(box_filter_corner6); box_filter_viz.polygon.points.append(box_filter_corner8)
        box_filter_viz.polygon.points.append(box_filter_corner7); box_filter_viz.polygon.points.append(box_filter_corner5)
        box_filter_viz.polygon.points.append(box_filter_corner6); box_filter_viz.polygon.points.append(box_filter_corner2)
        box_filter_viz.polygon.points.append(box_filter_corner4); box_filter_viz.polygon.points.append(box_filter_corner8)
        box_filter_viz.polygon.points.append(box_filter_corner7); box_filter_viz.polygon.points.append(box_filter_corner3)
        box_filter_pub.publish(box_filter_viz)

    def obbox_publisher(self, eigenvectors, com, length, width, height):
        self.obboxes.header.frame_id = self.FRAME_ID
        obbox_temp = PolygonStamped()
        obbox_temp.header.frame_id = self.FRAME_ID
        crn1 = Point32();crn2 = Point32();crn3 = Point32();crn4 = Point32()
        crn5 = Point32();crn6 = Point32();crn7 = Point32();crn8 = Point32()
        eigvec_0_2D = np.asarray([eigenvectors[:,0][0],eigenvectors[:,0][1],0.0]); eigvec_0_2D = eigvec_0_2D / np.linalg.norm(eigvec_0_2D)
        eigvec_1_2D = Rotation.from_euler('z', 90, degrees=True).as_matrix()@eigvec_0_2D; eigvec_1_2D = eigvec_1_2D / np.linalg.norm(eigvec_1_2D)
        eigvec_2_2D = np.asarray([0.0,0.0,0.1])
        crn2.x, crn2.y, crn2.z = com - length//2*eigvec_0_2D - width//2*eigvec_1_2D + height//2*eigvec_2_2D
        crn3.x, crn3.y, crn3.z = com - length//2*eigvec_0_2D + width//2*eigvec_1_2D - height//2*eigvec_2_2D
        crn4.x, crn4.y, crn4.z = com - length//2*eigvec_0_2D + width//2*eigvec_1_2D + height//2*eigvec_2_2D
        crn1.x, crn1.y, crn1.z = com - length//2*eigvec_0_2D - width//2*eigvec_1_2D - height//2*eigvec_2_2D
        crn5.x, crn5.y, crn5.z = com + length//2*eigvec_0_2D - width//2*eigvec_1_2D - height//2*eigvec_2_2D
        crn6.x, crn6.y, crn6.z = com + length//2*eigvec_0_2D - width//2*eigvec_1_2D + height//2*eigvec_2_2D
        crn7.x, crn7.y, crn7.z = com + length//2*eigvec_0_2D + width//2*eigvec_1_2D - height//2*eigvec_2_2D
        crn8.x, crn8.y, crn8.z = com + length//2*eigvec_0_2D + width//2*eigvec_1_2D + height//2*eigvec_2_2D
        obbox_temp.polygon.points.append(crn1); obbox_temp.polygon.points.append(crn2)
        obbox_temp.polygon.points.append(crn4); obbox_temp.polygon.points.append(crn3)
        obbox_temp.polygon.points.append(crn1); obbox_temp.polygon.points.append(crn5)
        obbox_temp.polygon.points.append(crn6); obbox_temp.polygon.points.append(crn8)
        obbox_temp.polygon.points.append(crn7); obbox_temp.polygon.points.append(crn5)
        obbox_temp.polygon.points.append(crn6); obbox_temp.polygon.points.append(crn2)
        obbox_temp.polygon.points.append(crn4); obbox_temp.polygon.points.append(crn8)
        obbox_temp.polygon.points.append(crn7); obbox_temp.polygon.points.append(crn3)

        return obbox_temp