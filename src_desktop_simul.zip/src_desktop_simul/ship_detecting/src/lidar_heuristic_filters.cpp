// Custom functions to filter out the non-ROI clusters

#include "lidar_params.hpp"

bool cam_fov_filter(Eigen::Vector3f com, float TOP_BOARD_WIDTH, float CAM_ALPHA){
    float dv_theta = - atan(com[0]/(com[1]-TOP_BOARD_WIDTH/2));
    float fov_test = CAM_ALPHA - dv_theta - M_PI/2;

    if ((0 < fov_test) && (fov_test < -M_PI)){
        return false;
    }else{
        return true;
    }
}

bool lettuce_filter(Eigen::VectorXf eigenvalues, Eigen::MatrixXf eigenvectors, float z_eigen_criterion){
    std::vector<std::pair<float, int>> eigen_pairs(3);
    for (int i = 0; i < 3; ++i) {
        eigen_pairs[i] = std::make_pair(eigenvalues[i], i);
    }
    std::sort(eigen_pairs.begin(), eigen_pairs.end(), std::greater<>());

    Eigen::VectorXf sorted_eigenvalues(3);
    Eigen::MatrixXf sorted_eigenvectors(3, 3);
    for (int i = 0; i < 3; ++i) {
        sorted_eigenvalues[i] = eigen_pairs[i].first;
        sorted_eigenvectors.col(i) = eigenvectors.col(eigen_pairs[i].second);
    }

    if (sorted_eigenvalues[2] < z_eigen_criterion && std::abs(sorted_eigenvectors(2, 2)) > 0.85) {
        return false;
    }else{
        return true;
    }
}

bool max_height_filter( Eigen::MatrixXf cluster_matrix_coordinated,
                        Eigen::Vector3f com,
                        float TARGET_TOP_HEIGHT_MIN,
                        float TARGET_TOP_HEIGHT_MAX){
    float height = cluster_matrix_coordinated.col(2).maxCoeff() - cluster_matrix_coordinated.col(2).minCoeff();
    
    float cluster_distance = com[0]*com[0] + com[1]*com[1];
    float min_d = 5.0;
    float max_d = 20.0;

    if (cluster_distance < max_d*max_d){
        if (height < (TARGET_TOP_HEIGHT_MAX-TARGET_TOP_HEIGHT_MIN)/((max_d-min_d)*(cluster_distance-min_d)) + TARGET_TOP_HEIGHT_MIN){
            return false;
        }else{
            return true;
        }
    }else{
        if (height < TARGET_TOP_HEIGHT_MAX){
            return false;
        }else{
            return true;
        }
    }
}

bool nukhada_tail_filter(Eigen::MatrixXf cluster_matrix_coordinated, float TAIL_ANGLE){
    double angle_factor = tan(TAIL_ANGLE);
    Eigen::Array<bool, Eigen::Dynamic, 1> mask_P = cluster_matrix_coordinated.col(1).array() < cluster_matrix_coordinated.col(0).array() * angle_factor;
    Eigen::Array<bool, Eigen::Dynamic, 1> mask_N = cluster_matrix_coordinated.col(1).array() > cluster_matrix_coordinated.col(0).array() * angle_factor;
    Eigen::Array<bool, Eigen::Dynamic, 1> mask_P_ = cluster_matrix_coordinated.col(1).array() < -cluster_matrix_coordinated.col(0).array() * angle_factor;

    bool condition1 = (mask_P_ && mask_N).any();
    bool condition2 = (cluster_matrix_coordinated.col(0).array() < 0).any();
    if (condition1 && condition2) {
        return false;
    }else{
        return true;
    }
}