#!/usr/bin/python3

import rospy
import numpy as np
import pcl
import math
from scipy.spatial.transform import Rotation
from std_msgs.msg import Float32MultiArray
from sensor_msgs.msg import PointCloud2, Imu
from jsk_recognition_msgs.msg import PolygonArray
import pcl_python_helper as ph

class PCL_Handler(ph.lidar_prop):
    def __init__(self):
        super().__init__()
        
        self.imu_yaw = 0.0
        self.imu_roll = 0.0
        self.imu_pitch = 0.0

        # Dummy ROSmsg to publish
        self.clustered = PointCloud2()
        self.filtered = PointCloud2()
        self.target_pose = Float32MultiArray()
        self.obboxes = PolygonArray()

        # ROSTOPICs pub/sub
        self.output_pub = rospy.Publisher(self.OS_CLUSTERED, PointCloud2, queue_size=1)
        self.filtered_pub = rospy.Publisher(self.OS_FILTERED, PointCloud2, queue_size=1)
        self.obbox_pub = rospy.Publisher(self.TARGET_POLYGONS_, PolygonArray, queue_size=1)
        self.target_pose_pub = rospy.Publisher(self.TARGET_POSES_, Float32MultiArray, queue_size=1)

        self.imu_sub = rospy.Subscriber(self.IMU_, Imu, self.imu_update)
        self.lidar_sub = rospy.Subscriber(self.OS_COMBINED_, PointCloud2, self.cloud_cb)
    
    def imu_update(self, data):
        r = Rotation.from_quat([data.orientation.x, data.orientation.y, data.orientation.z, data.orientation.w])
        self.imu_yaw, self.imu_roll, self.imu_pitch = r.as_euler('zxy', degrees=False)

    def measuring(self, cluster_n_nparr):

        cloud_arr_3d = (cluster_n_nparr[:,0:3].T).T
        com = np.sum(cloud_arr_3d, axis=0) / len(cloud_arr_3d)
        dv_theta = - math.atan(com[0]/(com[1]-self.TOP_BOARD_WIDTH/2))
        com_position_test = self.CAM_ALPHA - dv_theta - math.pi/2

        # IF THE CLUSTER IS NOT IN THE CAMERA FOV
        # if 0 < com_position_test or com_position_test < -math.pi:
        #     return "CSBD" # Cluster Should Be Deleted

        # cloud_arr_3d_projected = cloud_arr_3d.copy()
        # cloud_arr_3d_projected[:,2] = 0.0
        # com_projected = com.copy()
        # com_projected[2] = 0.0

        cov_matrix_3d = np.cov((cloud_arr_3d - com), rowvar=False)
        eigenvalues, eigenvectors = np.linalg.eig(cov_matrix_3d)
        idx = eigenvalues.argsort()[::-1]   
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:,idx]
        
        if eigenvalues[2] < 0.005 and abs(eigenvectors[2,2]) > 0.85:
           return "CSBD"


        # cov_matrix_2d = np.cov((cloud_arr_3d - com)[:,:2], rowvar=False)
        # eigenvalues_2d, eigenvectors_2d = np.linalg.eig(cov_matrix_2d)
        # idx_2d = eigenvalues_2d.argsort()[::-1]   
        # eigenvalues_2d = eigenvalues_2d[idx_2d]
        # eigenvectors_2d = eigenvectors_2d[:,idx_2d]

        # 3D Point Cloud size
        width_projected = (np.max(cloud_arr_3d[:,0])-np.min(cloud_arr_3d[:,0])) # X
        height_projected = (np.max(cloud_arr_3d[:,2])-np.min(cloud_arr_3d[:,2])) # Z

        # Target Box Height Check
        cloud_arr_coordinated = (eigenvectors.T @ cloud_arr_3d.T).T
        length = (np.max(cloud_arr_coordinated[:,0])-np.min(cloud_arr_coordinated[:,0]))
        width = (np.max(cloud_arr_coordinated[:,1])-np.min(cloud_arr_coordinated[:,1]))
        height = (np.max(cloud_arr_coordinated[:,2])-np.min(cloud_arr_coordinated[:,2]))

        # Cluster Height Filter
        cluster_distance = np.linalg.norm(com[0:2])
        min_d = 5
        max_d = 20
        if cluster_distance < max_d:
            if height < (self.TARGET_TOP_HEIGHT_P - self.TARGET_TOP_HEIGHT_N) / (max_d - min_d) * (cluster_distance - min_d) + self.TARGET_TOP_HEIGHT_N:
                return "CSBD" # Cluster Should Be Deleted
        else:
            if height < self.TARGET_TOP_HEIGHT_P:
                return "CSBD" # Cluster Should Be Deleted
            
        # # Back of my Nukhada Filter
        # mask_P = cloud_arr_coordinated[:,1] < cloud_arr_coordinated[:,0]/np.sqrt(3)
        # mask_N = cloud_arr_coordinated[:,1] > cloud_arr_coordinated[:,0]/np.sqrt(3)
        # mask_P_ = cloud_arr_coordinated[:,1] < -cloud_arr_coordinated[:,0]/np.sqrt(3)

        # if np.any(np.logical_and(mask_P_ , mask_N)) and np.any(cloud_arr_coordinated[:,0] < 0):
        #     return "CSBD"
        
        # # Wake linear
        # if np.logical_and(np.any(cloud_arr_coordinated[:,0] < 0), np.logical_and(np.any(cloud_arr_coordinated[:,1] < 0), np.any(cloud_arr_coordinated[:,1] > 0))):
        #     return "CSBD"

        # Cluster Z Position Filter
        if self.GLOBAL_Z_FILTER:
            imu_rotation_matrix = ((Rotation.from_euler("ZYX", [self.imu_yaw, self.imu_pitch, self.imu_roll], degrees=True)).as_matrix())
            cloud_globalized = (imu_rotation_matrix @ cloud_arr_3d.T).T
            if np.max(cloud_globalized[:,2]) < (cluster_distance*np.sin(self.LIDAR_TILT_BIAS/180*np.pi) - self.PCL_GROUND_Z_BOUND):
                return "CSBD" # Cluster Should Be Deleted
    
        obbox_temp = self.obbox_publisher(eigenvectors, com, length, width, height)
        self.obboxes.polygons.append(obbox_temp)

        plane_v = eigenvectors.T[np.argmax(eigenvalues)] # Extract the eigenvector of the minimum eigenvalue
        theta = dv_theta - math.pi/2

        r1 = width_projected/(2*self.A_BY_WIDTH*math.tan(self.CAM_FOV_HORIZONTAL))
        r2 = height_projected/(2*self.B_BY_HEIGHT*math.tan(self.CAM_FOV_VERTICAL))
        minimum_r = r1 if r1 > r2 else r2

        target_heading = np.arctan(eigenvectors[:,0][0]/eigenvectors[:,0][1])
        self.target_pose.data.append(com[0])
        self.target_pose.data.append(com[1])
        self.target_pose.data.append(com[2])
        self.target_pose.data.append(target_heading)
        self.target_pose.data.append(minimum_r)
        self.target_pose.data.append(theta)
        
        # print("[Ship Detected] Heading: {} | {} Deg".format(target_heading, target_heading*180/math.pi))

        return "CIP" # Cluster is Promising

    def crop_box_filter(self, pcl_data):
        nmp_data = np.asarray(pcl_data)

        # Mask 1: X/Y Box-Inside
        mask_xy = np.logical_and(
                                np.logical_and(nmp_data[:,0]>self.PASS_LIMIT_XN, nmp_data[:,0]<self.PASS_LIMIT_XP),
                                np.logical_and(nmp_data[:,1]>self.PASS_LIMIT_YN, nmp_data[:,1]<self.PASS_LIMIT_YP))
        
        # Mask 2: Z too high/low
        mask_z = np.logical_or(nmp_data[:,2]>self.PASS_LIMIT_ZP, nmp_data[:,2]<self.PASS_LIMIT_ZN)

        nmp_data[np.logical_or(mask_xy, mask_z)] = 0.0
        nmp_data = nmp_data[np.any(nmp_data != [0.,0.,0.,0.], axis=1)]
        
        filtered_cloud = pcl.PointCloud_PointXYZRGB()
        filtered_cloud.from_array(nmp_data)
        return filtered_cloud


    def clustering_function(self, cloud_filtered):

        cloud_filtered_projection = np.asarray(cloud_filtered).copy()[:,0:3]
        cloud_filtered_projection[:,2] = 0.0
        cloud_dist2 = np.square(cloud_filtered_projection[:,0]) + np.square(cloud_filtered_projection[:,1])
        cloud_dist = np.sqrt(cloud_dist2)
        cloud_ln = np.log(cloud_dist)
        cloud_filtered_projection[:,0:2] = cloud_filtered_projection[:,0:2] * (cloud_ln / cloud_dist).reshape(-1,1)

        ec_cloud_set = pcl.PointCloud()
        ec_cloud_set.from_array(cloud_filtered_projection)
        tree = ec_cloud_set.make_kdtree()
        ec = ec_cloud_set.make_EuclideanClusterExtraction()
        ec.set_ClusterTolerance(self.EC_TOLERANCE)
        ec.set_MinClusterSize(self.EC_MIN_SIZE)
        ec.set_MaxClusterSize(self.EC_MAX_SIZE)
        ec.set_SearchMethod(tree)
        cluster_indices = ec.Extract()
        
        return cluster_indices

    def filtering_function(self, point_cloud2_msg):

        # Step 1 - Voxel Grid Filter
        vox_cloud = ph.ros_to_pcl(point_cloud2_msg)
        vox = vox_cloud.make_voxel_grid_filter()
        vox.set_leaf_size(self.VG_SIZE_X, self.VG_SIZE_Y, self.VG_SIZE_Z)
        vox_cloud = vox.filter()

        # Step 2 - Box Filter
        box_cloud = self.crop_box_filter(vox_cloud)

        # Step 3 - Denoise
        denoised_cloud = ph.XYZRGB_to_XYZ(box_cloud)
        if self.DENOISE:
            outlier_filter = denoised_cloud.make_statistical_outlier_filter()
            outlier_filter.set_mean_k(self.MEAN_K)
            outlier_filter.set_std_dev_mul_thresh(self.THRESH)
            denoised_cloud = outlier_filter.filter()

        # Step 4 - Log Scale
        if self.LOG_SCALE:
            cloud_filtered_projection = np.asarray(denoised_cloud).copy()[:,0:3]
            cloud_filtered_projection[:,2] = 0.0
            cloud_dist2 = np.square(cloud_filtered_projection[:,0]) + np.square(cloud_filtered_projection[:,1])
            cloud_dist = np.sqrt(cloud_dist2)
            cloud_ln = np.log(cloud_dist)
            cloud_filtered_projection[:,0:2] = cloud_filtered_projection[:,0:2] * (cloud_ln / cloud_dist).reshape(-1,1)
            denoised_cloud = ph.XYZ_to_XYZRGB(cloud_filtered_projection, ph.random_color_gen())
        else:
            denoised_cloud = ph.XYZ_to_XYZRGB(denoised_cloud, ph.random_color_gen())

        return denoised_cloud
    
    def measure_postprocessing(self, point_cloud2_msg):
        ##### Filtered Point Cloud Publish ##################################
        cloud_filtered = self.filtering_function(point_cloud2_msg)
        self.filtered = ph.pcl_to_ros(cloud_filtered, frame_id=self.FRAME_ID)
        self.filtered_pub.publish(self.filtered)

        if cloud_filtered.size == 0:
            pass
        else:
            cluster_indices = self.clustering_function(cloud_filtered)

            whole_clustered_nparr = None
            cloud_clustered = np.asarray(cloud_filtered)
            self.target_pose.data = [0] # Initialize the rosmsg
            self.target_pose.data.append(self.imu_yaw)
            self.target_pose.data.append(self.imu_roll)
            self.target_pose.data.append(self.imu_pitch)
            cnt_valid_cluster = 0
            for j, indices in enumerate(cluster_indices):
                cloud_clustered[indices,3] = (j+1)
                measuring_result = self.measuring(cloud_clustered[indices])
                if measuring_result == "CIP":
                    if whole_clustered_nparr is None:

                        whole_clustered_nparr = cloud_clustered[indices]
                    else:
                        whole_clustered_nparr = np.vstack((whole_clustered_nparr, cloud_clustered[indices]))
                    cnt_valid_cluster += 1
                elif measuring_result == "CSBD":
                    pass

            if whole_clustered_nparr is not None:
                ##### Clustered Point Cloud (with Intensity difference) Publish #####
                whole_clustered_pcl = pcl.PointCloud_PointXYZRGB()
                whole_clustered_pcl.from_array(whole_clustered_nparr)
                whole_clustered_msg = ph.pcl_to_ros(whole_clustered_pcl, frame_id=self.FRAME_ID)
                self.output_pub.publish(whole_clustered_msg)
            else:
                empty_pcl = pcl.PointCloud_PointXYZRGB()
                empty_msg = ph.pcl_to_ros(empty_pcl, frame_id=self.FRAME_ID)
                self.output_pub.publish(empty_msg)

            ##### Bounding Boxes for all clusters Publish #######################
            self.obbox_pub.publish(self.obboxes)
            self.obboxes.polygons.clear()

            ##### Target Poses for all clusters Publish #########################
            self.target_pose.data[0] = cnt_valid_cluster
            self.target_pose_pub.publish(self.target_pose)
            self.target_pose.data.clear()

        print("LAP - Measure:", rospy.Time.now().to_sec() - self.start)
        print("---------------------------------------------------")

    def cloud_cb(self, point_cloud2_msg):
        self.start = rospy.Time.now().to_sec()
        self.measure_postprocessing(point_cloud2_msg)

if __name__ == "__main__":
    try:
        # ph.box_filter_visualizer()
        pcl_handler = PCL_Handler()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
