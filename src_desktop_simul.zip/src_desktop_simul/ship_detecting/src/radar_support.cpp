// Functions to provide useful pointcloud information for radar-based algorithms
// - ex1) Detect the ground (or wall structure at the start point) and give its position & shape 
// - ex2) For the clusters are detected, tell the specific yaw angles where the radar occlusion happens

#include "lidar_params.hpp"
LiDAR_Params lp;

#include <sensor_msgs/image_encodings.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/core/eigen.hpp>
#include <opencv2/opencv.hpp>

ros::Time start;
ros::Publisher occlusion_bin_pub;
std_msgs::Int16MultiArray occlusion_bin_msg;
pcl::PointCloud<pcl::PointXYZ>::Ptr os_clustered_pcl(new pcl::PointCloud<pcl::PointXYZ>);

// void callback(const sensor_msgs::ImageConstPtr& msg){
//     cout << msg->width << "," << msg->height << endl;

//     std::vector<int> bin_vector(msg->width);
//     for (uint32_t j = 0; j < msg->width; ++j){
//         int occlusion = 0;
//         for (uint32_t i = 0; i < (msg->height/2); ++i){
//             int index = i * msg->step + j; // Calculate the correct index
//             if (msg->data[index]){
//                 occlusion++;
//             }
//         }
//         bin_vector[j] = occlusion;
//         cout << occlusion << " ";
//     }
//     cout << endl;
// }

void radar_occlusion(const sensor_msgs::PointCloud2::ConstPtr& msg){
    // cout << "radar_occlusion" << endl;

    int point_step = msg->point_step;
    int data_length = msg->data.size();
    int num_points = point_step == 0 ? 0 : data_length / point_step;

    // cout << num_points << endl;

    if (num_points > 0){

        // cout << "In Loop" << endl;
        pcl::fromROSMsg (*msg, *os_clustered_pcl);
        std::vector<int> occlusion_bin(lp.RADAR_OCC_binnum, 0);
        for (auto& point : os_clustered_pcl->points) {

            float pt_x = point.x;
            float pt_y = point.y;
            float pt_z = point.z;

            // std::cout << "Point: " << pt_x << ", " << pt_y << ", " << pt_z << ", " << pt_intensity << std::endl;

            float theta = 0.0;
            float bin_size = 2*M_PI/lp.RADAR_OCC_binnum;

            if ((pt_x*pt_x + pt_y*pt_y < lp.RADAR_OCC_d*lp.RADAR_OCC_d) && (pt_z > lp.RADAR_OCC_h)){
                
                theta = atan2(pt_y, pt_x);
                if (theta < 0) {
                    theta += 2 * M_PI;
                }

                occlusion_bin[int(theta/bin_size)] = 1;

                // cout << "Theta: " << theta << endl;
                // cout << "Allocated BIN: " << int(theta/bin_size) << endl;
            }else{
                // cout << "No Occlusion" << endl;
            }
        }

        occlusion_bin_msg.data.clear();
        for (int i=0;i<lp.RADAR_OCC_binnum;i++){
            occlusion_bin_msg.data.push_back(occlusion_bin[i]);
        }

        int sum = count(occlusion_bin.begin(), occlusion_bin.end(), 1);
        cout << "Radar Occlusion Bin #: " << sum << endl;
        occlusion_bin_pub.publish(occlusion_bin_msg);
    }
}

int main(int argc, char **argv){
    ros::init(argc, argv, "radar_support");
    ros::NodeHandle n;


    lp = load_lidar_prop(n);

    occlusion_bin_pub = n.advertise<std_msgs::Int16MultiArray>(lp.RADAR_OCC_BIN, 1);

    ros::Subscriber sub_clustered = n.subscribe(lp.OS_CLUSTERED, 1, radar_occlusion);
    // ros::Subscriber sub_rangeimg = n.subscribe("/ouster1/range_image", 1, callback);
    
    ros::spin();

    return 0;
}