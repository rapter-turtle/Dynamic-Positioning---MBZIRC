#!/usr/bin/env python3
# Copyright (C) Alibaba Group Holding Limited. All rights reserved.

from .base import Config
