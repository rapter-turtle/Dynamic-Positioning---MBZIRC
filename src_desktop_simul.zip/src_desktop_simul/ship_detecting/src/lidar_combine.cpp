// Combine two LiDAR pointclouds, by simple configuration measure (translation & rotation between two LiDARs)
// Fix LiDAR coordinate to ENU using IMU data

#include "lidar_params.hpp"
#include "pointcloud_helper.cpp"
LiDAR_Params lp;

// Global Variables
pcl::PointCloud<pcl::PointXYZI>::Ptr os1_pcl_data(new pcl::PointCloud<pcl::PointXYZI>);
pcl::PointCloud<pcl::PointXYZI>::Ptr os2_pcl_data(new pcl::PointCloud<pcl::PointXYZI>);
Eigen::MatrixXf os1_eigen_data, os2_eigen_data, os1_eigen_data_global, os2_eigen_data_global, output_eigen, output_eigen_global;
bool os1_set, os2_set, os_comb_ready, imu_on, using_imu = false;
ros::Time rp_tprev, sensor_tprev, start;
ros::Publisher os_pub, os_pub_global;

// IMU Interpolation
Eigen::Vector3f imu_angvel_os1, imu_angvel_os2;
std::vector<Eigen::Quaternionf> imu_quat_stack_os1, imu_quat_stack_os2;
std::vector<double> imu_time_stack_os1, imu_time_stack_os2;

Eigen::Quaternionf imu_interpolation(std::string os_num, double os_time_tosec){
    //#################
    using_imu = true;
    //#################

    // Access to the IMU data address ############################
    Eigen::Vector3f* imu_angvel(new Eigen::Vector3f);
    std::vector<Eigen::Quaternionf>* imu_quat_stack(new std::vector<Eigen::Quaternionf>);
    std::vector<double>* imu_time_stack(new std::vector<double>);
    if (os_num == "os1"){
        imu_angvel = &imu_angvel_os1;
        imu_quat_stack = &imu_quat_stack_os1;
        imu_time_stack = &imu_time_stack_os1;
    }else if (os_num == "os2"){
        imu_angvel = &imu_angvel_os2;
        imu_quat_stack = &imu_quat_stack_os2;
        imu_time_stack = &imu_time_stack_os2;
    }
    //############################################################

    int idx = 0;
    bool between = false;
    while ((idx < imu_time_stack->size()) && (1 < imu_time_stack->size())){
        if ((*imu_time_stack)[idx] < os_time_tosec){
            if (idx != 0){
                imu_time_stack->erase(imu_time_stack->begin());
                imu_quat_stack->erase(imu_quat_stack->begin());
            }else{
                idx++;
            }
        }else if(os_time_tosec > (*imu_time_stack)[0] && os_time_tosec < (*imu_time_stack)[1])
        {
            between = true;
            break;
        }
        else{
            Eigen::Quaternionf new_quat(0,0,0,0);
            return new_quat;
        }
    }

    Eigen::Quaternionf result;
    if(between){
        double t = (os_time_tosec - (*imu_time_stack)[0])/((*imu_time_stack)[1] - (*imu_time_stack)[0]);
        result = (*imu_quat_stack)[0].slerp(t, (*imu_quat_stack)[1]);
    }else{
        Eigen::Quaternionf quat = (*imu_quat_stack)[0];
        Eigen::Vector4f quat_coeffs = quat.coeffs(); // Get current quaternion coeffs
        Eigen::Vector3f pqr = 0.5 * (*imu_angvel);

        // Quaternion derivative from angular velocity
        Eigen::Vector4f quat_derivative;
        quat_derivative(0) = quat.w() * pqr(0) + quat.z() * pqr(1) - quat.y() * pqr(2);
        quat_derivative(1) = quat.w() * pqr(1) - quat.z() * pqr(0) + quat.x() * pqr(2);
        quat_derivative(2) = quat.w() * pqr(2) + quat.y() * pqr(0) - quat.x() * pqr(1);
        quat_derivative(3) = -quat.x() * pqr(0) - quat.y() * pqr(1) - quat.z() * pqr(2);

        // quat_derivative <<  quat.w() * pqr(0) + quat.z() * pqr(1) - quat.y() * pqr(2),
        //                     quat.w() * pqr(1) - quat.z() * pqr(0) + quat.x() * pqr(2),
        //                     quat.w() * pqr(2) + quat.y() * pqr(0) - quat.x() * pqr(1),
        //                     -quat.x() * pqr(0) - quat.y() * pqr(1) - quat.z() * pqr(2);

        // Update quaternion
        double dt = os_time_tosec - (*imu_time_stack)[0]; // Your time difference
        if (dt > 0.5)
        {
            Eigen::Quaternionf new_quat(0,0,0,0);
            return new_quat;
        }
        Eigen::Vector4f new_quat_coeffs = quat_coeffs + quat_derivative * dt;
        Eigen::Quaternionf new_quat(new_quat_coeffs[3], new_quat_coeffs[0], new_quat_coeffs[1], new_quat_coeffs[2]);
        result = new_quat.normalized();

    }

    //#################
    using_imu = false;
    //#################

    return result;
}

void os1_callback(const sensor_msgs::PointCloud2::ConstPtr& msg){
    if (!imu_on){
        return;
    }
    os1_set = 0;

    if(os1_pcl_data && !os_comb_ready){ // If not NullPtr
        if (rp_tprev.isZero()) {  // In ROS C++, uninitialized ros::Time values are set to zero
            rp_tprev = ros::Time::now();
            sensor_tprev = msg->header.stamp;
        }

        if ((ros::Time::now() - rp_tprev) - (msg->header.stamp - sensor_tprev) > ros::Duration(lp.max_tdiff)) {
            return;
        }

        start = ros::Time::now();

        pcl::fromROSMsg (*msg, *os1_pcl_data);
        os1_eigen_data = pcl_to_eigen(os1_pcl_data);
        os1_eigen_data = rotate_matrix(os1_eigen_data, -lp.LIDAR_ROTATED_, lp.TOP_BOARD_WIDTH, lp.TOP_BOARD_WIDTH);

        // Extract spatial data (x, y, z) and rotate
        Eigen::MatrixXf spatialPart = os1_eigen_data.leftCols<3>();
        Eigen::Quaternionf imu_quat = imu_interpolation("os1", msg->header.stamp.toSec());
        if(imu_quat.norm() < 0.5) return;
        Eigen::MatrixXf rotatedSpatialPart = spatialPart * imu_quat.toRotationMatrix().transpose(); // You could also use rotation matrix without transpose, based on convention

        os1_eigen_data_global.resize(os1_eigen_data.rows(), os1_eigen_data.cols());
        os1_eigen_data_global.setZero();
        // os1_eigen_data_global << rotatedSpatialPart, os1_eigen_data.col(3);

        // cout << os1_eigen_data_global.rows() << " , " << 3 << endl;
        // cout << rotatedSpatialPart.rows() << " | " << rotatedSpatialPart.cols() << endl;

        os1_eigen_data_global.block(0, 0, os1_eigen_data_global.rows(), 3) = rotatedSpatialPart;
        os1_eigen_data_global.block(0, 3, os1_eigen_data_global.rows(), 1) = os1_eigen_data.col(3);

        os1_set = 1;
    }

    if (lp.OS_SET_DOUBLE && os1_set && os2_set){

        Eigen::MatrixXf os1_local = os1_eigen_data;
        Eigen::MatrixXf os2_local = os2_eigen_data;

        output_eigen.resize(os1_local.rows() + os2_local.rows(), 4);
        output_eigen.setZero();

        // cout << os1_local.cols() << ", " << os2_local.cols() << endl;
        // cout << output_eigen.rows() << ". " << os1_local.rows() + os2_local.rows() << endl;
        output_eigen.block(0, 0, os1_local.rows(), 4) = os1_local.eval();
        output_eigen.block(os1_local.rows(), 0, os2_local.rows(), 4) = os2_local.eval();
        // output_eigen << os1_eigen_data, os2_eigen_data;

        Eigen::MatrixXf os1_local_global = os1_eigen_data_global;
        Eigen::MatrixXf os2_local_global = os2_eigen_data_global;


        output_eigen_global.resize(os1_local_global.rows() + os2_local_global.rows(), 4);
        output_eigen_global.setZero();

        // cout << os1_local_global.rows() << "||" << os2_local_global.rows() << endl;

        output_eigen_global.block(0, 0, os1_local_global.rows(), 4) = os1_local_global.eval();
        output_eigen_global.block(os1_local_global.rows(), 0, os2_local_global.rows(), 4) = os2_local_global.eval();


        os_comb_ready = 1;
    }else if (!lp.OS_SET_DOUBLE && os1_set){

        Eigen::MatrixXf os1_local = os1_eigen_data;

        output_eigen.resize(os1_local.rows(), 4);
        output_eigen.setZero();
        output_eigen.block(0, 0, os1_local.rows(), 4) = os1_local.eval();
        // output_eigen << os1_eigen_data;

        Eigen::MatrixXf os1_local_global = os1_eigen_data_global;

        output_eigen_global.resize(os1_local_global.rows(), 4);
        output_eigen_global.setZero();
        output_eigen_global.block(0, 0, os1_local_global.rows(), 4) = os1_local_global.eval();

        os_comb_ready = 1;
    }

    if (os_comb_ready){
        pcl::PointCloud<pcl::PointXYZI> output_cloud;
        output_cloud.header.frame_id = lp.FRAME_ID_FIXED;

        pcl::PointCloud<pcl::PointXYZI> output_cloud_global;
        output_cloud_global.header.frame_id = lp.FRAME_ID_FIXED;

        int rowCnt = 0;
        int row_num = output_eigen.rows();
        for (int i=0; i<row_num; i++){
            Eigen::VectorXf rowVector = output_eigen.row(i);

            float m = lp.OS_MIN_INTN;
            float d = lp.OS_MAX_DIST;
            float md = lp.OS_MIN_INTN_DIST;
            float p = lp.PASS_LIMIT_ZP;
            float n = lp.PASS_LIMIT_ZN;
            float x = rowVector(0);
            float y = rowVector(1);
            float z = rowVector(2);
            float I = rowVector(3);

            if ((x*x+y*y < md*md) && (I < m)){                     // Mask 1: By Intensity
                //
            }else if ((z > p) || (z < n)){  // Mask 2: By Z value
                //
            }else if ((x*x+y*y > d*d)){     // Mask 3: By Distance (DELETE SO FAR)
                //
            }else{
                pcl::PointXYZI point;
                point.x = x;
                point.y = y;
                point.z = z;
                point.intensity = I;
                output_cloud.points.push_back(point);

                rowCnt += 1;
            }

            Eigen::VectorXf rowVector_global = output_eigen_global.row(i);

            if ((x*x+y*y < md*md) && (I < m)){                     // Mask 1: By Intensity
                //
            }else if ((x*x+y*y > d*d)){     // Mask 3: By Distance (DELETE SO FAR)
                //
            }else{
                pcl::PointXYZI point_global;
                point_global.x = rowVector_global(0);
                point_global.y = rowVector_global(1);
                point_global.z = rowVector_global(2);
                point_global.intensity = rowVector_global(3);
                output_cloud_global.points.push_back(point_global);
            }

            rowCnt += 1;
        }

        sensor_msgs::PointCloud2 output;
        pcl::toROSMsg(output_cloud, output);
        os_pub.publish(output);

        sensor_msgs::PointCloud2 output_global;
        pcl::toROSMsg(output_cloud_global, output_global);
        os_pub_global.publish(output_global);

        os_comb_ready = 0;

        std::cout << "LAP - Combine: " << ros::Time::now() - start << std::endl;
    }
}

void os2_callback(const sensor_msgs::PointCloud2::ConstPtr& msg){
    if (!imu_on){
        return;
    }
    os2_set = 0;
    if(os2_pcl_data && !os_comb_ready){
        if (rp_tprev.isZero()) {
            rp_tprev = ros::Time::now();
            sensor_tprev = msg->header.stamp;
        }

        if ((ros::Time::now() - rp_tprev) - (msg->header.stamp - sensor_tprev) > ros::Duration(lp.max_tdiff)) {
            return;
        }

        pcl::fromROSMsg (*msg, *os2_pcl_data);
        os2_eigen_data = pcl_to_eigen(os2_pcl_data);

        std::vector<int> rowsToKeep;
        for(int i = 0; i < os2_eigen_data.rows(); ++i) {
            if((os2_eigen_data(i, 0) > -lp.TOP_BOARD_WIDTH) && (os2_eigen_data(i, 1) > -lp.TOP_BOARD_LENGTH)) {
                rowsToKeep.push_back(i);
            }
        }
        Eigen::MatrixXf filtered(os2_eigen_data.rows(), os2_eigen_data.cols());
        int newRow = 0;
        for(int i : rowsToKeep) {
            filtered.row(newRow++) = os2_eigen_data.row(i);
        }
        filtered.conservativeResize(newRow, Eigen::NoChange);

        os2_eigen_data = rotate_matrix(filtered, lp.LIDAR_ROTATED_, lp.TOP_BOARD_WIDTH, lp.TOP_BOARD_WIDTH);

        // Extract spatial data (x, y, z) and rotate
        Eigen::MatrixXf spatialPart = os2_eigen_data.leftCols<3>();
        Eigen::Quaternionf imu_quat = imu_interpolation("os2", msg->header.stamp.toSec());
        if(imu_quat.norm() < 0.5) return;
        Eigen::MatrixXf rotatedSpatialPart = spatialPart * imu_quat.toRotationMatrix().transpose(); // You could also use rotation matrix without transpose, based on convention

        os2_eigen_data_global.resize(os2_eigen_data.rows(), os2_eigen_data.cols());
        os2_eigen_data_global.setZero();
        // os2_eigen_data_global << rotatedSpatialPart, os2_eigen_data.col(3);

        // cout << os2_eigen_data_global.rows() << " , " << 3 << endl;
        // cout << rotatedSpatialPart.rows() << " | " << rotatedSpatialPart.cols() << endl;
        os2_eigen_data_global.block(0, 0, os2_eigen_data_global.rows(), 3) = rotatedSpatialPart;
        os2_eigen_data_global.block(0, 3, os2_eigen_data_global.rows(), 1) = os2_eigen_data.col(3);

        os2_set = 1;
    }
}

void imu_cb(const sensor_msgs::Imu::ConstPtr& msg){
    imu_on = true;

    if (!using_imu){
        Eigen::Quaternionf eigen_quat(msg->orientation.w, msg->orientation.x, msg->orientation.y, msg->orientation.z);
        imu_quat_stack_os1.push_back(eigen_quat);
        imu_time_stack_os1.push_back(msg->header.stamp.toSec());
        imu_quat_stack_os2.push_back(eigen_quat);
        imu_time_stack_os2.push_back(msg->header.stamp.toSec());

        imu_angvel_os1(0) = msg->angular_velocity.x;
        imu_angvel_os1(1) = msg->angular_velocity.y;
        imu_angvel_os1(2) = msg->angular_velocity.z;

        imu_angvel_os2(0) = msg->angular_velocity.x;
        imu_angvel_os2(1) = msg->angular_velocity.y;
        imu_angvel_os2(2) = msg->angular_velocity.z;

        // imu_angvel_os1 << msg->angular_velocity.x, msg->angular_velocity.y, msg->angular_velocity.z;
        // imu_angvel_os2 << msg->angular_velocity.x, msg->angular_velocity.y, msg->angular_velocity.z;
    }
}

int main(int argc, char **argv){
    ros::init(argc, argv, "lidar_combine");
    ros::NodeHandle n;

    lp = load_lidar_prop(n);

    os_pub = n.advertise<sensor_msgs::PointCloud2>(lp.OS_COMBINED_, 1);
    os_pub_global = n.advertise<sensor_msgs::PointCloud2>(lp.OS_COMBINED_GLOBAL, 1);
    ros::AsyncSpinner spinner(3);

    if (lp.OS_SET_DOUBLE){
        ros::Subscriber os1_sub = n.subscribe(lp.OS1_, 1, os1_callback);
        ros::Subscriber os2_sub = n.subscribe(lp.OS2_, 1, os2_callback);
        ros::Subscriber imu_sub = n.subscribe(lp.IMU_, 1, imu_cb);
        //ros::spin();
        spinner.start();
        ros::waitForShutdown();
    }else{
        ros::Subscriber os1_sub = n.subscribe(lp.OS1_, 1, os1_callback);
        ros::Subscriber imu_sub = n.subscribe(lp.IMU_, 1, imu_cb);
        //ros::spin();
        spinner.start();
        ros::waitForShutdown();
    }

    return 0;
}
