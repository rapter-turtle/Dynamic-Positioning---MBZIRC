# Ship following
## Control Node
```
rosrun DP node
```
## Ship visualize
```
GUI
```
## Virtual ship Node 
# On GPS
```
virtual_ship_a
```
# On Lidar
```
gps_to_utm_lidar
```



