#!/usr/bin/python3

import rospy
import message_filters
import numpy as np
import pcl
from sensor_msgs.msg import PointCloud2, Imu

def callback(os1, os2):
    print("Time Synced!")

def main():
    os1_rev7_sub = message_filters.Subscriber("/ouster1/points", PointCloud2)
    os2_rev6_sub = message_filters.Subscriber("/ouster2/points", PointCloud2)
    ts = message_filters.ApproximateTimeSynchronizer([os1_rev7_sub, os2_rev6_sub], 10, 0.05)
    ts.registerCallback(callback)
    rospy.spin()

if __name__ == "__main__":
    try:
        rospy.init_node("LiDAR_Sync")
        rospy.loginfo("[{}] node created".format("LiDAR_Sync"))

        main()
    except rospy.ROSInterruptException:
        pass