#!/usr/bin/python3

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image, CompressedImage
from cv_bridge import CvBridge, CvBridgeError

def main():
    pub1 = rospy.Publisher('/usv/stereo1/compressed', CompressedImage, queue_size=1)
    pub2 = rospy.Publisher('/usv/stereo2/compressed', CompressedImage, queue_size=1)
    bridge = CvBridge()

    rate = rospy.Rate(30)
    base_path = "/media/morinsol/SOL/git_repo/"
    # base_path = "/home/dongwooklee1201/"
    cv_image = cv2.imread(base_path + 'MBZIRC2023/src/inspection/ship_detecting/test_imgs/target_ship.png')
    msg_img = CompressedImage()
    msg_img.header.stamp = rospy.Time.now()
    msg_img.data = np.array(cv2.imencode('.jpg', cv_image)[1]).tobytes()
    
    while not rospy.is_shutdown():
        pub1.publish(msg_img)
        pub2.publish(msg_img)
        rate.sleep()

if __name__ == '__main__':
    rospy.init_node('test_stereo1_sent')
    try:
        main()
    except rospy.ROSInterruptException:
        pass