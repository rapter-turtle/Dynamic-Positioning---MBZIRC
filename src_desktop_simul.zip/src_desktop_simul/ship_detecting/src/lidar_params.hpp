// Hpp file to globally set the ros parameters from the yaml file (../config/lidar_prop.yaml)

#ifndef LiDAR_PARAMS_HPP
#define LiDAR_PARAMS_HPP

#include "ros/ros.h"
#include "std_msgs/Int32.h"
#include "std_msgs/String.h"
#include "sensor_msgs/PointCloud2.h"
#include "sensor_msgs/Imu.h"
#include "sensor_msgs/Image.h"
#include "std_msgs/Int16MultiArray.h"
#include "std_msgs/Float32MultiArray.h"
#include "visualization_msgs/Marker.h"
#include "visualization_msgs/MarkerArray.h"

#include <sstream>
#include <thread>
#include <chrono>
#include <cmath>
#include <vector>
#include <numeric>
#include <algorithm>
#include <string>
using namespace std;

#include <pcl/conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/features/normal_3d.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/crop_box.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>

#include <tf2/LinearMath/Quaternion.h>
#include <tf2_eigen/tf2_eigen.h>
#include <Eigen/Geometry>
#include <tf2_ros/transform_broadcaster.h>

struct LiDAR_Params {
    string IMU_;
    bool PC_GLOBALIZE;

    // ------------------------------------------------------------------- Sensor - LiDAR
    string FRAME_ID_FIXED;
    string FRAME_ID_FILTERED;
    string FRAME_ID_CLUSTERED;
    string FRAME_ID_GROUND;
    string FRAME_ID_SUPPORT;

    bool OS_SET_DOUBLE;

    string OS_;
    string OS1_;
    string OS2_;
    string OS_COMBINED_;
    string OS_COMBINED_GLOBAL;
    string OS_FILTERED;
    string OS_CLUSTERED;
    string OS_OUTLINES;
    string MARKER_PUB;
    string OS_GROUND;
    string OS_GROUNDLINE;
    string RADAR_OCC_BIN;

    float OS1_surface_x;
    float OS1_surface_y;
    float LIDAR_ROTATED_;
    float max_tdiff;

    float GROUND_MAX_WIDTH;
    float RADAR_OCC_d;
    float RADAR_OCC_h;
    float RADAR_OCC_binnum;
    float GROUND_BIN_SIZE;

    string SHIP_BOX_FILTER;
    string TARGET_POLYGONS_;
    string TARGET_POSES_;

    // ------------------------------------------------------------------- Catamaran Config
    float TOP_BOARD_WIDTH;
    float TOP_BOARD_LENGTH;

    // Deadzone Filter
    float OS_MAX_DIST;

    // Intensity Filter
    float OS_MIN_INTN_DIST;
    float OS_MIN_INTN;

    // Voxel Grid Filter
    float VG_SIZE_X;
    float VG_SIZE_Y;
    float VG_SIZE_Z;

    // Crop Box Filter
    float PASS_LIMIT_XP;
    float PASS_LIMIT_XN;
    float PASS_LIMIT_YP;
    float PASS_LIMIT_YN;
    float PASS_LIMIT_ZP;
    float PASS_LIMIT_ZN;

    // Denoise Filter                               (optional)
    bool DENOISE;
    int MEAN_K;
    float THRESH;

    // Euclidean Distance Clustering                (optional)
    bool LOG_SCALE;
    float EC_TOLERANCE;
    int EC_MIN;
    int EC_MAX;

    // Cluster Height Filter
    float TARGET_TOP_HEIGHT_MAX;
    float TARGET_TOP_HEIGHT_MIN;

    // Cluster Z Position Filter                    (optional)
    bool GLOBAL_Z_FILTER;
    float LIDAR_TILT_BIAS;
    float PCL_GROUND_Z_BOUND;

    // CAM FOV Filter                               (optional)
    bool CAM_FOV_FITLER;
    float CAM_FOV_HORIZONTAL;
    float CAM_FOV_VERTICAL;
    float CAM_ALPHA;
    float A_BY_WIDTH;
    float B_BY_HEIGHT;

    // Nukhada Tail Filter                          (optional)
    bool TAIL_FILTER;
    float TAIL_ANGLE;

    bool LETTUCE_FILTER;
    bool BIG_WAVE_FILTER;
    float WAVE_SIZE;
    bool BUOY_FILTER;
    float BUOY_SIZE;

};

LiDAR_Params load_lidar_prop(ros::NodeHandle nh) {
    LiDAR_Params lp;

    nh.getParam("/IMU_", lp.IMU_);
    nh.getParam("/PC_GLOBALIZE", lp.PC_GLOBALIZE);

    nh.getParam("/FRAME_ID_FIXED", lp.FRAME_ID_FIXED);
    nh.getParam("/FRAME_ID_FILTERED", lp.FRAME_ID_FILTERED);
    nh.getParam("/FRAME_ID_CLUSTERED", lp.FRAME_ID_CLUSTERED);
    nh.getParam("/FRAME_ID_GROUND", lp.FRAME_ID_GROUND);
    nh.getParam("/FRAME_ID_SUPPORT", lp.FRAME_ID_SUPPORT);

    nh.getParam("/OS_SET_DOUBLE", lp.OS_SET_DOUBLE);

    nh.getParam("/OS_", lp.OS_);
    nh.getParam("/OS1_", lp.OS1_);
    nh.getParam("/OS2_", lp.OS2_);
    nh.getParam("/OS_COMBINED_", lp.OS_COMBINED_);
    nh.getParam("/OS_COMBINED_GLOBAL", lp.OS_COMBINED_GLOBAL);
    nh.getParam("/OS_FILTERED", lp.OS_FILTERED);
    nh.getParam("/OS_CLUSTERED", lp.OS_CLUSTERED);
    nh.getParam("/OS_OUTLINES", lp.OS_OUTLINES);
    nh.getParam("/MARKER_PUB", lp.MARKER_PUB);
    nh.getParam("/OS_GROUND", lp.OS_GROUND);
    nh.getParam("/OS_GROUNDLINE", lp.OS_GROUNDLINE);
    nh.getParam("/RADAR_OCC_BIN", lp.RADAR_OCC_BIN);

    nh.getParam("/OS1_surface_x", lp.OS1_surface_x);
    nh.getParam("/OS1_surface_y", lp.OS1_surface_y);
    nh.getParam("/LIDAR_ROTATED_", lp.LIDAR_ROTATED_);
    nh.getParam("/max_tdiff", lp.max_tdiff);

    nh.getParam("/GROUND_MAX_WIDTH", lp.GROUND_MAX_WIDTH);
    nh.getParam("/RADAR_OCC_d", lp.RADAR_OCC_d);
    nh.getParam("/RADAR_OCC_h", lp.RADAR_OCC_h);
    nh.getParam("/RADAR_OCC_binnum", lp.RADAR_OCC_binnum);
    nh.getParam("/GROUND_BIN_SIZE", lp.GROUND_BIN_SIZE);

    nh.getParam("/SHIP_BOX_FILTER", lp.SHIP_BOX_FILTER);
    nh.getParam("/TARGET_POLYGONS_", lp.TARGET_POLYGONS_);
    nh.getParam("/TARGET_POSES_", lp.TARGET_POSES_);

    nh.getParam("/TOP_BOARD_WIDTH", lp.TOP_BOARD_WIDTH);
    nh.getParam("/TOP_BOARD_LENGTH", lp.TOP_BOARD_LENGTH);

    nh.getParam("/OS_MAX_DIST", lp.OS_MAX_DIST);

    nh.getParam("/OS_MIN_INTN_DIST", lp.OS_MIN_INTN_DIST);
    nh.getParam("/OS_MIN_INTN", lp.OS_MIN_INTN);

    nh.getParam("/VG_SIZE_X", lp.VG_SIZE_X);
    nh.getParam("/VG_SIZE_Y", lp.VG_SIZE_Y);
    nh.getParam("/VG_SIZE_Z", lp.VG_SIZE_Z);

    nh.getParam("/PASS_LIMIT_XP", lp.PASS_LIMIT_XP);
    nh.getParam("/PASS_LIMIT_XN", lp.PASS_LIMIT_XN);
    nh.getParam("/PASS_LIMIT_YP", lp.PASS_LIMIT_YP);
    nh.getParam("/PASS_LIMIT_YN", lp.PASS_LIMIT_YN);
    nh.getParam("/PASS_LIMIT_ZP", lp.PASS_LIMIT_ZP);
    nh.getParam("/PASS_LIMIT_ZN", lp.PASS_LIMIT_ZN);

    nh.getParam("/DENOISE", lp.DENOISE);
    nh.getParam("/MEAN_K", lp.MEAN_K);
    nh.getParam("/THRESH", lp.THRESH);

    nh.getParam("/LOG_SCALE", lp.LOG_SCALE);
    nh.getParam("/EC_TOLERANCE", lp.EC_TOLERANCE);
    nh.getParam("/EC_MIN", lp.EC_MIN);
    nh.getParam("/EC_MAX", lp.EC_MAX);

    nh.getParam("/TARGET_TOP_HEIGHT_MAX", lp.TARGET_TOP_HEIGHT_MAX);
    nh.getParam("/TARGET_TOP_HEIGHT_MIN", lp.TARGET_TOP_HEIGHT_MIN);

    nh.getParam("/GLOBAL_Z_FILTER", lp.GLOBAL_Z_FILTER);
    nh.getParam("/LIDAR_TILT_BIAS", lp.LIDAR_TILT_BIAS);
    nh.getParam("/PCL_GROUND_Z_BOUND", lp.PCL_GROUND_Z_BOUND);

    nh.getParam("/CAM_FOV_FITLER", lp.CAM_FOV_FITLER);
    nh.getParam("/CAM_FOV_HORIZONTAL", lp.CAM_FOV_HORIZONTAL);
    nh.getParam("/CAM_FOV_VERTICAL", lp.CAM_FOV_VERTICAL);
    nh.getParam("/CAM_ALPHA", lp.CAM_ALPHA);
    nh.getParam("/A_BY_WIDTH", lp.A_BY_WIDTH);
    nh.getParam("/B_BY_HEIGHT", lp.B_BY_HEIGHT);

    nh.getParam("/TAIL_FILTER", lp.TAIL_FILTER);
    nh.getParam("/TAIL_ANGLE", lp.TAIL_ANGLE);

    nh.getParam("/LETTUCE_FILTER", lp.LETTUCE_FILTER);

    nh.getParam("/LETTUCE_FILTER", lp.LETTUCE_FILTER);

    nh.getParam("/BIG_WAVE_FILTER", lp.BIG_WAVE_FILTER);
    nh.getParam("/WAVE_SIZE", lp.WAVE_SIZE);
    nh.getParam("/BUOY_FILTER", lp.BUOY_FILTER);
    nh.getParam("/BUOY_SIZE", lp.BUOY_SIZE);

    return lp;
}

#endif // LiDAR_PARAMS_HPP
