#!/usr/bin/python3

import rospy
import numpy as np
import pcl
import math
from variables import *
from scipy.spatial.transform import Rotation
from std_msgs.msg import Float32MultiArray
from sensor_msgs.msg import PointCloud2, Imu
from geometry_msgs.msg import PolygonStamped, Point32
from jsk_recognition_msgs.msg import PolygonArray
import pcl_python_helper as ph



########################################### PCL Handler #################################################
def rot_btw_vec(vec):
    base_vec = [0,0,1]
    axis1 = np.cross(vec, base_vec)
    c = np.dot(vec, base_vec)
    s = np.linalg.norm(axis1)
    axis1 = axis1/s
    t = 1 - c
    x, y, z = axis1
    K = np.array([[0, -axis1[2], axis1[1]],
              [axis1[2], 0, -axis1[0]],
              [-axis1[1], axis1[0], 0]])
    return (np.eye(3) + s * K + (1 - c) * np.dot(K,K))

def ransac_plane_fit(points, num_iterations=1000, distance_threshold=0.01):
    max_inliers = 0
    best_plane = None
    
    for _ in range(num_iterations):
        # Sample three points
        sample_indices = np.random.choice(len(points), 3, replace=False)
        sample_points = points[sample_indices]
        
        # Fit plane
        v1 = sample_points[1] - sample_points[0]
        v2 = sample_points[2] - sample_points[0]
        normal = np.cross(v1, v2)
        
        # Normalize normal
        normal = normal / np.linalg.norm(normal)
        
        # Calculate distance of all points to the plane
        distances = np.abs(np.dot(points - sample_points[0], normal))
        
        # Count inliers
        inliers = distances < distance_threshold
        num_inliers = np.sum(inliers)
        
        if num_inliers > max_inliers:
            max_inliers = num_inliers
            best_plane = normal
        if best_plane[2] < 0:
            best_plane = -best_plane
    
    return best_plane
    
class PCL_Handler():
    def __init__(self):
        rospy.init_node(PCL_HANDLER_NODE)
        rospy.loginfo("[{}] node created".format(PCL_HANDLER_NODE))
        
        self.is_imu_on = False
        self.imu_yaw = 0.0
        self.imu_roll = 0.0
        self.imu_pitch = 0.0

        # Dummy ROSmsg to publish
        self.clustered = PointCloud2()
        self.filtered = PointCloud2()
        self.target_pose = Float32MultiArray()
        self.obboxes = PolygonArray()

        # ROSTOPICs pub/sub
        self.output_pub = rospy.Publisher(OS_CLUSTERED, PointCloud2, queue_size=1)
        self.filtered_pub = rospy.Publisher(OS_FILTERED, PointCloud2, queue_size=1)
        self.box_filter_pub = rospy.Publisher(SHIP_BOX_FILTER, PolygonStamped, queue_size=1)
        self.obbox_pub = rospy.Publisher(TARGET_POLYGONS_, PolygonArray, queue_size=1)
        self.target_pose_pub = rospy.Publisher(TARGET_POSES_, Float32MultiArray, queue_size=1)

        self.imu_sub = rospy.Subscriber(IMU_, Imu, self.imu_update)
        self.lidar_sub = rospy.Subscriber(OS1_, PointCloud2, self.cloud_cb)
        self.surface_vec1 = [OS1_surface_x, OS1_surface_y, math.sqrt(1-OS1_surface_x*OS1_surface_x-OS1_surface_y*OS1_surface_y)]
        print(self.surface_vec1)
        self.base_vec = [0,0,1]
        axis1 = np.cross(self.surface_vec1, self.base_vec)
        c = np.dot(self.surface_vec1, self.base_vec)
        s = np.linalg.norm(axis1)
        axis1 = axis1/s
        t = 1 - c
        x, y, z = axis1
        K = np.array([[0, -axis1[2], axis1[1]],
                  [axis1[2], 0, -axis1[0]],
                  [-axis1[1], axis1[0], 0]])
        #self.Rot1 = np.array([[t*x*x + c, t*x*y - s*z, t*x*z + s*y],
        #                        [t*x*y + s*z, t*y*y + c, t*y*z - s*x],
        #                        [t*x*z - s*y, t*y*z + s*x, t*z*z + c]])
        self.Rot1 = np.eye(3) + s * K + (1 - c) * np.dot(K,K)
        #self.Rot1 = np.linalg.inv(self.Rot1)
                             
        print(self.Rot1 @ self.surface_vec1)
    
    def imu_update(self, data):
        # if not self.is_imu_on:
        r = Rotation.from_quat([data.orientation.x, data.orientation.y, data.orientation.z, data.orientation.w])
        self.imu_yaw, self.imu_roll, self.imu_pitch = r.as_euler('zxy', degrees=False)
        self.is_imu_on = True

    def measuring(self, cluster_n_nparr):

        filtered_cloud = pcl.PointCloud_PointXYZRGB()
        filtered_cloud.from_array(cluster_n_nparr.astype(np.float32))

        rect_filtered = ph.pcl_to_ros(filtered_cloud)
        rect_filtered.header.frame_id = LIDAR_TF
        self.filtered_pub.publish(rect_filtered)

        # r = Rotation.from_euler('z', -LIDAR_ROTATED_, degrees=True)
        # cloud_arr_3d = (r.as_matrix()@cluster_n_nparr[:,0:3].T).T
        
        cloud_arr_3d = cluster_n_nparr[:,0:3]
        # cloud_arr_3d =((Rotation.from_euler("ZXY", [self.imu_yaw, self.imu_roll, self.imu_pitch], degrees=True)).as_matrix()@cluster_n_nparr[:,0:3].T).T
        com = np.sum(cloud_arr_3d, axis=0) / len(cloud_arr_3d)
        dv_theta = - math.atan(com[0]/(com[1]-TOP_BOARD_WIDTH/2))
        com_position_test = CAM_ALPHA - dv_theta - math.pi/2

        # IF THE CLUSTER IS NOT IN THE CAMERA FOV
        # if 0 < com_position_test or com_position_test < -math.pi:
        #     return "CSBD" # Cluster Should Be Deleted

        cov_matrix = np.cov((cloud_arr_3d - com), rowvar=False)
        eigenvalues, eigenvectors = np.linalg.eig(cov_matrix)
        idx = eigenvalues.argsort()[::-1]   
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:,idx]

        #print(eigenvalues)
        #print(eigenvectors[2])

        # 3D Point Cloud size
        width_projected = (np.max(cloud_arr_3d[:,0])-np.min(cloud_arr_3d[:,0])) # X
        height_projected = (np.max(cloud_arr_3d[:,2])-np.min(cloud_arr_3d[:,2])) # Z

        cloud_arr_coordinated = (eigenvectors.T @ cloud_arr_3d.T).T
        length = (np.max(cloud_arr_coordinated[:,0])-np.min(cloud_arr_coordinated[:,0]))
        width = (np.max(cloud_arr_coordinated[:,1])-np.min(cloud_arr_coordinated[:,1]))
        height = (np.max(cloud_arr_coordinated[:,2])-np.min(cloud_arr_coordinated[:,2]))

        # imu_rotation_matrix = ((Rotation.from_euler("ZYX", [self.imu_yaw, self.imu_pitch, self.imu_roll], degrees=True)).as_matrix())
        # cloud_globalized = (imu_rotation_matrix @ cloud_arr_3d.T).T
        # height = np.max(cloud_globalized[:,2])

        # # IF THE CLUSTER HEIGHT IS LESS THAN THRESHOLD
        # if height < TARGET_MIN_HEIGHT:
        #     return "CSBD" # Cluster Should Be Deleted
        
        self.obboxes.header.frame_id = LIDAR_TF
        obbox_temp = PolygonStamped()
        obbox_temp.header.frame_id = LIDAR_TF
        crn1 = Point32();crn2 = Point32();crn3 = Point32();crn4 = Point32()
        crn5 = Point32();crn6 = Point32();crn7 = Point32();crn8 = Point32()
        eigvec_0_2D = np.asarray([eigenvectors[:,0][0],eigenvectors[:,0][1],0.0]); eigvec_0_2D = eigvec_0_2D / np.linalg.norm(eigvec_0_2D)
        eigvec_1_2D = Rotation.from_euler('z', 90, degrees=True).as_matrix()@eigvec_0_2D; eigvec_1_2D = eigvec_1_2D / np.linalg.norm(eigvec_1_2D)
        eigvec_2_2D = np.asarray([0.0,0.0,1.0])
        crn1.x, crn1.y, crn1.z = com - length//2*eigvec_0_2D - width//2*eigvec_1_2D - height//2*eigvec_2_2D
        crn2.x, crn2.y, crn2.z = com - length//2*eigvec_0_2D - width//2*eigvec_1_2D + height//2*eigvec_2_2D
        crn3.x, crn3.y, crn3.z = com - length//2*eigvec_0_2D + width//2*eigvec_1_2D - height//2*eigvec_2_2D
        crn4.x, crn4.y, crn4.z = com - length//2*eigvec_0_2D + width//2*eigvec_1_2D + height//2*eigvec_2_2D
        crn5.x, crn5.y, crn5.z = com + length//2*eigvec_0_2D - width//2*eigvec_1_2D - height//2*eigvec_2_2D
        crn6.x, crn6.y, crn6.z = com + length//2*eigvec_0_2D - width//2*eigvec_1_2D + height//2*eigvec_2_2D
        crn7.x, crn7.y, crn7.z = com + length//2*eigvec_0_2D + width//2*eigvec_1_2D - height//2*eigvec_2_2D
        crn8.x, crn8.y, crn8.z = com + length//2*eigvec_0_2D + width//2*eigvec_1_2D + height//2*eigvec_2_2D
        obbox_temp.polygon.points.append(crn1); obbox_temp.polygon.points.append(crn2)
        obbox_temp.polygon.points.append(crn4); obbox_temp.polygon.points.append(crn3)
        obbox_temp.polygon.points.append(crn1); obbox_temp.polygon.points.append(crn5)
        obbox_temp.polygon.points.append(crn6); obbox_temp.polygon.points.append(crn8)
        obbox_temp.polygon.points.append(crn7); obbox_temp.polygon.points.append(crn5)
        obbox_temp.polygon.points.append(crn6); obbox_temp.polygon.points.append(crn2)
        obbox_temp.polygon.points.append(crn4); obbox_temp.polygon.points.append(crn8)
        obbox_temp.polygon.points.append(crn7); obbox_temp.polygon.points.append(crn3)
        self.obboxes.polygons.append(obbox_temp)

        # # plane_v = eigenvectors.T[np.argmax(eigenvalues)] # Extract the eigenvector of the minimum eigenvalue
        # theta = dv_theta - math.pi/2

        # r1 = width_projected/(2*A_BY_WIDTH*math.tan(CAM_FOV_HORIZONTAL))
        # r2 = height_projected/(2*B_BY_HEIGHT*math.tan(CAM_FOV_VERTICAL))
        # minimum_r = r1 if r1 > r2 else r2

        # target_heading = np.arctan(eigenvectors[:,0][0]/eigenvectors[:,0][1])
        # self.target_pose.data.append(com[0])
        # self.target_pose.data.append(com[1])
        # self.target_pose.data.append(com[2])
        # self.target_pose.data.append(target_heading)
        # self.target_pose.data.append(minimum_r)
        # self.target_pose.data.append(theta)
        
        # # print("[Ship Detected] Heading: {} | {} Deg".format(target_heading, target_heading*180/math.pi))

        # return "CIP" # Cluster is Promising

    def crop_box_filter(self, cloud):
        numpy_points = np.asarray(cloud)
        # numpy_points[np.logical_or(
        #                 np.logical_or(
        #                     # MASK X&Y
        #                     np.logical_and(
        #                         np.logical_and(numpy_points[:,0]>PASS_LIMIT_XN, numpy_points[:,0]<PASS_LIMIT_XP),
        #                         np.logical_and(numpy_points[:,1]>PASS_LIMIT_YN, numpy_points[:,1]<PASS_LIMIT_YP)),
        #                     # MASK DEADZONE
        #                     np.logical_or(numpy_points[:,0]>PASS_LIMIT_DEADZONE, numpy_points[:,1]>PASS_LIMIT_DEADZONE)),
        #                 np.logical_or(
        #                     # MASK Z
        #                     np.logical_or(numpy_points[:,2]>PASS_LIMIT_ZP, numpy_points[:,2]<PASS_LIMIT_ZN),
        #                     np.logical_and(numpy_points[:,2]<PCL_GROUND_Z_BOUND, numpy_points[:,2]>-PCL_GROUND_Z_BOUND)))] = 0
        mask = np.logical_and(
                                 np.logical_and(numpy_points[:,0]>-5, numpy_points[:,0]<5),
                                 np.logical_and(numpy_points[:,1]>-5, numpy_points[:,1]<5))
        numpy_points = numpy_points[~mask, :]
        mask = np.abs(numpy_points[:,0])+np.abs(numpy_points[:,1]) > 15
        numpy_points = numpy_points[~mask, :]   
        
        
        #numpy_points[np.logical_and(
        #                         np.logical_and(numpy_points[:,0]>PASS_LIMIT_XN, numpy_points[:,0]<PASS_LIMIT_XP),
        #                         np.logical_and(numpy_points[:,1]>PASS_LIMIT_YN, numpy_points[:,1]<PASS_LIMIT_YP))] = 0
        #numpy_points = numpy_points[np.any(numpy_points != [0.,0.,0.,0.], axis=1)]

        #numpy_points_new =(self.Rot1 @((Rotation.from_euler("ZXY", [self.imu_yaw, self.imu_roll, self.imu_pitch], degrees=True)).as_matrix()@numpy_points[:,0:3].T)).T
        numpy_points_new =((Rotation.from_euler("ZXY", [self.imu_yaw, self.imu_roll, self.imu_pitch], degrees=True)).as_matrix()@numpy_points[:,0:3].T).T
        print("PCL Normal : ", ransac_plane_fit(numpy_points_new ))
        print(np.std(numpy_points_new[:,2]), np.max(numpy_points_new[:,2]) - np.min(numpy_points_new[:,2]) )
        numpy_points_new = np.append(numpy_points_new, np.asarray(numpy_points)[:,3].reshape(-1,1), 1)

        # ########################## Immediate Publisher ######################
        # box_filter_viz = PolygonStamped()
        # box_filter_viz.header.frame_id = LIDAR_TF
        # box_filter_corner1 = Point32(); box_filter_corner2 = Point32(); box_filter_corner3 = Point32(); box_filter_corner4 = Point32()
        # box_filter_corner5 = Point32(); box_filter_corner6 = Point32(); box_filter_corner7 = Point32(); box_filter_corner8 = Point32()
        # box_filter_corner2.x = PASS_LIMIT_XN; box_filter_corner2.y = PASS_LIMIT_YN; box_filter_corner2.z = PASS_LIMIT_ZP
        # box_filter_corner1.x = PASS_LIMIT_XN; box_filter_corner1.y = PASS_LIMIT_YN; box_filter_corner1.z = PASS_LIMIT_ZN
        # box_filter_corner3.x = PASS_LIMIT_XN; box_filter_corner3.y = PASS_LIMIT_YP; box_filter_corner3.z = PASS_LIMIT_ZN
        # box_filter_corner4.x = PASS_LIMIT_XN; box_filter_corner4.y = PASS_LIMIT_YP; box_filter_corner4.z = PASS_LIMIT_ZP
        # box_filter_corner5.x = PASS_LIMIT_XP; box_filter_corner5.y = PASS_LIMIT_YN; box_filter_corner5.z = PASS_LIMIT_ZN
        # box_filter_corner6.x = PASS_LIMIT_XP; box_filter_corner6.y = PASS_LIMIT_YN; box_filter_corner6.z = PASS_LIMIT_ZP
        # box_filter_corner7.x = PASS_LIMIT_XP; box_filter_corner7.y = PASS_LIMIT_YP; box_filter_corner7.z = PASS_LIMIT_ZN
        # box_filter_corner8.x = PASS_LIMIT_XP; box_filter_corner8.y = PASS_LIMIT_YP; box_filter_corner8.z = PASS_LIMIT_ZP

        # box_filter_viz.polygon.points.append(box_filter_corner1); box_filter_viz.polygon.points.append(box_filter_corner2)
        # box_filter_viz.polygon.points.append(box_filter_corner4); box_filter_viz.polygon.points.append(box_filter_corner3)
        # box_filter_viz.polygon.points.append(box_filter_corner1); box_filter_viz.polygon.points.append(box_filter_corner5)
        # box_filter_viz.polygon.points.append(box_filter_corner6); box_filter_viz.polygon.points.append(box_filter_corner8)
        # box_filter_viz.polygon.points.append(box_filter_corner7); box_filter_viz.polygon.points.append(box_filter_corner5)
        # box_filter_viz.polygon.points.append(box_filter_corner6); box_filter_viz.polygon.points.append(box_filter_corner2)
        # box_filter_viz.polygon.points.append(box_filter_corner4); box_filter_viz.polygon.points.append(box_filter_corner8)
        # box_filter_viz.polygon.points.append(box_filter_corner7); box_filter_viz.polygon.points.append(box_filter_corner3)

        # self.box_filter_pub.publish(box_filter_viz)
        # #####################################################################
        
        return numpy_points_new

    def filtering_function(self, full_cloud):
        # print("Point count before Filters:", full_cloud.size) # Size 4

        # Step 1 - Voxel Grid Filter
        vox = full_cloud.make_voxel_grid_filter()
        vox.set_leaf_size(VG_SIZE_X, VG_SIZE_Y, VG_SIZE_Z)
        vox_cloud = vox.filter()
        # print("Point count after Voxel Filter:", vox_cloud.size) # Size 4

        # Step 2 - Box Filter
        box_cloud = self.crop_box_filter(vox_cloud)
        # print("Point count after Box Filter:", box_cloud.size) # Size 4

        # Step 3 - Denoise
        box_cloud = ph.XYZRGB_to_XYZ(box_cloud)
        outlier_filter = box_cloud.make_statistical_outlier_filter()
        outlier_filter.set_mean_k(MEAN_K)
        outlier_filter.set_std_dev_mul_thresh(THRESH)
        denoised_cloud = outlier_filter.filter()
        denoised_cloud = ph.XYZ_to_XYZRGB(denoised_cloud, ph.random_color_gen())
        # print("# Deleted by outlier Filter:", box_cloud.size-denoised_cloud.size) # Size 4

        return denoised_cloud

    def clustering_function(self, cloud_filtered):

        ec_cloud_set = pcl.PointCloud()
        ec_cloud_set.from_array(np.asarray(cloud_filtered)[:,0:3])
        tree = ec_cloud_set.make_kdtree()
        ec = ec_cloud_set.make_EuclideanClusterExtraction()
        ec.set_ClusterTolerance(EC_TOLERANCE)
        ec.set_MinClusterSize(EC_MIN_SIZE)
        ec.set_MaxClusterSize(EC_MAX_SIZE)
        ec.set_SearchMethod(tree)
        cluster_indices = ec.Extract()
        
        return cluster_indices

    def measure_postprocessing(self, cloud):
        ##### Filtered Point Cloud Publish ##################################
        cloud_filtered = self.filtering_function(cloud)
        self.filtered = ph.pcl_to_ros(cloud_filtered)
        self.filtered.header.frame_id = LIDAR_TF
        self.filtered_pub.publish(self.filtered)
        #####################################################################

        # print(cloud_filtered.size)
        if cloud_filtered.size != 0:
            cluster_indices = self.clustering_function(cloud_filtered)
            meas_num = len(cluster_indices)
            # print("Cluster Numbers:", meas_num)

            whole_clustered_nparr = None
            cloud_clustered = np.asarray(cloud_filtered)
            self.target_pose.data = [0] # Initialize the rosmsg
            # print(self.target_pose.data[0])
            self.target_pose.data.append(self.imu_yaw)
            self.target_pose.data.append(self.imu_roll)
            self.target_pose.data.append(self.imu_pitch)
            cnt_valid_cluster = 0
            for j, indices in enumerate(cluster_indices):
                cloud_clustered[indices,3] = (j+1)
                measuring_result = self.measuring(cloud_clustered[indices])
                if measuring_result == "CIP":
                    if whole_clustered_nparr is None:
                        whole_clustered_nparr = cloud_clustered[indices]
                    else:
                        whole_clustered_nparr = np.vstack((whole_clustered_nparr, cloud_clustered[indices]))
                    cnt_valid_cluster += 1
                elif measuring_result == "CSBD":
                    pass

            if whole_clustered_nparr is not None:
                ##### Clustered Point Cloud (with Intensity difference) Publish #####
                whole_clustered_pcl = pcl.PointCloud_PointXYZRGB()
                whole_clustered_pcl.from_array(whole_clustered_nparr)
                whole_clustered_msg = ph.pcl_to_ros(whole_clustered_pcl)
                whole_clustered_msg.header.frame_id = LIDAR_TF
                self.output_pub.publish(whole_clustered_msg)
                #####################################################################

            # ##### Bounding Boxes for all clusters Publish #######################
            self.obbox_pub.publish(self.obboxes)
            self.obboxes.polygons.clear()
            # #####################################################################

            ##### Target Poses for all clusters Publish #########################
            self.target_pose.data[0] = cnt_valid_cluster
            self.target_pose_pub.publish(self.target_pose)
            self.target_pose.data.clear()
            #####################################################################

    def cloud_cb(self, point_cloud2_msg):
        cloud = ph.ros_to_pcl(point_cloud2_msg)
        # print("----------\nInput:", cloud, type(cloud))

        # self.measure_postprocessing(cloud)
        box_nparr = self.crop_box_filter(cloud)
        self.measuring(box_nparr)
########################################################################################################

if __name__ == "__main__":
    try:
        pcl_handler = PCL_Handler()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
