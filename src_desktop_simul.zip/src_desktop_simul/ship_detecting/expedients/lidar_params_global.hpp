#ifndef LiDAR_PARAMS_HPP
#define LiDAR_PARAMS_HPP

#include "ros/ros.h"
#include "std_msgs/Int32.h"
#include "std_msgs/String.h"
#include "sensor_msgs/PointCloud2.h"
#include "sensor_msgs/Imu.h"
#include "std_msgs/Float32MultiArray.h"

#include <sstream>
#include <thread>
#include <chrono>
#include <cmath>
#include <vector>
#include <numeric>
#include <algorithm>
#include <string>
using namespace std;

#include <pcl/conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/features/normal_3d.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/crop_box.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>

#include <tf2/LinearMath/Quaternion.h>
#include <tf2_eigen/tf2_eigen.h>
#include <Eigen/Geometry>

struct LiDAR_Params {
    string IMU_ = "/imu/data";
    bool PC_GLOBALIZE = false;

    // ------------------------------------------------------------------- Sensor - LiDAR
    string LIDAR_FIX_NODE = "lidar_combinator";
    // string FRAME_ID = "imu_link";
    string FRAME_ID = "os_sensor";
    bool OS_SET_DOUBLE = true;

    string OS_  = "/os_cloud_node/points";
    string OS1_ = "/ouster1/points"; // REV7
    string OS2_ = "/ouster2/points"; // REV6
    string OS_COMBINED_ = "/ouster/fixed";
    string OS_FILTERED = "/ouster/filtered";
    string OS_CLUSTERED = "/ouster/clustered";
    
    float OS1_surface_x = -0.0;
    float OS1_surface_y = 0.0;
    float LIDAR_ROTATED_ = 90.0;
    float max_tdiff = 0.2;

    string SHIP_BOX_FILTER = "/ouster/box_filter";
    string TARGET_POLYGONS_ = "/target/obboxes";
    string TARGET_POSES_ = "/target/poses";

    // ------------------------------------------------------------------- Catamaran Config
    float TOP_BOARD_WIDTH = 3.325;
    float TOP_BOARD_LENGTH = 1.415;
    
    // ------------------------------------------------------------------- PCA Node
    string COMBINE_NODE = "lidar_combine";
    string MEASURE_NODE = "lidar_measure";

    // Deadzone Filter
    float OS_MAX_DIST = 250;

    // Intensity Filter
    float OS_MIN_INTN_DIST = 30;
    float OS_MIN_INTN = 200;

    // Voxel Grid Filter
    float VG_SIZE_X = 0.5;
    float VG_SIZE_Y = 0.5;
    float VG_SIZE_Z = 0.5;

    // Crop Box Filter
    float PASS_LIMIT_XP = 3.5;
    float PASS_LIMIT_XN = -3.5;
    float PASS_LIMIT_YP = 2.0;
    float PASS_LIMIT_YN = -2.0;
    float PASS_LIMIT_ZP = 10.0;
    float PASS_LIMIT_ZN = -10.0;

    // Denoise Filter                               (optional)
    bool DENOISE = false;
    int MEAN_K = 3;
    float THRESH = 0.01;

    // Euclidean Distance Clustering                (optional)
    bool LOG_SCALE = false;
    float EC_TOLERANCE = LOG_SCALE ? 0.05 : 3.0;
    int EC_MIN = 5;
    int EC_MAX = 500;

    // Cluster Height Filter
    float TARGET_TOP_HEIGHT_MAX = 0.3;
    float TARGET_TOP_HEIGHT_MIN = 0.3;

    // Cluster Z Position Filter                    (optional)
    bool GLOBAL_Z_FILTER = false;
    float LIDAR_TILT_BIAS = 2; // Degree
    float PCL_GROUND_Z_BOUND = 0.4;

    // CAM FOV Filter                               (optional)
    bool CAM_FOV_FITLER = false;                    
    float CAM_FOV_HORIZONTAL = 90 * M_PI/180;
    float CAM_FOV_VERTICAL = 60 * M_PI/180;
    float CAM_ALPHA = 30 * M_PI/180;
    float A_BY_WIDTH = 0.7;
    float B_BY_HEIGHT = 0.3;

    // Nukhada Tail Filter                          (optional)
    bool TAIL_FILTER = false;
    float TAIL_ANGLE = 30 * M_PI/180;
};

#endif // LiDAR_PARAMS_HPP