#!/usr/bin/python3

# Python node for object detection.
# Customized to indicate the detection of 'boat' class

import os
import cv2
import time
import random
import rospkg
from tqdm import tqdm
import rospy
import numpy as np
import argparse
from loguru import logger
import importlib
import torch
from torch.backends import cudnn

from std_msgs.msg import Int8, Int64MultiArray, Int32, Float64MultiArray, Float32
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Pose2D
from vision_msgs.msg import BoundingBox2D, Detection2D, Detection2DArray
from cv_bridge import CvBridge, CvBridgeError

from damo.base_models.core.ops import RepConv
from damo.detectors.detector import build_local_model
from damo.utils import vis
from damo.utils.demo_utils import transform_img
from damo.structures.image_list import ImageList
from damo_configs import (
    damoyolo_tinynasL18_Ns,
    damoyolo_tinynasL18_Nm,
    damoyolo_tinynasL20_Nl,
    damoyolo_tinynasL20_N,
    damoyolo_tinynasL20_T,
    damoyolo_tinynasL25_S,
    damoyolo_tinynasL35_M,
    damoyolo_tinynasL45_L,
)

use_cuda = True
backbone = "damoyolo_tinynasL35_M"
conf = 0.6
infer_size = [320, 320]
save_result = False

tick = 0
if tick:
    starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)

class DetectionNode():

    def __init__(self):

        self.use_cuda = use_cuda
        self.tick = tick
        # self.base_path = "/home/developer/mbzirc_ros/src/MBZIRC2023/"
        # self.ckpt_path = self.base_path + "src/inspection/ship_detecting/weights/" + backbone + ".pth"

        # Find the path to your ROS package
        rospack = rospkg.RosPack()
        package_path = rospack.get_path('ship_detecting')  # replace with your package name
        self.ckpt_path = os.path.join(package_path, 'weights/' + backbone + ".pth")

        self.config = importlib.import_module("damo_configs." + backbone).Config()
        self.output_dir = os.path.join(package_path, 'test_imgs/damo_result')
        self.output_file = "result1.png"
        self.save_result = save_result
        self.conf = conf

        os.makedirs(self.output_dir, exist_ok=True)
        self.device = 'cuda' if torch.cuda.is_available() and self.use_cuda else 'cpu'

        if "class_names" in self.config.dataset:
            self.class_names = self.config.dataset.class_names
        else:
            self.class_names = []
            for i in range(self.config.model.head.num_classes):
                self.class_names.append(str(i))
            self.class_names = tuple(self.class_names)

        self.infer_size = infer_size
        self.config.dataset.size_divisibility = 0
        self.model = self._build_engine(self.config)

        self.bridge = CvBridge()
        self.img_sub_1 = rospy.Subscriber('/usv/slot3/image_raw', Image, callback = self.img_cb, queue_size = 1, callback_args=0) ###/camera1/image
        self.img_sub_2 = rospy.Subscriber('/usv/slot3/image_raw', Image, callback = self.img_cb, queue_size = 1, callback_args=1) ###/camera2/image
        # self.tsp_counter_changer = rospy.Subscriber('/reid/pass_N', Int32, callback = self.n_changer_cb, queue_size = 1)
        self.dummmy_similarities = rospy.Subscriber('/reid/sim_arr', Float64MultiArray, callback = self.sim_arr_cb, queue_size = 1)
        self.tsp_id_sub = rospy.Subscriber('/wp_id', Float32, callback = self.tsp_cb, queue_size = 1)
        self.bbox_pub1 = rospy.Publisher('/detection_bbox1', Detection2DArray, queue_size = 1)
        self.bbox_pub2 = rospy.Publisher('/detection_bbox2', Detection2DArray, queue_size = 1)
        self.result_pub1 = rospy.Publisher('/detection_image1/compressed', CompressedImage, queue_size = 1)
        self.result_pub2 = rospy.Publisher('/detection_image2/compressed', CompressedImage, queue_size = 1)
        self.id_sim_pub = rospy.Publisher('/trg_info', Float64MultiArray, queue_size = 1)

        # ######################################################
        # self.tsp_count = 1 # N개 거르고 N+1번째 Re-ID=1
        self.tsp_count = -1 # 몇번째 타겟인지 확인
        # self.target_sim = 0.0
        self.sim_arr = Float64MultiArray()

        self.prev_flag_stage = 0
        self.flag_stage = 0
        self.tsp_id = 0
        self.flag5_on = False
        self.flag_in = rospy.Subscriber('/usv_flag', Int32, callback = self.flag_cb, queue_size=1)
        self.flag_out = rospy.Publisher('/flag_5', Int32, queue_size=1)
        self.total_counter = 0
        self.overflow_counter = 0
        self.overflow_maximum = 600
        self.valid_range = np.zeros((200,)) # 총 Detection Bin
        self.valid_portion = 0.6 # 총 Detection Bin에 '1'이 valid_portion 만큼 차면 Detected=1

    def _pad_image(self, img, target_size):

        n, c, h, w = img.shape
        assert n == 1
        assert h<=target_size[0] and w<=target_size[1]
        target_size = [n, c, target_size[0], target_size[1]]
        pad_imgs = torch.zeros(*target_size)
        pad_imgs[:, :c, :h, :w].copy_(img)

        img_sizes = [img.shape[-2:]]
        pad_sizes = [pad_imgs.shape[-2:]]

        return ImageList(pad_imgs, img_sizes, pad_sizes)

    def _build_engine(self, config):

        model = build_local_model(config, self.device)
        ckpt = torch.load(self.ckpt_path, map_location=self.device)
        model.load_state_dict(ckpt['model'], strict=True)

        for layer in model.modules():
            if isinstance(layer, RepConv):
                layer.switch_to_deploy()

        model.eval()

        dumy_input = torch.ones((1, 3, self.infer_size[0], self.infer_size[1])).cuda(self.device)
        _ = model(dumy_input)

        return model

    def preprocess(self, origin_img):

        img = transform_img(origin_img, 0,
                            **self.config.test.augment.transform,
                            infer_size=self.infer_size)
                            
        # img is a image_list
        oh, ow, _  = origin_img.shape
        img = self._pad_image(img.tensors, self.infer_size)
        img = img.to(self.device)

        return img, (ow, oh)

    def postprocess(self, preds, origin_shape=None):
        
        output = preds[0].resize(origin_shape)
        bboxes = output.bbox
        scores = output.get_field('scores')
        cls_inds = output.get_field('labels')

        return bboxes,  scores, cls_inds

    def forward(self, origin_image):

        image, origin_shape = self.preprocess(origin_image)
        output = self.infer(image)
        bboxes, scores, cls_inds = self.postprocess(output, origin_shape=origin_shape)

        return bboxes, scores, cls_inds

    def infer(self, image):
        if tick:
            starter.record()
            output = self.model(image)
            ender.record()
            torch.cuda.synchronize()
            curr_time = starter.elapsed_time(ender)
            print("{} took for INFERENCE".format(curr_time))
        else:
            output = self.model(image)

        return output

    def visualize(self, image, bboxes, scores, cls_inds, conf, save_name='vis.jpg', save_result=True):
        vis_img = vis(image, bboxes, scores, cls_inds, conf, self.class_names)
        if save_result:
            save_path = os.path.join(self.output_dir, save_name)
            print(f"save visualization results at {save_path}")
            cv2.imwrite(save_path, vis_img[:, :, ::-1])
        return vis_img

    def img_cb(self, data, args):
        # print(self.flag_stage)

        if (self.flag_stage >= 4):
            if (self.prev_flag_stage != self.flag_stage):
                # self.tsp_count -= 1
                self.tsp_count += 1
                self.prev_flag_stage = self.flag_stage

            if (self.tsp_count >= len(self.sim_arr.data)):
                self.tsp_count = -1

            # try:
            #     np_arr = np.fromstring(data.data, np.uint8)
            #     origin_img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
                
            # except CvBridgeError as e:
            #     print(e)

            origin_img = self.bridge.imgmsg_to_cv2(data, desired_encoding="passthrough")

            # rospy.loginfo("Received image {}".format(args))

            bboxes, scores, cls_inds = self.forward(origin_img)
            vis_img = self.visualize(origin_img, bboxes, scores, cls_inds, conf=self.conf, save_name=self.output_file, save_result=save_result)

            bbox_img = CompressedImage()
            bbox_img.header = data.header
            bbox_img.data = np.array(cv2.imencode('.jpg', vis_img)[1]).tobytes()

            add_cnt = 0
            det_arr = Detection2DArray()
            for i in range(len(bboxes)):
                box = bboxes[i]
                cls_id = int(cls_inds[i]) # for identifying boat

                score = scores[i]
                if score < self.conf:
                    continue
                x0 = int(box[0])
                y0 = int(box[1])
                x1 = int(box[2])
                y1 = int(box[3])
                
                bbox = BoundingBox2D()
                bbox.center.x = float((x0 + x1)/2)
                bbox.center.y = float((y0 + y1)/2)
                bbox.center.theta = 0.0
                bbox.size_x = float(2*(bbox.center.x - x0))
                bbox.size_y = float(2*(bbox.center.y - y0))

                det = Detection2D()
                det.header = data.header
                det.bbox = bbox

                det_arr.header = data.header
                det_arr.detections.append(det)

                if (cls_id==8):
                    add_cnt = 1

                    # if score > self.target_sim:
                    #     self.target_sim = score

            img_pub = self.result_pub2 if args else self.result_pub1
            box_pub = self.bbox_pub2 if args else self.bbox_pub1
            img_pub.publish(bbox_img)
            box_pub.publish(det_arr)

            if add_cnt:
                self.valid_range[self.total_counter] = 1
            else:
                self.valid_range[self.total_counter] = 0

            # 1 counter per frame
            self.total_counter += 1
            if (self.total_counter >= (self.valid_range.shape[0]-1)):
                self.total_counter = 0

            # 1 time-overflow counter per frame
            self.overflow_counter += 1

            if (self.flag5_on) or ((np.sum(self.valid_range)/(self.valid_range.shape[0])) > self.valid_portion):
                
                self.flag5_on = True

                # ### HOW MANY SHIPS TO PASS VIA TSP?
                # flag5 = Int32()
                # if self.tsp_count > -1:
                #     flag5.data = 0
                #     self.flag_out.publish(flag5)
                # elif self.tsp_count == -1:
                #     flag5.data = 1
                #     self.flag_out.publish(flag5)

                #     target_id_sim = Float64MultiArray()
                #     target_id_sim.data.append(self.tsp_id)
                #     target_id_sim.data.append(self.target_sim)
                #     self.id_sim_pub.publish(target_id_sim)
                #     target_id_sim.data.clear()

                # else:
                #     flag5.data = 0
                #     self.flag_out.publish(flag5)

                # print("Current self.tsp_count: ", self.tsp_count)
                
                flag5 = Int32()
                flag5.data = 1
                self.flag_out.publish(flag5)

                target_id_sim = Float64MultiArray()
                target_id_sim.data.append(self.tsp_id)
                target_id_sim.data.append(self.sim_arr.data[self.tsp_count])
                self.id_sim_pub.publish(target_id_sim)
                target_id_sim.data.clear()
                
                print("Current ID & Similarity: ", self.tsp_id, " & ", self.sim_arr.data[self.tsp_count])
                print("Publish /flag_5: ", flag5.data)
            elif (self.overflow_counter > self.overflow_maximum):
                flag5 = Int32()
                flag5.data = 1
                self.flag_out.publish(flag5)

                target_id_sim = Float64MultiArray()
                target_id_sim.data.append(self.tsp_id)
                target_id_sim.data.append(self.sim_arr.data[self.tsp_count])
                self.id_sim_pub.publish(target_id_sim)
                target_id_sim.data.clear()
                
                print("(DUMMY) Current ID & Similarity: ", self.tsp_id, " & ", self.sim_arr.data[self.tsp_count])
                print("(DUMMY) Publish /flag_5: ", flag5.data)
            else:
                print("Detected Frame Count: ", np.sum(self.valid_range))
                print("Total    Frame Count: ", self.total_counter)
                print("Time  Overflow Count: ", self.overflow_counter)



        else:
            self.prev_flag_stage = self.flag_stage
            self.flag5_on = False
            self.overflow_counter = 0
            self.total_counter = 0
            self.valid_range = np.zeros((self.valid_range.shape[0],))
            print("NODE OFF")
            pass


    def flag_cb(self, msg):
        self.flag_stage = msg.data

    def tsp_cb(self, msg):
        self.tsp_id = msg.data

    def sim_arr_cb(self, msg):
        if self.flag_stage == 0:
            self.sim_arr = msg

            to_print_arr = "[ "
            for idx, similarity in enumerate(self.sim_arr.data):
                if idx == (len(self.sim_arr.data)-1):
                    to_print_arr += str(similarity)
                    to_print_arr += " ]"
                else:
                    to_print_arr += str(similarity)
                    to_print_arr += " , "

            rospy.loginfo("Pass Similarity {} ..".format(to_print_arr))

    def n_changer_cb(self, msg):
        if self.flag_stage == 0:
            self.tsp_count = msg.data
            rospy.loginfo("Pass N = [ {} ] targets from TSP solver..".format(self.tsp_count))



def main():

    nh_name = 'ship_detecting'
    rospy.init_node(nh_name)
    rospy.loginfo("[{}] node created".format(nh_name))
    detection_node = DetectionNode()
    rospy.spin()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
