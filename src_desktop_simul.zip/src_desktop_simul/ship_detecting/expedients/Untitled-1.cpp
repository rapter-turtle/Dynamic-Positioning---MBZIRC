
    for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it) {
        if ((it->indices.size()) != 0){


            Eigen::MatrixXf pcl_matrix(it->indices.size(), 3);

            pcl_matrix.setZero();

            int i = 0;
            pcl::PointCloud<pcl::PointXYZI> clusterCloud;
            for (std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit) {
                pcl::PointXYZI pt = cloud_filtered_original->points[*pit];
                pt.intensity = (float)(j + 1);
                clusterCloud.push_back(pt);
                
                pcl_matrix(i, 0) = pt.x;
                pcl_matrix(i, 1) = pt.y;
                pcl_matrix(i, 2) = pt.z;

                i++;
            }

            bool keepCluster = true;

            Eigen::Vector3f com;
            com.setZero();
            com(0) = (pcl_matrix.col(0).maxCoeff()+pcl_matrix.col(0).minCoeff())/2;
            com(1) = (pcl_matrix.col(1).maxCoeff()+pcl_matrix.col(1).minCoeff())/2;

            Eigen::Vector3f axis_radius;
            axis_radius.setZero();
            axis_radius(0) = (pcl_matrix.col(0).maxCoeff()-pcl_matrix.col(0).minCoeff())/2;
            axis_radius(1) = (pcl_matrix.col(1).maxCoeff()-pcl_matrix.col(1).minCoeff())/2;
            int longer_axis = axis_radius(1)>axis_radius(0)?1:0;
            int shorter_axis = 1 - longer_axis;
            int bin_number = 5;
            float bin_size = (float)(axis_radius(longer_axis)/bin_number);

            Eigen::MatrixXf centered = pcl_matrix.rowwise() - com.transpose();
            Eigen::MatrixXf edge_pos(bin_number*2, 2);
            edge_pos.col(0).setConstant(centered.col(shorter_axis).maxCoeff()+1.0);
            edge_pos.col(1).setConstant(centered.col(shorter_axis).minCoeff()-1.0);
            for (int i=0; i<centered.rows(); i++){
                int n_b = std::floor(centered(i, longer_axis)/bin_size) + bin_number;

                if (centered(i, shorter_axis) < edge_pos(n_b, 0)){
                    edge_pos(n_b, 0) = centered(i, shorter_axis);
                }
                if (centered(i, shorter_axis) > edge_pos(n_b, 1)){
                    edge_pos(n_b, 1) = centered(i, shorter_axis);
                }
            }
            
            Eigen::MatrixXf outline(bin_number*4, 3);
            outline.setZero();
            for (int i=0; i<bin_number*2; i++){
                if (edge_pos(i,0 > centered.col(shorter_axis).maxCoeff())){
                    continue;
                }
                if (edge_pos(i,1 < centered.col(shorter_axis).minCoeff())){
                    continue;
                }

                outline(i*2, longer_axis) = (0.5 - bin_number + i) * bin_size;
                outline(i*2, shorter_axis) = edge_pos(i,0);
                outline(i*2+1, longer_axis) = outline(i*2, longer_axis);
                outline(i*2+1, shorter_axis) = edge_pos(i,1);
            }
            Eigen::MatrixXf covariance = (outline.adjoint() * outline) / (float)(outline.rows() - 1);
            Eigen::EigenSolver<Eigen::MatrixXf> solver(covariance);
            Eigen::VectorXf eigenValues = solver.eigenvalues().real();
            Eigen::MatrixXf eigenvectors = solver.eigenvectors().real();
            
            std::vector<std::pair<float, int>> eigen_pairs(3);
            for (int i = 0; i < 3; ++i) {
                eigen_pairs[i] = std::make_pair(eigenValues[i], i);
            }
            std::sort(eigen_pairs.begin(), eigen_pairs.end(), std::greater<>());

            Eigen::VectorXf sorted_eigenvalues(3);
            Eigen::MatrixXf sorted_eigenvectors(3, 3);
            for (int i = 0; i < 3; ++i) {
                sorted_eigenvalues[i] = eigen_pairs[i].first;
                sorted_eigenvectors.col(i) = eigenvectors.col(eigen_pairs[i].second);
            }
            Eigen::MatrixXf pcl_matrix_coordinated = (eigenvectors.transpose() * pcl_matrix.transpose()).transpose();
            float height = pcl_matrix_coordinated.col(2).maxCoeff() - pcl_matrix_coordinated.col(2).minCoeff();
            float cluster_distance = com[0]*com[0] + com[1]*com[1];
            float min_d = 5.0;
            float max_d = 20.0;
            if (cluster_distance < max_d*max_d){
                if (height < (lp.TARGET_TOP_HEIGHT_MAX-lp.TARGET_TOP_HEIGHT_MIN)/((max_d-min_d)*(cluster_distance-min_d)) + lp.TARGET_TOP_HEIGHT_MIN){
                    keepCluster = false;
                }
            }else{
                if (height < lp.TARGET_TOP_HEIGHT_MAX){
                    keepCluster = false;
                }
            }
        } // < --- Here
        j++;
    }