#!/usr/bin/env python
import rospy
from std_msgs.msg import Int32, Float32, Float64MultiArray, Float32MultiArray


# When flag is 6, send highest similarity target ID 

class Mode_manager:
    def __init__(self):
        self.mode = 0
        self.id_similarity = []
        self.usv_flag= 0 
        self.threshold = 0.2
        self.M = 4
        self.N = 2
        self.trg_num = 7
        self.global_track_list = []
        
        self.publisher_HID = rospy.Publisher('wp_id',Float32,queue_size=10)
        self.publisher_mode = rospy.Publisher('mode_state',Int32,queue_size=10)

        rospy.Subscriber("trg_info", Float64MultiArray,self.trg_callback)
        rospy.Subscriber("usv_flag",Int32,self.usv_flag_callback)
        rospy.Subscriber("global_track",Float32MultiArray,self.global_track_callback)
        rospy.Subscriber("reset",Int32,self.reset_callback)
        rospy.Subscriber("threshold",Float32,self.threshold_callback)
        rospy.Subscriber("M",Int32,self.M_callback)
        rospy.Subscriber("N",Int32,self.N_callback)


    def trg_callback(self, msg):
        if self.mode == 0:
            append = -1
            ##stack highest similarity even if the same id 
            if len(self.id_similarity) >0:
                for i in range(int(len(self.id_similarity))):
                    if self.id_similarity[i][0] == msg.data[0]:
                        append = i

            if append == -1:
                self.id_similarity.append([msg.data[0], msg.data[1]]) 
                self.id_similarity = sorted(self.id_similarity, key=lambda x: x[1], reverse=True)
                print(self.id_similarity)

            elif append > -1:
                if self.id_similarity[append][1] < msg.data[1]:
                    self.id_similarity[append][1] = msg.data[1] 
                    print(self.id_similarity)

    def usv_flag_callback(self, msg):
        self.usv_flag = msg.data

    ##reset mode 
    def reset_callback(self, msg):
        if msg.data == 1:
            self.id_similarity = []
            self.mode = 0

    def global_track_callback(self, msg):
        self.trg_num = msg.data[2]
        self.global_track_list = msg.data


    def threshold_callback(self, msg):
        self.threshold = msg.data
    def M_callback(self, msg):
        self.M = msg.data
    def N_callback(self, msg):
        self.N = msg.data

    def publish_wp_hid(self):
        # find = 0
        msg_1 = Float32()
        # for i in range(int(self.trg_num)):
        #     if self.id_similarity[0][0] == self.global_track_list[3+5*i]:
        #         find = 1

        # if find == 0:
        #     self.mode = 0
        #     highest_similarity_id = -1
        #     msg_1.data = float(highest_similarity_id)
        #     self.publisher_HID.publish(msg_1)
        #     msg_2 = Int32()
        #     msg_2.data = self.mode
        #     self.publisher_mode.publish(msg_2)


        # elif find == 1:  # Check if the list is not empty
        
        highest_similarity_id = self.id_similarity[0][0]  # Assuming first element is the highest ID
        if self.usv_flag == 6:
            msg_1.data = float(highest_similarity_id)
            self.publisher_HID.publish(msg_1)
            self.id_similarity = self.id_similarity[1:]
            self.mode = 0
        

    def publish_mode(self):
        if self.mode == 0:
            if len(self.id_similarity) < self.M:
                self.mode = 0
            elif len(self.id_similarity) >= self.M and len(self.id_similarity) < self.trg_num:
                if self.id_similarity[self.N-1][1] - self.id_similarity[self.N][1] > self.threshold:
                    self.mode = 1
                else:
                    self.mode = 0
            elif len(self.id_similarity) == self.trg_num:
                self.mode = 1
        
        msg = Int32()
        msg.data = self.mode
        self.publisher_mode.publish(msg)

        

if __name__ == '__main__':
    rospy.init_node('mode_manager')
    mode_manager = Mode_manager()
    rate = rospy.Rate(10)  # 10Hz
    try:
        while not rospy.is_shutdown():
            if mode_manager.usv_flag == 5:
                mode_manager.publish_mode()

            if mode_manager.usv_flag == 6 and mode_manager.mode == 1:
                mode_manager.publish_wp_hid()

            rate.sleep()
    except rospy.ROSInterruptException:
        pass
