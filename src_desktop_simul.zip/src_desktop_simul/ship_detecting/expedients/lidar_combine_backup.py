#!/usr/bin/python3

import rospy as rp
import numpy as np
import pcl
import pcl_python_helper as ph
from scipy.spatial.transform import Rotation as R
from sensor_msgs.msg import PointCloud2, PointField

class LiDAR_Combinator():
    def __init__(self):
        ######## User Defined ############################
        nh_name = 'lidar_combinator'
        self.frame = "os_sensor"
        self.ouster1_name = "/ouster1/points"
        self.ouster2_name = "/ouster2/points"
        self.ouster_comb_name = "/ouster_combined/points"
        ##################################################

        rp.init_node(nh_name)
        rp.loginfo("[{}] node created".format(nh_name))

        self.is_pub_on = False

        self.ouster1_pcl = None
        self.ouster2_pcl = None
        self.ouster1_toggle = False
        self.ouster2_toggle = False
        self.ouster_precedent = "REV_what?"
        self.ouster_following = "REV_what?"

        self.ouster1_sub = rp.Subscriber(self.ouster1_name, PointCloud2, self.update_ouster1, queue_size=1)
        self.ouster2_sub = rp.Subscriber(self.ouster2_name, PointCloud2, self.update_ouster2, queue_size=1)
    
    def update_ouster1(self,ouster1_rosmsg):
        self.ouster1_pcl = ph.ros_to_pcl(ouster1_rosmsg)
        if not self.ouster1_toggle:
            self.ouster1_toggle = True
            self.ouster_following = self.ouster1_name
        if self.ouster1_toggle and self.ouster2_toggle:
            if self.ouster_following == self.ouster1_name:
                self.ouster_precedent = self.ouster2_name
                self.main_combinator()

    def update_ouster2(self,ouster2_rosmsg):
        self.ouster2_pcl = ph.ros_to_pcl(ouster2_rosmsg)
        self.ouster1_toggle = True
        if not self.ouster2_toggle:
            self.ouster2_toggle = True
            self.ouster_following = self.ouster2_name
        if self.ouster1_toggle and self.ouster2_toggle:
            if self.ouster_following == self.ouster2_name:
                self.ouster_precedent = self.ouster1_name
                self.main_combinator()
        
    def main_combinator(self):
        if self.ouster1_pcl is not None and self.ouster2_pcl is not None:

            # Step 1: Transform the pcl from ouster2
            r = R.from_euler('z', 180, degrees=True)
            ouster2_points_3d = np.asarray(self.ouster2_pcl)[:,0:3].T
            ouster2_points_In = np.asarray(self.ouster2_pcl)[:,2:3]
            ouster2_points_3d_rotated = (r.as_matrix()@ouster2_points_3d).T
            new_ouster2_pcl = np.append(ouster2_points_3d_rotated,ouster2_points_In,1)

            # Step 2: Concatenate the pcl from two LiDARs
            lidar_comb_pub = rp.Publisher(self.ouster_comb_name, PointCloud2, queue_size=1)
            lidar_comb_pcl = pcl.PointCloud_PointXYZRGB()
            lidar_comb_pcl.from_array(np.append(np.asarray(self.ouster1_pcl),np.asarray(new_ouster2_pcl).astype('float32'),0))
            lidar_comb_msg = ph.pcl_to_ros(lidar_comb_pcl)
            lidar_comb_msg.header.frame_id = self.frame
            lidar_comb_pub.publish(lidar_comb_msg)

        if not self.is_pub_on:
            print("--------- Publishing Topic: [{}] + [{}] = [{}] ...".format(self.ouster_precedent, self.ouster_following, self.ouster_comb_name))
            self.is_pub_on = True

if __name__=="__main__":
    try:
        lidar_combinator = LiDAR_Combinator()
        rp.spin()
    except rp.ROSInterruptException:
        pass