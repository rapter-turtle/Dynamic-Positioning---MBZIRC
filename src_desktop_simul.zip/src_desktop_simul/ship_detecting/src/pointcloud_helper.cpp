// Mathematical functions to help pointcloud manipulation

#include "lidar_params.hpp"

Eigen::MatrixXf pcl_to_eigen(const pcl::PointCloud<pcl::PointXYZI>::ConstPtr& pcl){
    Eigen::MatrixXf eigen;

    int numPoints = pcl->points.size();
    eigen.setZero(numPoints, 4);

    for(int i = 0; i < numPoints; i++) {
        eigen(i, 0) = pcl->points[i].x;
        eigen(i, 1) = pcl->points[i].y;
        eigen(i, 2) = pcl->points[i].z;
        eigen(i, 3) = pcl->points[i].intensity;
    }

    return eigen;
}

Eigen::MatrixXf rotate_matrix(const Eigen::MatrixXf mat, float theta_custom, float TOP_BOARD_LENGTH, float TOP_BOARD_WIDTH){
    Eigen::MatrixXf mat_copy = mat;
    float theta = theta_custom * M_PI/180;
    Eigen::Matrix3f rotation;
    rotation << cos(theta), -sin(theta), 0,
                sin(theta),  cos(theta), 0,
                        0,          0, 1;
    float dx = TOP_BOARD_LENGTH/2, dy = -TOP_BOARD_WIDTH/2;
    Eigen::Vector3f translation(dx, dy, 0);
    for (int i = 0; i < mat_copy.rows(); ++i) {
        Eigen::Vector3f point(mat_copy(i, 0), mat_copy(i, 1), mat_copy(i, 2));
        Eigen::Vector3f transformed = rotation * point + translation;
        mat_copy(i, 0) = transformed(0);
        mat_copy(i, 1) = transformed(1);
        mat_copy(i, 2) = transformed(2);
    }

    return mat_copy;
}

Eigen::MatrixXf extract_sorted_eigenvectors(Eigen::MatrixXf cluster){
    Eigen::MatrixXf covariance = (cluster.adjoint() * cluster) / (float)(cluster.rows() - 1);
    Eigen::EigenSolver<Eigen::MatrixXf> solver(covariance);
    Eigen::VectorXf eigenvalues = solver.eigenvalues().real();
    Eigen::MatrixXf eigenvectors = solver.eigenvectors().real();
    
    std::vector<std::pair<float, int>> eigen_pairs(3);
    for (int i = 0; i < 3; ++i) {
        eigen_pairs[i] = std::make_pair(eigenvalues[i], i);
    }
    std::sort(eigen_pairs.begin(), eigen_pairs.end(), std::greater<>());

    Eigen::VectorXf sorted_eigenvalues(3);
    Eigen::MatrixXf sorted_eigenvectors(3, 3);
    for (int i = 0; i < 3; ++i) {
        sorted_eigenvalues[i] = eigen_pairs[i].first;
        sorted_eigenvectors.col(i) = eigenvectors.col(eigen_pairs[i].second);
    }
    
    return sorted_eigenvectors;
}

Eigen::MatrixXf cluster_to_contour(Eigen::MatrixXf cluster_matrix, Eigen::Vector3f com){
    Eigen::Vector3f axis_radius;
    axis_radius.setZero();
    axis_radius(0) = (cluster_matrix.col(0).maxCoeff()-cluster_matrix.col(0).minCoeff())/2;
    axis_radius(1) = (cluster_matrix.col(1).maxCoeff()-cluster_matrix.col(1).minCoeff())/2;

    int longer_axis = axis_radius(1)>axis_radius(0)?1:0;
    int shorter_axis = 1 - longer_axis;
    int bin_number = 5;
    float bin_size = (float)(axis_radius(longer_axis)/bin_number);
    int plot_number = 10;
    float plot_size = (float)(axis_radius(shorter_axis)/plot_number);

    Eigen::MatrixXf centered = cluster_matrix.rowwise() - com.transpose();
    Eigen::MatrixXf edge_pos(bin_number*2, 3);
    edge_pos.col(0).setConstant(centered.col(shorter_axis).maxCoeff()+1.0);
    edge_pos.col(1).setConstant(centered.col(shorter_axis).minCoeff()-1.0);
    edge_pos.col(2).setZero();

    for (int i=0; i<centered.rows(); i++){
        // check bin number (n_b)
        int n_b = (int) std::floor(centered(i, longer_axis)/bin_size) + bin_number;
        
        if(n_b >= edge_pos.rows()){
            n_b = edge_pos.rows() - 1;
        }
        
        if(n_b < 0){
            n_b = 0;
        }

        // get the pos of shorter axis (y)
        if (centered(i, shorter_axis) < edge_pos(n_b, 0)){
            edge_pos(n_b, 0) = centered(i, shorter_axis);
        }
        
        if (centered(i, shorter_axis) > edge_pos(n_b, 1)){
            edge_pos(n_b, 1) = centered(i, shorter_axis);
        }
    }

    int n_outline = 0;
    for (int i=0; i<bin_number*2; i++){
        if (edge_pos(i,0) > centered.col(shorter_axis).maxCoeff()){
            continue;
        }
        
        if (edge_pos(i,1) < centered.col(shorter_axis).minCoeff()){
            continue;
        }
        
        int plot_num = (int) std::floor((edge_pos(i,1) - edge_pos(i,0)) / plot_size)-1;
        if(plot_num < 0){
            plot_num = 0;
        }
        
        n_outline += plot_num + 2;
    }

    Eigen::MatrixXf outline(n_outline, 3);
    outline.setZero();
    int pc_outline=0;
    for (int i=0; i<bin_number*2; i++){
        if (edge_pos(i,0) > centered.col(shorter_axis).maxCoeff()){
            continue;
        }
        if (edge_pos(i,1) < centered.col(shorter_axis).minCoeff()){
            continue;
        }

        int plot_num = (int) std::floor((edge_pos(i,1) - edge_pos(i,0)) / plot_size)-1;
        if(plot_num < 0){
            plot_num = 0;
        }

        outline(pc_outline, longer_axis) = (0.5 - bin_number + i) * bin_size;
        outline(pc_outline, shorter_axis) = edge_pos(i, 0);
        pc_outline++;

        outline(pc_outline, longer_axis) = (0.5 - bin_number + i) * bin_size;
        outline(pc_outline, shorter_axis) = edge_pos(i, 1);
        pc_outline++;
        
        for (int ii=0; ii<plot_num;ii++){
            outline(pc_outline, longer_axis) = (0.5 - bin_number + i) * bin_size;
            outline(pc_outline, shorter_axis) = (ii + 1) * (edge_pos(i,1)- edge_pos(i,0)) / (plot_num+1) + edge_pos(i,0);
            pc_outline++;
        }
    }

    return outline;
}