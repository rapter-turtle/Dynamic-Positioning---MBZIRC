########################## Immediate Publisher ######################
#     obbox_temp = PolygonStamped()
#     obbox_temp.header.frame_id = self.frame
#     crn1 = Point32();crn2 = Point32();crn3 = Point32();crn4 = Point32()
#     crn5 = Point32();crn6 = Point32();crn7 = Point32();crn8 = Point32()

#     box_orientation_dimension = "2D_Projected" # 3D or 2D_Projected
#     if box_orientation_dimension == "3D":
#         crn1.x, crn1.y, crn1.z = com - length_half*eigenvectors[:,0] - width_half*eigenvectors[:,1] - height_half*eigenvectors[:,2]
#         crn2.x, crn2.y, crn2.z = com - length_half*eigenvectors[:,0] - width_half*eigenvectors[:,1] + height_half*eigenvectors[:,2]
#         crn3.x, crn3.y, crn3.z = com - length_half*eigenvectors[:,0] + width_half*eigenvectors[:,1] - height_half*eigenvectors[:,2]
#         crn4.x, crn4.y, crn4.z = com - length_half*eigenvectors[:,0] + width_half*eigenvectors[:,1] + height_half*eigenvectors[:,2]
#         crn5.x, crn5.y, crn5.z = com + length_half*eigenvectors[:,0] - width_half*eigenvectors[:,1] - height_half*eigenvectors[:,2]
#         crn6.x, crn6.y, crn6.z = com + length_half*eigenvectors[:,0] - width_half*eigenvectors[:,1] + height_half*eigenvectors[:,2]
#         crn7.x, crn7.y, crn7.z = com + length_half*eigenvectors[:,0] + width_half*eigenvectors[:,1] - height_half*eigenvectors[:,2]
#         crn8.x, crn8.y, crn8.z = com + length_half*eigenvectors[:,0] + width_half*eigenvectors[:,1] + height_half*eigenvectors[:,2]
#     elif box_orientation_dimension == "2D_Projected":
#         eigvec_0_2D = np.asarray([eigenvectors[:,0][0],eigenvectors[:,0][1],0.0]); eigvec_0_2D = eigvec_0_2D / np.linalg.norm(eigvec_0_2D)
#         eigvec_1_2D = Rotation.from_euler('z', 90, degrees=True).as_matrix()@eigvec_0_2D; eigvec_1_2D = eigvec_1_2D / np.linalg.norm(eigvec_1_2D)
#         eigvec_2_2D = np.asarray([0.0,0.0,1.0])
#         crn1.x, crn1.y, crn1.z = com - length_half*eigvec_0_2D - width_half*eigvec_1_2D - height_half*eigvec_2_2D
#         crn2.x, crn2.y, crn2.z = com - length_half*eigvec_0_2D - width_half*eigvec_1_2D + height_half*eigvec_2_2D
#         crn3.x, crn3.y, crn3.z = com - length_half*eigvec_0_2D + width_half*eigvec_1_2D - height_half*eigvec_2_2D
#         crn4.x, crn4.y, crn4.z = com - length_half*eigvec_0_2D + width_half*eigvec_1_2D + height_half*eigvec_2_2D
#         crn5.x, crn5.y, crn5.z = com + length_half*eigvec_0_2D - width_half*eigvec_1_2D - height_half*eigvec_2_2D
#         crn6.x, crn6.y, crn6.z = com + length_half*eigvec_0_2D - width_half*eigvec_1_2D + height_half*eigvec_2_2D
#         crn7.x, crn7.y, crn7.z = com + length_half*eigvec_0_2D + width_half*eigvec_1_2D - height_half*eigvec_2_2D
#         crn8.x, crn8.y, crn8.z = com + length_half*eigvec_0_2D + width_half*eigvec_1_2D + height_half*eigvec_2_2D

#     obbox_temp.polygon.points.append(crn1); obbox_temp.polygon.points.append(crn2)
#     obbox_temp.polygon.points.append(crn4); obbox_temp.polygon.points.append(crn3)
#     obbox_temp.polygon.points.append(crn1); obbox_temp.polygon.points.append(crn5)
#     obbox_temp.polygon.points.append(crn6); obbox_temp.polygon.points.append(crn8)
#     obbox_temp.polygon.points.append(crn7); obbox_temp.polygon.points.append(crn5)
#     obbox_temp.polygon.points.append(crn6); obbox_temp.polygon.points.append(crn2)
#     obbox_temp.polygon.points.append(crn4); obbox_temp.polygon.points.append(crn8)
#     obbox_temp.polygon.points.append(crn7); obbox_temp.polygon.points.append(crn3)

#     self.obbox_pub.publish(obbox_temp)
#     #####################################################################