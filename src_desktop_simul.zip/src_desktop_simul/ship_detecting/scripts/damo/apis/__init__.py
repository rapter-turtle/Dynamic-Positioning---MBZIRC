# Copyright (C) Alibaba Group Holding Limited. All rights reserved.
from .detector_trainer import Trainer
