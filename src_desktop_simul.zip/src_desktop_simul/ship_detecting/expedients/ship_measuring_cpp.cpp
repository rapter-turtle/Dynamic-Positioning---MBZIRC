#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Int32.h"
#include "sensor_msgs/PointCloud2.h"
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <sstream>
#include <thread>
#include <chrono>
#include <cmath>

#include <pcl/conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/features/normal_3d.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/crop_box.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>

#include <Eigen/Dense>
#include <vector>
#include <numeric>
#include <algorithm>
using namespace std;

// Launch Parameters
float LEAF_X;
float LEAF_Y;
float LEAF_Z;
float PASS_LIMIT_XP;
float PASS_LIMIT_XN;
float PASS_LIMIT_YP;
float PASS_LIMIT_YN;
float PASS_LIMIT_ZP;
float PASS_LIMIT_ZN;
float EC_TOLERANCE;
float EC_MIN;
float EC_MAX;
float TOP_BOARD_WIDTH;
float TARGET_TOP_HEIGHT_MAX;
float TARGET_TOP_HEIGHT_MIN;
float CAM_ALPHA;
std::string FRAME_ID;

// Global Variables
pcl::PointCloud<pcl::PointXYZI>::Ptr os_pcl_data(new pcl::PointCloud<pcl::PointXYZI>);
pcl::PointCloud<pcl::PointXYZI>::Ptr TotalCloud(new pcl::PointCloud<pcl::PointXYZI>);
int start_flag, meas_num, marker_num = 0;
ros::Publisher os_filtered;
ros::Publisher os_clustered;

void load_lidar_prop(ros::NodeHandle n) {
    n.getParam("/TOP_BOARD_WIDTH", TOP_BOARD_WIDTH);
    n.getParam("/TARGET_TOP_HEIGHT_MAX", TARGET_TOP_HEIGHT_MAX);
    n.getParam("/TARGET_TOP_HEIGHT_MIN", TARGET_TOP_HEIGHT_MIN);
    n.getParam("/CAM_ALPHA", CAM_ALPHA);
    n.getParam("/vg_size_x", LEAF_X);
    n.getParam("/vg_size_y", LEAF_Y);
    n.getParam("/vg_size_z", LEAF_Z);
    n.getParam("/pass_limit_xp", PASS_LIMIT_XP);
    n.getParam("/pass_limit_xn", PASS_LIMIT_XN);
    n.getParam("/pass_limit_yp", PASS_LIMIT_YP);
    n.getParam("/pass_limit_yn", PASS_LIMIT_YN);
    n.getParam("/pass_limit_zp", PASS_LIMIT_ZP);
    n.getParam("/pass_limit_zn", PASS_LIMIT_ZN);
    n.getParam("/ec_Tolerance", EC_TOLERANCE);
    n.getParam("/ec_MinSize", EC_MIN);
    n.getParam("/ec_MaxSize", EC_MAX);
    n.getParam("/FRAME_ID", FRAME_ID);
}

void cloud_cb (const sensor_msgs::PointCloud2ConstPtr& msg){
    pcl::fromROSMsg (*msg, *os_pcl_data);
}

pcl::PointCloud<pcl::PointXYZI>::Ptr filtering_function (pcl::PointCloud<pcl::PointXYZI> pcl){
    pcl::VoxelGrid<pcl::PointXYZI> vg;
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered_vg (new pcl::PointCloud<pcl::PointXYZI>);
    vg.setInputCloud (pcl.makeShared());
    vg.setLeafSize (LEAF_X, LEAF_Y, LEAF_Z);
    vg.filter(*cloud_filtered_vg);

    pcl::CropBox<pcl::PointXYZI> boxFilter;
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered_box (new pcl::PointCloud<pcl::PointXYZI>);
    boxFilter.setInputCloud(cloud_filtered_vg);
    boxFilter.setMin(Eigen::Vector4f(5, 5, 5, 1.0));
    boxFilter.setMax(Eigen::Vector4f(5, 5, 5, 1.0));
    // boxFilter.setNegative(true);
    boxFilter.filter(*cloud_filtered_box);

    // pcl::PassThrough<pcl::PointXYZI> pass;
    // pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered_ps (new pcl::PointCloud<pcl::PointXYZI>);
    // pass.setInputCloud (cloud_filtered_box);
    // pass.setFilterFieldName ("z");
    // pass.setFilterLimits (PASS_LIMIT_ZN, PASS_LIMIT_ZP);
    // pass.filter (*cloud_filtered_ps);

    sensor_msgs::PointCloud2 rosCloud;
    pcl::toROSMsg(*cloud_filtered_box, rosCloud);
    rosCloud.header.frame_id = FRAME_ID;
    os_filtered.publish(rosCloud);

    cloud_filtered_vg.reset(new pcl::PointCloud<pcl::PointXYZI>);
    return cloud_filtered_box;
}

std::vector<pcl::PointIndices> clustering_function (pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered){
    std::vector<pcl::PointIndices> cluster_indices;
    pcl::search::KdTree<pcl::PointXYZI>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZI>);
    if (cloud_filtered->points.size () > 0) {
        pcl::EuclideanClusterExtraction<pcl::PointXYZI> ec;
        tree->setInputCloud(cloud_filtered);
        ec.setClusterTolerance(EC_TOLERANCE);
        ec.setMinClusterSize(EC_MIN);
        ec.setMaxClusterSize(EC_MAX);
        ec.setSearchMethod(tree);
        ec.setInputCloud(cloud_filtered);
        ec.extract(cluster_indices);
    }
    // free memory
    tree.reset(new pcl::search::KdTree<pcl::PointXYZI>);

    return cluster_indices;
}

void lidar_detection_function (const pcl::PointCloud<pcl::PointXYZI>::ConstPtr& pcl){
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_filtered = filtering_function(*pcl);
    int points_num = cloud_filtered->points.size ();

    std::vector<pcl::PointIndices> cluster_indices = clustering_function (cloud_filtered);

    meas_num = cluster_indices.size ();

    int j = 0;
    // visualization_msgs::MarkerArray node_arr;
    for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it) {
        int numPoints = it->indices.size();


        // If the cluster is empty
        if (numPoints == 0){
            continue;
        }
        // If the cluster is NOT empty
        else{

            // 1. Change to Eigen Matrix
            Eigen::MatrixXf pcl_matrix;
            Eigen::MatrixXf pcl_matrix_4f;
            pcl_matrix.setZero(numPoints, 3);

            int i = 0;
            pcl::PointCloud<pcl::PointXYZI> clusterCloud;
            for (std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit) {
                pcl::PointXYZI pt = cloud_filtered->points[*pit];
                pt.intensity = (float)(j + 1);
                clusterCloud.push_back(pt);
                
                pcl_matrix(i, 0) = pt.x;
                pcl_matrix(i, 1) = pt.y;
                pcl_matrix(i, 2) = pt.z;

                i++;
            }

            // 2. Check the checklist
            // - Camera FOV (optional)
            // - Eigenvalue Z too small
            // - Cluster Box Height
            // - Back of my Nukhada (optional)
            bool keepCluster = true;
            Eigen::Vector3f com;
            com = pcl_matrix.colwise().mean();

            // // Camera FOV
            // float dv_theta = - atan(com[0]/(com[1]-TOP_BOARD_WIDTH/2));
            // float fov_test = CAM_ALPHA - dv_theta - M_PI/2;
            // if ((0 < fov_test) && (fov_test < -M_PI)){
            //     keepCluster = false;
            // }

            // Eigenvalue Z too small
            Eigen::MatrixXf centered = pcl_matrix.rowwise() - pcl_matrix.colwise().mean();
            Eigen::MatrixXf covariance = (centered.adjoint() * centered) / double(pcl_matrix.rows() - 1);
            Eigen::EigenSolver<Eigen::MatrixXf> solver(covariance);
            Eigen::VectorXf eigenValues = solver.eigenvalues().real();
            Eigen::MatrixXf eigenvectors = solver.eigenvectors().real();

            std::vector<std::pair<float, int>> eigen_pairs(3);
            for (int i = 0; i < 3; ++i) {
                eigen_pairs[i] = std::make_pair(eigenValues[i], i);
            }
            std::sort(eigen_pairs.begin(), eigen_pairs.end(), std::greater<>());

            Eigen::VectorXf sorted_eigenvalues(3);
            Eigen::MatrixXf sorted_eigenvectors(3, 3);
            for (int i = 0; i < 3; ++i) {
                sorted_eigenvalues[i] = eigen_pairs[i].first;
                sorted_eigenvectors.col(i) = eigenvectors.col(eigen_pairs[i].second);
            }

            if (sorted_eigenvalues[2] < 0.005 && std::abs(sorted_eigenvectors(2, 2)) > 0.85) {
                keepCluster = false;
            }

            // Cluster Box Height
            Eigen::MatrixXf pcl_matrix_coordinated = (eigenvectors.transpose() * pcl_matrix.transpose()).transpose();
            float height = pcl_matrix_coordinated.col(2).maxCoeff() - pcl_matrix_coordinated.col(2).minCoeff();
            
            float cluster_distance = com[0]*com[0] + com[1]*com[1];
            float min_d = 5.0;
            float max_d = 20.0;
            if (cluster_distance < max_d*max_d){
                if (height < (TARGET_TOP_HEIGHT_MAX-TARGET_TOP_HEIGHT_MIN)/((max_d-min_d)*(cluster_distance-min_d)) + TARGET_TOP_HEIGHT_MIN){
                    keepCluster = false;
                }
            }else{
                if (height < TARGET_TOP_HEIGHT_MAX){
                    keepCluster = false;
                }
            }

            // // Back of my Nukhada
            // double sqrt_3 = std::sqrt(3.0);
            // Eigen::Array<bool, Eigen::Dynamic, 1> mask_P = pcl_matrix_coordinated.col(1).array() < pcl_matrix_coordinated.col(0).array() / sqrt_3;
            // Eigen::Array<bool, Eigen::Dynamic, 1> mask_N = pcl_matrix_coordinated.col(1).array() > pcl_matrix_coordinated.col(0).array() / sqrt_3;
            // Eigen::Array<bool, Eigen::Dynamic, 1> mask_P_ = pcl_matrix_coordinated.col(1).array() < -pcl_matrix_coordinated.col(0).array() / sqrt_3;

            // bool condition1 = (mask_P_ && mask_N).any();
            // bool condition2 = (pcl_matrix_coordinated.col(0).array() < 0).any();
            // if (condition1 && condition2) {
            //     keepCluster = false;
            // }

            if (keepCluster){
                *TotalCloud += clusterCloud;
                clusterCloud.clear();
            }
        }

        j++;
    }

    sensor_msgs::PointCloud2 rosCloud;
    pcl::toROSMsg(*TotalCloud, rosCloud);
    rosCloud.header.frame_id = FRAME_ID;
    os_clustered.publish(rosCloud);

    TotalCloud.reset(new pcl::PointCloud<pcl::PointXYZI>);
}

int main(int argc, char **argv){
    ros::init(argc, argv, "dl_pst_node");
    ros::NodeHandle n;

    load_lidar_prop(n);

    os_filtered = n.advertise<sensor_msgs::PointCloud2>("/ouster_filtered_bag/points", 1);
    os_clustered = n.advertise<sensor_msgs::PointCloud2>("/ouster_clustered_bag/points", 1);
    ros::Subscriber sub_pointcloud = n.subscribe("/ouster_fixed_bag/points", 10, cloud_cb);

    while(ros::ok()){
        ros::spinOnce();
        lidar_detection_function(os_pcl_data);
    }

    return 0;
}